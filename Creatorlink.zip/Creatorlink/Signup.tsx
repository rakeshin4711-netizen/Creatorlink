import { MarketingLayout, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Eye,
  EyeOff,
  Hexagon,
  ArrowRight,
  User,
  Briefcase,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { createSession } from "@/lib/session";

type Role = "client" | "creator" | null;

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim());
}

function isStrongPassword(password: string) {
  return (
    password.length >= 8 &&
    /[A-Z]/.test(password) &&
    /[a-z]/.test(password) &&
    /\d/.test(password)
  );
}

export default function Signup() {
  const [location, setLocation] = useLocation();

  const [role, setRole] = useState<Role>(null);
  const [step, setStep] = useState(1);

  const [showPassword, setShowPassword] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const returnTo = new URLSearchParams(
    location.split("?")[1] ?? "",
  ).get("returnTo");

  const safeReturnTo =
    returnTo &&
    returnTo.startsWith("/") &&
    !returnTo.startsWith("//")
      ? returnTo
      : null;

  const handleContinue = () => {
    setError("");
    setSuccess("");

    if (!role) {
      setError("Please select whether you are a Client or Creator.");
      return;
    }

    setStep(2);
  };

  const handleSignup = (e: React.FormEvent) => {
    e.preventDefault();

    setError("");
    setSuccess("");

    const cleanFirstName = firstName.trim();
    const cleanLastName = lastName.trim();
    const cleanEmail = email.trim().toLowerCase();

    // First name validation
    if (!cleanFirstName) {
      setError("Please enter your first name.");
      return;
    }

    // Last name validation
    if (!cleanLastName) {
      setError("Please enter your last name.");
      return;
    }

    // Email validation
    if (!cleanEmail) {
      setError("Please enter your email address.");
      return;
    }

    if (!isValidEmail(cleanEmail)) {
      setError(
        "Invalid email address. Please enter a valid email like name@example.com.",
      );
      return;
    }

    // Password validation
    if (!password) {
      setError("Please enter a password.");
      return;
    }

    if (!isStrongPassword(password)) {
      setError(
        "Password must be at least 8 characters and contain uppercase, lowercase, and a number.",
      );
      return;
    }

    if (!role) {
      setError("Please select an account type.");
      return;
    }

    const sessionRole = role;

    createSession(sessionRole, cleanEmail, true);

    setSuccess("Account created successfully.");

    setTimeout(() => {
      setLocation(
        safeReturnTo ??
          (sessionRole === "client"
            ? "/client-dashboard"
            : "/creator-dashboard"),
      );
    }, 300);
  };

  return (
    <MarketingLayout>
      <div className="min-h-[80vh] flex items-center justify-center px-4 relative pt-20 pb-10">
        <div className="ambient-glow ambient-glow-accent -right-40 top-1/2 -translate-y-1/2" />

        <motion.div
          layout
          className="w-full max-w-lg relative z-10"
        >
          <PremiumCard className="p-8 md:p-10 border-white/20 min-h-[500px] flex flex-col">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col h-full"
                >
                  <div className="flex flex-col items-center mb-8">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center mb-4">
                      <Hexagon className="w-6 h-6" />
                    </div>

                    <h1 className="text-2xl font-bold tracking-tight">
                      Join CreatorLink
                    </h1>

                    <p className="text-muted-foreground mt-2 text-sm text-center">
                      To begin, tell us how you want to use the platform.
                    </p>
                  </div>

                  {error && (
                    <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 gap-4 mb-8">
                    <button
                      type="button"
                      onClick={() => {
                        setRole("client");
                        setError("");
                      }}
                      className={cn(
                        "p-6 rounded-2xl border text-left transition-all",
                        role === "client"
                          ? "border-primary bg-primary/10 shadow-[0_0_20px_rgba(108,92,231,0.2)]"
                          : "border-white/10 bg-white/5 hover:border-white/30",
                      )}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="p-3 rounded-lg bg-white/10 text-foreground">
                          <Briefcase className="w-6 h-6" />
                        </div>

                        <div
                          className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            role === "client"
                              ? "border-primary"
                              : "border-white/20",
                          )}
                        >
                          {role === "client" && (
                            <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                          )}
                        </div>
                      </div>

                      <h3 className="font-bold text-lg">
                        I'm a Client
                      </h3>

                      <p className="text-sm text-muted-foreground mt-1">
                        I want to hire top-tier creative talent for my
                        projects.
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setRole("creator");
                        setError("");
                      }}
                      className={cn(
                        "p-6 rounded-2xl border text-left transition-all",
                        role === "creator"
                          ? "border-accent bg-accent/10 shadow-[0_0_20px_rgba(0,210,255,0.2)]"
                          : "border-white/10 bg-white/5 hover:border-white/30",
                      )}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="p-3 rounded-lg bg-white/10 text-foreground">
                          <User className="w-6 h-6" />
                        </div>

                        <div
                          className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            role === "creator"
                              ? "border-accent"
                              : "border-white/20",
                          )}
                        >
                          {role === "creator" && (
                            <div className="w-2.5 h-2.5 rounded-full bg-accent" />
                          )}
                        </div>
                      </div>

                      <h3 className="font-bold text-lg">
                        I'm a Creator
                      </h3>

                      <p className="text-sm text-muted-foreground mt-1">
                        I want to showcase my portfolio and find clients.
                      </p>
                    </button>
                  </div>

                  <div className="mt-auto">
                    <PremiumButton
                      className="w-full"
                      onClick={handleContinue}
                      disabled={!role}
                      variant={role ? "primary" : "secondary"}
                    >
                      Continue
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </PremiumButton>

                    <div className="mt-6 text-center text-sm text-muted-foreground">
                      Already have an account?{" "}
                      <Link
                        href={
                          safeReturnTo
                            ? `/login?returnTo=${encodeURIComponent(
                                safeReturnTo,
                              )}`
                            : "/login"
                        }
                        className="text-primary font-medium hover:underline"
                      >
                        Log in
                      </Link>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex flex-col h-full"
                >
                  <button
                    type="button"
                    onClick={() => {
                      setStep(1);
                      setError("");
                    }}
                    className="text-sm text-muted-foreground hover:text-foreground mb-6 flex items-center gap-1 w-max"
                  >
                    ← Back
                  </button>

                  <div className="mb-8">
                    <h1 className="text-2xl font-bold tracking-tight">
                      Create your{" "}
                      {role === "client" ? "Client" : "Creator"} account
                    </h1>

                    <p className="text-muted-foreground mt-2 text-sm">
                      Just a few details to get you set up.
                    </p>
                  </div>

                  {error && (
                    <div className="mb-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300 flex items-start gap-2">
                      <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>{error}</span>
                    </div>
                  )}

                  {success && (
                    <div className="mb-4 rounded-xl border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300 flex items-start gap-2">
                      <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
                      <span>{success}</span>
                    </div>
                  )}

                  <form
                    onSubmit={handleSignup}
                    className="space-y-4 flex-1"
                    noValidate
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          First name
                        </label>

                        <input
                          type="text"
                          value={firstName}
                          onChange={(e) => {
                            setFirstName(e.target.value);
                            setError("");
                          }}
                          placeholder="John"
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">
                          Last name
                        </label>

                        <input
                          type="text"
                          value={lastName}
                          onChange={(e) => {
                            setLastName(e.target.value);
                            setError("");
                          }}
                          placeholder="Doe"
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Email
                      </label>

                      <input
                        type="email"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          setError("");
                        }}
                        placeholder="john@example.com"
                        autoComplete="email"
                        className={cn(
                          "w-full h-11 px-4 rounded-xl bg-white/5 border focus:ring-1 outline-none transition-all",
                          error && email
                            ? "border-red-500/50 focus:border-red-500 focus:ring-red-500"
                            : "border-white/10 focus:border-primary focus:ring-primary",
                        )}
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">
                        Password
                      </label>

                      <div className="relative">
                        <input
                          type={
                            showPassword
                              ? "text"
                              : "password"
                          }
                          value={password}
                          onChange={(e) => {
                            setPassword(e.target.value);
                            setError("");
                          }}
                          placeholder="Minimum 8 characters"
                          autoComplete="new-password"
                          className="w-full h-11 px-4 pr-11 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />

                        <button
                          type="button"
                          onClick={() =>
                            setShowPassword((visible) => !visible)
                          }
                          aria-label={
                            showPassword
                              ? "Hide password"
                              : "Show password"
                          }
                          className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground hover:text-foreground"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>

                      <p className="text-xs text-muted-foreground">
                        Use 8+ characters with uppercase, lowercase and
                        a number.
                      </p>
                    </div>

                    <PremiumButton
                      type="submit"
                      className="w-full mt-8"
                      glow
                    >
                      Create Account
                    </PremiumButton>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </PremiumCard>
        </motion.div>
      </div>
    </MarketingLayout>
  );
}