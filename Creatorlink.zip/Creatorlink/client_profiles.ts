cd ~/workspace

cat > lib/db/src/schema/client-profiles.ts <<'EOF'
import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const clientProfilesTable = pgTable("client_profiles", {
  id: serial("id").primaryKey(),

  userId: integer("user_id")
    .notNull()
    .unique()
    .references(() => usersTable.id, { onDelete: "cascade" }),

  companyName: text("company_name").notNull().default(""),
  bio: text("bio").notNull().default(""),
  location: text("location").notNull().default(""),
  website: text("website").notNull().default(""),
  industry: text("industry").notNull().default(""),
  profilePhoto: text("profile_photo").notNull().default(""),

  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),

  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertClientProfileSchema = createInsertSchema(
  clientProfilesTable,
).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertClientProfile = z.infer<
  typeof insertClientProfileSchema
>;

export type ClientProfile =
  typeof clientProfilesTable.$inferSelect;
EOF