import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgEnum,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const blogStatusEnum = pgEnum("blog_status", ["draft", "published"]);

export const blogsTable = pgTable("blogs", {
  id: serial("id").primaryKey(),
  authorIdentifier: text("author_identifier").notNull(),
  slug: text("slug").notNull().unique(),
  title: text("title").notNull(),
  shortDescription: text("short_description").notNull().default(""),
  contentHtml: text("content_html").notNull().default(""),
  coverImage: text("cover_image").notNull().default(""),
  category: text("category").notNull().default(""),
  tags: text("tags").array().notNull().default([]),
  readingTime: integer("reading_time").notNull().default(1),
  status: blogStatusEnum("status").notNull().default("draft"),
  seoTitle: text("seo_title").notNull().default(""),
  seoDescription: text("seo_description").notNull().default(""),
  publishedAt: timestamp("published_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertBlogSchema = createInsertSchema(blogsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertBlog = z.infer<typeof insertBlogSchema>;
export type Blog = typeof blogsTable.$inferSelect;