import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const creatorsTable = pgTable("creators", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  profilePhoto: text("profile_photo").notNull().default(""),
  fullName: text("full_name").notNull(),
  bio: text("bio").notNull().default(""),
  skills: text("skills").array().notNull().default([]),
  experience: text("experience").notNull().default(""),
  category: text("category").notNull().default(""),
  hourlyRate: integer("hourly_rate").notNull().default(0),
  location: text("location").notNull().default(""),
  socialLinks: jsonb("social_links")
    .$type<Record<string, string>>()
    .notNull()
    .default({}),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertCreatorSchema = createInsertSchema(creatorsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertCreator = z.infer<typeof insertCreatorSchema>;
export type Creator = typeof creatorsTable.$inferSelect;