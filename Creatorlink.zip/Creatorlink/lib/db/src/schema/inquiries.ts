import { createInsertSchema } from "drizzle-zod";
import { integer, pgEnum, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const inquiryStatusEnum = pgEnum("inquiry_status", [
  "pending",
  "accepted",
  "rejected",
  "cancelled",
]);

export const inquiriesTable = pgTable("inquiries", {
  id: serial("id").primaryKey(),
  clientIdentifier: text("client_identifier").notNull(),
  creatorIdentifier: text("creator_identifier").notNull(),
  title: text("title").notNull(),
  message: text("message").notNull().default(""),
  budget: integer("budget").notNull().default(0),
  status: inquiryStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertInquirySchema = createInsertSchema(inquiriesTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertInquiry = z.infer<typeof insertInquirySchema>;
export type Inquiry = typeof inquiriesTable.$inferSelect;
