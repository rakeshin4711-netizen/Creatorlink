import { boolean, pgEnum, pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";

export const userRoleEnum = pgEnum("user_role", ["client", "creator"]);

export const usersTable = pgTable("users", {
  id: serial("id").primaryKey(),

  email: text("email").notNull().unique(),

  passwordHash: text("password_hash").notNull(),

  firstName: text("first_name"),
  lastName: text("last_name"),

  role: userRoleEnum("role").notNull().default("client"),

  emailVerified: boolean("email_verified").notNull().default(false),

  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),

  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});