import { createInsertSchema } from "drizzle-zod";
import {
  integer,
  pgTable,
  serial,
  text,
  timestamp,
} from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const paymentsTable = pgTable("payments", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull(),
  clientIdentifier: text("client_identifier").notNull(),
  creatorIdentifier: text("creator_identifier"),
  amount: integer("amount").notNull(),
  currency: text("currency").notNull().default("INR"),
  commissionAmount: integer("commission_amount").notNull(),
  creatorEarnings: integer("creator_earnings").notNull(),
  status: text("status").notNull().default("pending"),
  provider: text("provider").notNull().default("mock"),
  paymentId: text("payment_id").notNull().unique(),
  invoiceNumber: text("invoice_number").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
});

export const insertPaymentSchema = createInsertSchema(paymentsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type Payment = typeof paymentsTable.$inferSelect;