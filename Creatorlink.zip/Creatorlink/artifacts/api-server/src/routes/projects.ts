import { desc, eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, projectsTable } from "@workspace/db";
import {
  CreateClientProjectBody,
  CreateClientProjectResponse,
  DeleteClientProjectParams,
  GetClientProjectParams,
  GetClientProjectResponse,
  ListClientProjectsQueryParams,
  ListClientProjectsResponse,
  UpdateClientProjectBody,
  UpdateClientProjectParams,
  UpdateClientProjectResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function dateOnly(value: Date) {
  return value.toISOString().slice(0, 10);
}

function projectResponse(project: typeof projectsTable.$inferSelect) {
  return {
    id: project.id,
    clientIdentifier: project.clientIdentifier,
    creatorIdentifier: project.creatorIdentifier,
    title: project.title,
    description: project.description,
    category: project.category,
    budget: project.budget,
    deadline: project.deadline,
    skills: project.skills,
    status: project.status,
  };
}

router.get("/projects", async (req, res): Promise<void> => {
  const params = ListClientProjectsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const projects = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.clientIdentifier, params.data.clientIdentifier))
    .orderBy(desc(projectsTable.createdAt));

  res.json(ListClientProjectsResponse.parse(projects.map(projectResponse)));
});

router.post("/projects", async (req, res): Promise<void> => {
  const parsed = CreateClientProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [project] = await db
    .insert(projectsTable)
    .values({
      clientIdentifier: parsed.data.clientIdentifier,
      creatorIdentifier: parsed.data.creatorIdentifier ?? null,
      title: parsed.data.title.trim(),
      description: parsed.data.description.trim(),
      category: parsed.data.category.trim(),
      budget: parsed.data.budget,
      deadline: dateOnly(parsed.data.deadline),
      skills: parsed.data.skills.map((skill) => skill.trim()).filter(Boolean),
      status: parsed.data.status ?? "pending",
    })
    .returning();

  res.status(201).json(CreateClientProjectResponse.parse(projectResponse(project)));
});

router.get("/projects/:projectId", async (req, res): Promise<void> => {
  const params = GetClientProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const projects = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.projectId))
    .limit(1);

  if (!projects[0]) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.json(GetClientProjectResponse.parse(projectResponse(projects[0])));
});

router.patch("/projects/:projectId", async (req, res): Promise<void> => {
  const params = UpdateClientProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateClientProjectBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const existing = await db
    .select()
    .from(projectsTable)
    .where(
      eq(projectsTable.id, params.data.projectId),
    )
    .limit(1);

  if (!existing[0] || existing[0].clientIdentifier !== parsed.data.clientIdentifier) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const [project] = await db
    .update(projectsTable)
    .set({
      title: parsed.data.title.trim(),
      description: parsed.data.description.trim(),
      category: parsed.data.category.trim(),
      budget: parsed.data.budget,
      deadline: dateOnly(parsed.data.deadline),
      skills: parsed.data.skills.map((skill) => skill.trim()).filter(Boolean),
      updatedAt: new Date(),
    })
    .where(eq(projectsTable.id, params.data.projectId))
    .returning();

  res.json(UpdateClientProjectResponse.parse(projectResponse(project)));
});

router.delete("/projects/:projectId", async (req, res): Promise<void> => {
  const params = DeleteClientProjectParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const project = await db
    .select({ id: projectsTable.id })
    .from(projectsTable)
    .where(eq(projectsTable.id, params.data.projectId))
    .limit(1);

  if (!project[0]) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const deleted = await db
    .delete(projectsTable)
    .where(
      eq(projectsTable.id, params.data.projectId),
    )
    .returning({ id: projectsTable.id });

  if (!deleted.length || project[0].id !== params.data.projectId) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  res.status(204).send();
});

export default router;