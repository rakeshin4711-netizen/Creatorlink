import crypto from "crypto";
import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, sessionsTable, usersTable } from "@workspace/db";
import { hashPassword, verifyPassword } from "../lib/auth";
import { getSessionUser } from "../lib/session";

const router: IRouter = Router();

const SESSION_DURATION_MS = 7 * 24 * 60 * 60 * 1000;

function createSessionToken(): string {
  return crypto.randomBytes(32).toString("hex");
}

function hashSessionToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

function getSessionTokenFromCookie(req: {
  headers: {
    cookie?: string;
  };
}): string | null {
  const cookieHeader = req.headers.cookie;

  if (!cookieHeader) {
    return null;
  }

  const cookies = cookieHeader.split(";");

  for (const cookie of cookies) {
    const [name, ...valueParts] = cookie.trim().split("=");

    if (name === "session_token") {
      return decodeURIComponent(valueParts.join("="));
    }
  }

  return null;
}

function setSessionCookie(
  res: {
    cookie: (
      name: string,
      value: string,
      options: {
        httpOnly: boolean;
        secure: boolean;
        sameSite: "lax";
        expires: Date;
        path: string;
      },
    ) => void;
  },
  sessionToken: string,
  expiresAt: Date,
) {
  res.cookie("session_token", sessionToken, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    expires: expiresAt,
    path: "/",
  });
}

router.post("/auth/signup", async (req, res): Promise<void> => {
  const { email, password, firstName, lastName, role } = req.body ?? {};

  if (
    typeof email !== "string" ||
    typeof password !== "string"
  ) {
    res.status(400).json({
      error: "Email and password are required",
    });
    return;
  }

  const normalizedEmail = email.trim().toLowerCase();

  if (!normalizedEmail || password.length < 8) {
    res.status(400).json({
      error:
        "Enter a valid email and a password of at least 8 characters",
    });
    return;
  }

  const existingUser = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, normalizedEmail))
    .limit(1);

  if (existingUser[0]) {
    res.status(409).json({
      error: "An account with this email already exists",
    });
    return;
  }

  const passwordHash = await hashPassword(password);

  const [user] = await db
    .insert(usersTable)
    .values({
      email: normalizedEmail,
      passwordHash,
      firstName:
        typeof firstName === "string"
          ? firstName.trim() || null
          : null,
      lastName:
        typeof lastName === "string"
          ? lastName.trim() || null
          : null,
      role: role === "creator" ? "creator" : "client",
    })
    .returning({
      id: usersTable.id,
      email: usersTable.email,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      role: usersTable.role,
      emailVerified: usersTable.emailVerified,
    });

  const sessionToken = createSessionToken();
  const tokenHash = hashSessionToken(sessionToken);

  const expiresAt = new Date(
    Date.now() + SESSION_DURATION_MS,
  );

  await db.insert(sessionsTable).values({
    tokenHash,
    userId: user.id,
    expiresAt,
  });

  setSessionCookie(res, sessionToken, expiresAt);

  res.status(201).json({
    user,
  });
});

router.post("/auth/login", async (req, res): Promise<void> => {
  const { email, password } = req.body ?? {};

  if (
    typeof email !== "string" ||
    typeof password !== "string"
  ) {
    res.status(401).json({
      error: "Invalid email or password",
    });
    return;
  }

  const normalizedEmail = email.trim().toLowerCase();

  const [user] = await db
    .select({
      id: usersTable.id,
      email: usersTable.email,
      passwordHash: usersTable.passwordHash,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      role: usersTable.role,
      emailVerified: usersTable.emailVerified,
    })
    .from(usersTable)
    .where(eq(usersTable.email, normalizedEmail))
    .limit(1);

  if (!user) {
    res.status(401).json({
      error: "Invalid email or password",
    });
    return;
  }

  const passwordValid = await verifyPassword(
    password,
    user.passwordHash,
  );

  if (!passwordValid) {
    res.status(401).json({
      error: "Invalid email or password",
    });
    return;
  }

  const sessionToken = createSessionToken();
  const tokenHash = hashSessionToken(sessionToken);

  const expiresAt = new Date(
    Date.now() + SESSION_DURATION_MS,
  );

  await db.insert(sessionsTable).values({
    tokenHash,
    userId: user.id,
    expiresAt,
  });

  setSessionCookie(res, sessionToken, expiresAt);

  res.status(200).json({
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      role: user.role,
      emailVerified: user.emailVerified,
    },
  });
});

router.get("/auth/me", async (req, res): Promise<void> => {
  const sessionToken = getSessionTokenFromCookie(req);

  if (!sessionToken) {
    res.status(401).json({
      error: "Not authenticated",
    });
    return;
  }

  const session = await getSessionUser(sessionToken);

  if (!session) {
    res.status(401).json({
      error: "Invalid or expired session",
    });
    return;
  }

  res.status(200).json({
    user: session.user,
  });
});

router.post("/auth/logout", async (req, res): Promise<void> => {
  const sessionToken = getSessionTokenFromCookie(req);

  if (sessionToken) {
    const tokenHash = hashSessionToken(sessionToken);

    await db
      .delete(sessionsTable)
      .where(eq(sessionsTable.tokenHash, tokenHash));
  }

  res.clearCookie("session_token", {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
  });

  res.status(200).json({
    message: "Logged out successfully",
  });
});

export default router;