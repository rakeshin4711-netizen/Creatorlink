import { and, asc, desc, eq, or, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, conversationsTable, messagesTable } from "@workspace/db";
import {
  CreateConversationBody,
  CreateConversationResponse,
  ListConversationMessagesResponse,
  ListConversationMessagesParams,
  ListConversationsQueryParams,
  ListConversationsResponse,
  SendConversationMessageBody,
  SendConversationMessageParams,
  SendConversationMessageResponse,
  MarkConversationReadBody,
  MarkConversationReadParams,
  MarkConversationReadResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function getConversation(id: number) {
  const rows = await db
    .select()
    .from(conversationsTable)
    .where(eq(conversationsTable.id, id))
    .limit(1);
  return rows[0];
}

function getUnreadCount(
  conversation: {
    participantOne: string;
    participantTwo: string;
    unreadCountOne: number;
    unreadCountTwo: number;
  },
  participant: string,
) {
  if (conversation.participantOne === participant) return conversation.unreadCountOne;
  if (conversation.participantTwo === participant) return conversation.unreadCountTwo;
  return 0;
}

async function getConversationSummary(
  conversation: {
    id: number;
    participantOne: string;
    participantTwo: string;
    unreadCountOne: number;
    unreadCountTwo: number;
  },
  participant: string,
) {
  const last = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, conversation.id))
    .orderBy(desc(messagesTable.createdAt), desc(messagesTable.id))
    .limit(1);

  return {
    id: conversation.id,
    participantOne: conversation.participantOne,
    participantTwo: conversation.participantTwo,
    unreadCount: getUnreadCount(conversation, participant),
    lastMessage: last[0]?.text ?? "",
    lastMessageAt: last[0]?.createdAt?.toISOString() ?? null,
  };
}

router.get("/conversations", async (req, res): Promise<void> => {
  const parsed = ListConversationsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const participant = parsed.data.participant;
  const conversations = await db
    .select()
    .from(conversationsTable)
    .where(
      or(
        eq(conversationsTable.participantOne, participant),
        eq(conversationsTable.participantTwo, participant),
      ),
    )
    .orderBy(desc(conversationsTable.updatedAt));

  const result = await Promise.all(
    conversations.map((conversation) => getConversationSummary(conversation, participant)),
  );

  res.setHeader("Cache-Control", "no-store");
  res.json(ListConversationsResponse.parse(result));
});

router.post("/conversations", async (req, res): Promise<void> => {
  const parsed = CreateConversationBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const { participant, otherParticipant } = parsed.data;
  const existing = await db
    .select()
    .from(conversationsTable)
    .where(
      or(
        and(
          eq(conversationsTable.participantOne, participant),
          eq(conversationsTable.participantTwo, otherParticipant),
        ),
        and(
          eq(conversationsTable.participantOne, otherParticipant),
          eq(conversationsTable.participantTwo, participant),
        ),
      ),
    )
    .limit(1);

  if (existing[0]) {
    res.json(
      CreateConversationResponse.parse(
        await getConversationSummary(existing[0], participant),
      ),
    );
    return;
  }

  const [conversation] = await db
    .insert(conversationsTable)
    .values({
      participantOne: participant,
      participantTwo: otherParticipant,
    })
    .returning();

  res.json(
    CreateConversationResponse.parse(await getConversationSummary(conversation, participant)),
  );
});

router.get("/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const parsed = ListConversationMessagesParams.safeParse(req.params);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const conversation = await getConversation(parsed.data.conversationId);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  const messages = await db
    .select()
    .from(messagesTable)
    .where(eq(messagesTable.conversationId, conversation.id))
    .orderBy(asc(messagesTable.createdAt), asc(messagesTable.id));

  res.setHeader("Cache-Control", "no-store");
  res.json(ListConversationMessagesResponse.parse(messages));
});

router.post("/conversations/:conversationId/read", async (req, res): Promise<void> => {
  const params = MarkConversationReadParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = MarkConversationReadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const conversation = await getConversation(params.data.conversationId);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  if (
    conversation.participantOne !== parsed.data.participant &&
    conversation.participantTwo !== parsed.data.participant
  ) {
    res.status(403).json({ error: "Participant is not part of this conversation" });
    return;
  }

  await db
    .update(conversationsTable)
    .set(
      conversation.participantOne === parsed.data.participant
        ? { unreadCountOne: 0 }
        : { unreadCountTwo: 0 },
    )
    .where(eq(conversationsTable.id, conversation.id));

  const updated = await getConversation(conversation.id);
  if (!updated) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  res.setHeader("Cache-Control", "no-store");
  res.json(
    MarkConversationReadResponse.parse(
      await getConversationSummary(updated, parsed.data.participant),
    ),
  );
});

router.post("/conversations/:conversationId/messages", async (req, res): Promise<void> => {
  const params = SendConversationMessageParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = SendConversationMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const conversation = await getConversation(params.data.conversationId);
  if (!conversation) {
    res.status(404).json({ error: "Conversation not found" });
    return;
  }

  if (
    conversation.participantOne !== parsed.data.senderId &&
    conversation.participantTwo !== parsed.data.senderId
  ) {
    res.status(403).json({ error: "Sender is not part of this conversation" });
    return;
  }

  const text = parsed.data.text.trim();
  if (!text && !parsed.data.attachment.trim()) {
    res.status(400).json({ error: "Message text or attachment is required" });
    return;
  }

  const [message] = await db
    .insert(messagesTable)
    .values({
      conversationId: conversation.id,
      senderId: parsed.data.senderId,
      text,
      attachment: parsed.data.attachment,
    })
    .returning();

  await db
    .update(conversationsTable)
    .set({
      ...(conversation.participantOne === parsed.data.senderId
        ? { unreadCountTwo: sql`${conversationsTable.unreadCountTwo} + 1` }
        : { unreadCountOne: sql`${conversationsTable.unreadCountOne} + 1` }),
      updatedAt: new Date(),
    })
    .where(eq(conversationsTable.id, conversation.id));

  res.status(201).json(SendConversationMessageResponse.parse(message));
});

export default router;