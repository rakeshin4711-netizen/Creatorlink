import { and, desc, eq, ne } from "drizzle-orm";
import { Router, type IRouter } from "express";
import {
  blogsTable,
  creatorsTable,
  db,
  type Blog,
} from "@workspace/db";
import {
  CreateBlogBody,
  CreateBlogResponse,
  DeleteBlogByIdParams,
  GetBlogBySlugParams,
  GetBlogBySlugResponse,
  ListMyBlogsQueryParams,
  ListPublishedBlogsResponse,
  ListRelatedBlogsParams,
  ListRelatedBlogsResponse,
  UpdateBlogByIdBody,
  UpdateBlogByIdParams,
  UpdateBlogByIdResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

type Author = {
  name: string;
  profileUrl: string;
};

async function authorFor(identifier: string): Promise<Author> {
  const [creator] = await db
    .select({
      fullName: creatorsTable.fullName,
      username: creatorsTable.username,
      profilePhoto: creatorsTable.profilePhoto,
    })
    .from(creatorsTable)
    .where(eq(creatorsTable.username, identifier))
    .limit(1);

  return {
    name: creator?.fullName || identifier,
    profileUrl: creator?.profilePhoto || "",
  };
}

async function blogResponse(blog: Blog) {
  const author = await authorFor(blog.authorIdentifier);
  return {
    id: blog.id,
    authorIdentifier: blog.authorIdentifier,
    slug: blog.slug,
    title: blog.title,
    shortDescription: blog.shortDescription,
    contentHtml: blog.contentHtml,
    coverImage: blog.coverImage,
    category: blog.category,
    tags: blog.tags,
    readingTime: blog.readingTime,
    status: blog.status,
    seoTitle: blog.seoTitle,
    seoDescription: blog.seoDescription,
    authorName: author.name,
    authorProfileUrl: author.profileUrl,
    publishedAt: blog.publishedAt?.toISOString() ?? null,
    createdAt: blog.createdAt.toISOString(),
    updatedAt: blog.updatedAt.toISOString(),
  };
}

async function blogResponses(blogs: Blog[]) {
  return Promise.all(blogs.map(blogResponse));
}

function slugify(value: string) {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function normalizedBlogValues(data: typeof CreateBlogBody._type) {
  const wordCount = data.contentHtml
    .replace(/<[^>]*>/g, " ")
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;

  return {
    authorIdentifier: data.authorIdentifier.trim(),
    slug: data.slug.trim() || slugify(data.title),
    title: data.title.trim(),
    shortDescription: data.shortDescription.trim(),
    contentHtml: data.contentHtml,
    coverImage: data.coverImage,
    category: data.category.trim(),
    tags: data.tags.map((tag) => tag.trim()).filter(Boolean),
    readingTime: Math.max(1, Math.ceil(wordCount / 200)),
    status: data.status,
    seoTitle: data.seoTitle.trim(),
    seoDescription: data.seoDescription.trim(),
    publishedAt: data.status === "published" ? new Date() : null,
  };
}

function validateBlogValues(values: ReturnType<typeof normalizedBlogValues>) {
  if (!values.authorIdentifier) return "Author is required";
  if (!values.title) return "Title is required";
  if (!values.slug) return "A valid title or slug is required";
  if (!values.shortDescription && values.status === "published") {
    return "Short description is required for published articles";
  }
  if (!values.contentHtml.replace(/<[^>]*>/g, " ").trim()) {
    return "Content is required";
  }
  if (!values.category && values.status === "published") {
    return "Category is required for published articles";
  }
  return null;
}

router.get("/blogs", async (_req, res): Promise<void> => {
  const blogs = await db
    .select()
    .from(blogsTable)
    .where(eq(blogsTable.status, "published"))
    .orderBy(desc(blogsTable.publishedAt), desc(blogsTable.createdAt));

  res.json(ListPublishedBlogsResponse.parse(await blogResponses(blogs)));
});

router.post("/blogs", async (req, res): Promise<void> => {
  const parsed = CreateBlogBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const values = normalizedBlogValues(parsed.data);
  const validationError = validateBlogValues(values);
  if (validationError) {
    res.status(400).json({ error: validationError });
    return;
  }

  const existing = await db
    .select({ id: blogsTable.id })
    .from(blogsTable)
    .where(eq(blogsTable.slug, values.slug))
    .limit(1);
  if (existing[0]) {
    res.status(409).json({ error: "A blog with this slug already exists" });
    return;
  }

  const [blog] = await db.insert(blogsTable).values(values).returning();
  res.status(201).json(CreateBlogResponse.parse(await blogResponse(blog)));
});

router.get("/blogs/mine", async (req, res): Promise<void> => {
  const parsed = ListMyBlogsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const blogs = await db
    .select()
    .from(blogsTable)
    .where(eq(blogsTable.authorIdentifier, parsed.data.authorIdentifier))
    .orderBy(desc(blogsTable.updatedAt));

  res.json(ListPublishedBlogsResponse.parse(await blogResponses(blogs)));
});

router.get("/blogs/slug/:slug/related", async (req, res): Promise<void> => {
  const params = ListRelatedBlogsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [source] = await db
    .select({ category: blogsTable.category, id: blogsTable.id })
    .from(blogsTable)
    .where(and(eq(blogsTable.slug, params.data.slug), eq(blogsTable.status, "published")))
    .limit(1);

  if (!source) {
    res.json([]);
    return;
  }

  const related = await db
    .select()
    .from(blogsTable)
    .where(
      and(
        eq(blogsTable.status, "published"),
        eq(blogsTable.category, source.category),
        ne(blogsTable.id, source.id),
      ),
    )
    .orderBy(desc(blogsTable.publishedAt), desc(blogsTable.createdAt))
    .limit(4);

  res.json(ListRelatedBlogsResponse.parse(await blogResponses(related)));
});

router.get("/blogs/slug/:slug", async (req, res): Promise<void> => {
  const params = GetBlogBySlugParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [blog] = await db
    .select()
    .from(blogsTable)
    .where(and(eq(blogsTable.slug, params.data.slug), eq(blogsTable.status, "published")))
    .limit(1);

  if (!blog) {
    res.status(404).json({ error: "Blog post not found" });
    return;
  }

  res.json(GetBlogBySlugResponse.parse(await blogResponse(blog)));
});

router.patch("/blogs/id/:blogId/author/:authorIdentifier", async (req, res): Promise<void> => {
  const params = UpdateBlogByIdParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateBlogByIdBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [existing] = await db
    .select()
    .from(blogsTable)
    .where(
      and(
        eq(blogsTable.id, params.data.blogId),
        eq(blogsTable.authorIdentifier, params.data.authorIdentifier),
      ),
    )
    .limit(1);
  if (!existing) {
    res.status(404).json({ error: "Blog post not found" });
    return;
  }

  const values = normalizedBlogValues(parsed.data);
  const validationError = validateBlogValues(values);
  if (validationError) {
    res.status(400).json({ error: validationError });
    return;
  }

  const slugConflict = await db
    .select({ id: blogsTable.id })
    .from(blogsTable)
    .where(and(eq(blogsTable.slug, values.slug), ne(blogsTable.id, existing.id)))
    .limit(1);
  if (slugConflict[0]) {
    res.status(409).json({ error: "A blog with this slug already exists" });
    return;
  }

  const [updated] = await db
    .update(blogsTable)
    .set({ ...values, updatedAt: new Date() })
    .where(eq(blogsTable.id, existing.id))
    .returning();

  res.json(UpdateBlogByIdResponse.parse(await blogResponse(updated)));
});

router.delete("/blogs/id/:blogId/author/:authorIdentifier", async (req, res): Promise<void> => {
  const params = DeleteBlogByIdParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const deleted = await db
    .delete(blogsTable)
    .where(
      and(
        eq(blogsTable.id, params.data.blogId),
        eq(blogsTable.authorIdentifier, params.data.authorIdentifier),
      ),
    )
    .returning({ id: blogsTable.id });

  if (!deleted[0]) {
    res.status(404).json({ error: "Blog post not found" });
    return;
  }

  res.status(204).send();
});

export default router;