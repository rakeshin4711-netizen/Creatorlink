import { randomUUID } from "node:crypto";
import { eq } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, paymentsTable, projectsTable } from "@workspace/db";
import {
  CreateMockPaymentBody,
  CreateMockPaymentResponse,
  GetPaymentByPaymentIdParams,
  GetPaymentByPaymentIdResponse,
  ListClientPaymentsQueryParams,
  ListClientPaymentsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function paymentResponse(payment: typeof paymentsTable.$inferSelect) {
  return {
    id: payment.id,
    projectId: payment.projectId,
    clientIdentifier: payment.clientIdentifier,
    creatorIdentifier: payment.creatorIdentifier,
    amount: payment.amount,
    currency: payment.currency,
    commissionAmount: payment.commissionAmount,
    creatorEarnings: payment.creatorEarnings,
    status: payment.status,
    provider: payment.provider,
    paymentId: payment.paymentId,
    invoiceNumber: payment.invoiceNumber,
    createdAt: payment.createdAt,
    updatedAt: payment.updatedAt,
  };
}

router.post("/payments/mock", async (req, res): Promise<void> => {
  const parsed = CreateMockPaymentBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [project] = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, parsed.data.projectId))
    .limit(1);

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  if (project.clientIdentifier !== parsed.data.clientIdentifier) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const amount = Math.max(0, project.budget);
  const commissionAmount = Math.round(amount * 0.1);
  const creatorEarnings = amount - commissionAmount;
  const status = parsed.data.outcome === "failure" ? "failed" : "succeeded";
  const reference = randomUUID().replace(/-/g, "").slice(0, 16);

  const payment = await db.transaction(async (tx) => {
    const [createdPayment] = await tx
      .insert(paymentsTable)
      .values({
        projectId: project.id,
        clientIdentifier: project.clientIdentifier,
        creatorIdentifier: project.creatorIdentifier,
        amount,
        currency: "INR",
        commissionAmount,
        creatorEarnings,
        status,
        provider: "mock",
        paymentId: `mock_pay_${reference}`,
        invoiceNumber: `INV-INR-${reference.toUpperCase()}`,
      })
      .returning();

    if (status === "succeeded") {
      await tx
        .update(projectsTable)
        .set({ status: "paid", updatedAt: new Date() })
        .where(eq(projectsTable.id, project.id));
    }

    return createdPayment;
  });

  res.status(201).json(CreateMockPaymentResponse.parse(paymentResponse(payment)));
});

router.get("/payments", async (req, res): Promise<void> => {
  const params = ListClientPaymentsQueryParams.safeParse(req.query);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const payments = await db
    .select()
    .from(paymentsTable)
    .where(eq(paymentsTable.clientIdentifier, params.data.clientIdentifier))
    .orderBy(paymentsTable.createdAt);

  res.json(ListClientPaymentsResponse.parse(payments.reverse().map(paymentResponse)));
});

router.get("/payments/:paymentId", async (req, res): Promise<void> => {
  const params = GetPaymentByPaymentIdParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [payment] = await db
    .select()
    .from(paymentsTable)
    .where(eq(paymentsTable.paymentId, params.data.paymentId))
    .limit(1);

  if (!payment) {
    res.status(404).json({ error: "Payment not found" });
    return;
  }

  res.json(GetPaymentByPaymentIdResponse.parse(paymentResponse(payment)));
});

export default router;