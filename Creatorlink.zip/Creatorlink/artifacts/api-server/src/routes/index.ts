import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import creatorsRouter from "./creators";
import messagesRouter from "./messages";
import projectsRouter from "./projects";
import paymentsRouter from "./payments";
import blogsRouter from "./blogs";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(creatorsRouter);
router.use(messagesRouter);
router.use(projectsRouter);
router.use(paymentsRouter);
router.use(blogsRouter);

export default router;