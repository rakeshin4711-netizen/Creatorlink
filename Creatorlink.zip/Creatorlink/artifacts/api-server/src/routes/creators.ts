import { and, eq, or } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { db, creatorsTable, portfoliosTable } from "@workspace/db";
import {
  CreateCreatorPortfolioBody,
  CreateCreatorPortfolioParams,
  CreateCreatorPortfolioResponse,
  DeleteCreatorPortfolioParams,
  GetPortfolioParams,
  GetPortfolioResponse,
  GetCreatorProfileResponse,
  GetCreatorProfileParams,
  ListCreatorPortfoliosParams,
  ListCreatorPortfoliosResponse,
  ListCreatorsResponse,
  UpsertCreatorProfileBody,
  UpdateCreatorPortfolioBody,
  UpdateCreatorPortfolioParams,
  UpdateCreatorPortfolioResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function findCreator(identifier: string) {
  const numericId = Number(identifier);
  const creators = await db
    .select()
    .from(creatorsTable)
    .where(
      Number.isInteger(numericId)
        ? or(eq(creatorsTable.username, identifier), eq(creatorsTable.id, numericId))
        : eq(creatorsTable.username, identifier),
    )
    .limit(1);
  return creators[0];
}

function portfolioResponse(
  portfolio: typeof portfoliosTable.$inferSelect,
  creatorUsername: string,
) {
  return {
    id: portfolio.id,
    creatorUsername,
    title: portfolio.title,
    description: portfolio.description,
    category: portfolio.category,
    skills: portfolio.skills,
    images: portfolio.images,
  };
}

router.get("/creators", async (_req, res): Promise<void> => {
  const creators = await db.select().from(creatorsTable);
  res.json(ListCreatorsResponse.parse(creators));
});

router.get("/creators/:identifier", async (req, res): Promise<void> => {
  const params = GetCreatorProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);

  if (!creator) {
    res.status(404).json({ error: "Creator profile not found" });
    return;
  }

  res.json(GetCreatorProfileResponse.parse(creator));
});

router.put("/creators/:identifier", async (req, res): Promise<void> => {
  const params = GetCreatorProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpsertCreatorProfileBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const identifier = params.data.identifier;
  const numericId = Number(identifier);
  const existing = await db
    .select({ id: creatorsTable.id, username: creatorsTable.username })
    .from(creatorsTable)
    .where(
      Number.isInteger(numericId)
        ? or(eq(creatorsTable.username, identifier), eq(creatorsTable.id, numericId))
        : eq(creatorsTable.username, identifier),
    )
    .limit(1);

  const values = {
    ...parsed.data,
    updatedAt: new Date(),
  };

  const saved = existing[0]
    ? await db
        .update(creatorsTable)
        .set({ ...parsed.data, updatedAt: new Date() })
        .where(eq(creatorsTable.id, existing[0].id))
        .returning()
    : await db
        .insert(creatorsTable)
        .values(values)
        .returning();

  res.json(GetCreatorProfileResponse.parse(saved[0]));
});

router.delete("/creators/:identifier", async (req, res): Promise<void> => {
  const params = GetCreatorProfileParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);
  if (!creator) {
    res.status(404).json({ error: "Creator profile not found" });
    return;
  }

  await db.transaction(async (transaction) => {
    await transaction
      .delete(portfoliosTable)
      .where(eq(portfoliosTable.creatorId, creator.id));
    await transaction
      .delete(creatorsTable)
      .where(eq(creatorsTable.id, creator.id));
  });

  res.status(204).send();
});

router.get("/creators/:identifier/portfolios", async (req, res): Promise<void> => {
  const params = ListCreatorPortfoliosParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);
  if (!creator) {
    res.status(404).json({ error: "Creator not found" });
    return;
  }

  const portfolios = await db
    .select()
    .from(portfoliosTable)
    .where(eq(portfoliosTable.creatorId, creator.id))
    .orderBy(portfoliosTable.createdAt);

  res.json(ListCreatorPortfoliosResponse.parse(
    portfolios.map((portfolio) => portfolioResponse(portfolio, creator.username)),
  ));
});

router.post("/creators/:identifier/portfolios", async (req, res): Promise<void> => {
  const params = CreateCreatorPortfolioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = CreateCreatorPortfolioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);
  if (!creator) {
    res.status(404).json({ error: "Creator not found" });
    return;
  }

  const [portfolio] = await db
    .insert(portfoliosTable)
    .values({ creatorId: creator.id, ...parsed.data })
    .returning();

  res.status(201).json(
    CreateCreatorPortfolioResponse.parse(portfolioResponse(portfolio, creator.username)),
  );
});

router.patch("/creators/:identifier/portfolios/:portfolioId", async (req, res): Promise<void> => {
  const params = UpdateCreatorPortfolioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateCreatorPortfolioBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);
  const existing = creator
    ? await db
        .select()
        .from(portfoliosTable)
        .where(
          and(
            eq(portfoliosTable.id, params.data.portfolioId),
            eq(portfoliosTable.creatorId, creator.id),
          ),
        )
        .limit(1)
    : [];
  const portfolio = existing[0];

  if (!creator || !portfolio || portfolio.creatorId !== creator.id) {
    res.status(404).json({ error: "Portfolio project not found" });
    return;
  }

  const [updated] = await db
    .update(portfoliosTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(portfoliosTable.id, portfolio.id))
    .returning();

  res.json(
    UpdateCreatorPortfolioResponse.parse(portfolioResponse(updated, creator.username)),
  );
});

router.delete("/creators/:identifier/portfolios/:portfolioId", async (req, res): Promise<void> => {
  const params = DeleteCreatorPortfolioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const creator = await findCreator(params.data.identifier);
  if (!creator) {
    res.status(404).json({ error: "Creator not found" });
    return;
  }

  const deleted = await db
    .delete(portfoliosTable)
    .where(
      and(
        eq(portfoliosTable.id, params.data.portfolioId),
        eq(portfoliosTable.creatorId, creator.id),
      ),
    )
    .returning({ id: portfoliosTable.id });

  if (!deleted.some(({ id }) => id === params.data.portfolioId)) {
    res.status(404).json({ error: "Portfolio project not found" });
    return;
  }

  res.status(204).send();
});

router.get("/portfolios/:portfolioId", async (req, res): Promise<void> => {
  const params = GetPortfolioParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const result = await db
    .select({ portfolio: portfoliosTable, creatorUsername: creatorsTable.username })
    .from(portfoliosTable)
    .innerJoin(creatorsTable, eq(portfoliosTable.creatorId, creatorsTable.id))
    .where(eq(portfoliosTable.id, params.data.portfolioId))
    .limit(1);

  if (!result[0]) {
    res.status(404).json({ error: "Portfolio project not found" });
    return;
  }

  res.json(
    GetPortfolioResponse.parse(
      portfolioResponse(result[0].portfolio, result[0].creatorUsername),
    ),
  );
});

export default router;