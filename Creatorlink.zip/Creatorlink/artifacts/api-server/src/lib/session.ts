import crypto from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { db, sessionsTable, usersTable } from "@workspace/db";

export function hashSessionToken(token: string): string {
  return crypto.createHash("sha256").update(token).digest("hex");
}

export async function getSessionUser(sessionToken: string) {
  if (!sessionToken) {
    return null;
  }

  const tokenHash = hashSessionToken(sessionToken);

  const [result] = await db
    .select({
      sessionId: sessionsTable.id,
      userId: usersTable.id,
      email: usersTable.email,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      role: usersTable.role,
      emailVerified: usersTable.emailVerified,
      expiresAt: sessionsTable.expiresAt,
    })
    .from(sessionsTable)
    .innerJoin(usersTable, eq(sessionsTable.userId, usersTable.id))
    .where(
      and(
        eq(sessionsTable.tokenHash, tokenHash),
        gt(sessionsTable.expiresAt, new Date()),
      ),
    )
    .limit(1);

  if (!result) {
    return null;
  }

  return {
    sessionId: result.sessionId,
    user: {
      id: result.userId,
      email: result.email,
      firstName: result.firstName,
      lastName: result.lastName,
      role: result.role,
      emailVerified: result.emailVerified,
    },
    expiresAt: result.expiresAt,
  };
}