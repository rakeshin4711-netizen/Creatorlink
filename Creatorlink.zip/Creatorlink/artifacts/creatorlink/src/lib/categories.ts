export const CATEGORIES = [
  "Video Editors",
  "UI/UX Designers",
  "Motion Designers",
  "Graphic Designers",
  "3D Artists",
  "Illustrators",
  "Photographers",
  "Copywriters",
  "Web Developers",
  "Brand Strategists",
] as const;