export type CurrencyCode = "INR" | "USD" | "EUR" | "GBP";

export const DEFAULT_CURRENCY: CurrencyCode = "INR";
export const DEFAULT_LOCALE = "en-IN";

const currencyLocales: Record<CurrencyCode, string> = {
  INR: "en-IN",
  USD: "en-US",
  EUR: "de-DE",
  GBP: "en-GB",
};

export type CurrencyFormatOptions = {
  currency?: CurrencyCode;
  locale?: string;
  minimumFractionDigits?: number;
  maximumFractionDigits?: number;
};

export function formatCurrency(
  amount: number,
  {
    currency = DEFAULT_CURRENCY,
    locale = currencyLocales[currency] ?? DEFAULT_LOCALE,
    minimumFractionDigits = 0,
    maximumFractionDigits = minimumFractionDigits,
  }: CurrencyFormatOptions = {},
) {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
    currencyDisplay: "symbol",
    minimumFractionDigits,
    maximumFractionDigits,
  }).format(amount);
}

export function formatHourlyRate(amount: number, options?: Omit<CurrencyFormatOptions, "minimumFractionDigits" | "maximumFractionDigits">) {
  return `${formatCurrency(amount, { ...options, minimumFractionDigits: 0, maximumFractionDigits: 0 })}/hr`;
}