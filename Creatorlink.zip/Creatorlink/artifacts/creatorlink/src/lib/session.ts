const SESSION_KEY = "creatorlink-session";

export type SessionRole = "client" | "creator";
export type Session = {
  role: SessionRole;
  username?: string;
};

export function createSession(
  role: SessionRole,
  username = role === "creator" ? "creator" : undefined,
  rememberMe = false,
) {
  const serialized = JSON.stringify({ role, username });
  localStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SESSION_KEY);
  (rememberMe ? localStorage : sessionStorage).setItem(SESSION_KEY, serialized);
}

export function getSession(): Session | null {
  const raw =
    localStorage.getItem(SESSION_KEY) ?? sessionStorage.getItem(SESSION_KEY);
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw) as Partial<Session>;
    if (parsed.role !== "client" && parsed.role !== "creator") return null;
    return {
      role: parsed.role,
      username: parsed.username,
    };
  } catch {
    return null;
  }
}

export function getSessionUsername() {
  return getSession()?.username ?? null;
}

export function updateSessionUsername(username: string) {
  const session = getSession();
  if (!session) return;
  const storage = localStorage.getItem(SESSION_KEY) !== null
    ? localStorage
    : sessionStorage;
  storage.setItem(SESSION_KEY, JSON.stringify({ ...session, username }));
}

export function hasSession() {
  return getSession() !== null;
}

export function clearSession() {
  localStorage.removeItem(SESSION_KEY);
  sessionStorage.removeItem(SESSION_KEY);
}