import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Hexagon } from "lucide-react";
import { useState, useEffect } from "react";

export function FloatingNav() {
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      className={`fixed top-4 left-0 right-0 z-50 flex justify-center px-4 transition-all duration-300 ${
        scrolled ? "top-2" : "top-4"
      }`}
    >
      <div className="w-full max-w-5xl glass-panel rounded-full px-6 py-3 flex items-center justify-between shadow-2xl border-white/20 dark:border-white/10">
        <Link href="/" className="flex items-center gap-2 group" data-testid="link-home">
          <div className="relative flex items-center justify-center w-8 h-8 rounded-lg bg-primary/10 text-primary group-hover:bg-primary group-hover:text-white transition-colors">
            <Hexagon className="w-5 h-5 absolute" />
          </div>
          <span className="font-bold text-lg tracking-tight">CreatorLink</span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          <Link href="/search" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-search">
            Find Talent
          </Link>
          <Link href="/search" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-pro">
            Pro Services
          </Link>
          <Link href="/blog" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors" data-testid="nav-blogs">
            Blogs
          </Link>
          <Link href="/design-system" className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors" data-testid="nav-design-system">
            Design System
          </Link>
        </nav>

        <div className="hidden md:flex items-center gap-4">
          <Link href="/login" className="text-sm font-medium hover:text-primary transition-colors" data-testid="nav-login">
            Log in
          </Link>
          <Link
            href="/signup"
            className="text-sm font-medium bg-foreground text-background dark:bg-white dark:text-black px-5 py-2.5 rounded-full hover:scale-105 transition-transform active:scale-95"
            data-testid="nav-signup"
          >
            Sign up
          </Link>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-foreground p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          data-testid="btn-mobile-menu"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu Dropdown */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="absolute top-20 left-4 right-4 glass-panel rounded-2xl p-6 flex flex-col gap-4 shadow-2xl md:hidden"
          >
            <Link href="/search" className="text-lg font-medium p-2 hover:bg-white/10 rounded-lg">Find Talent</Link>
            <Link href="/blog" className="text-lg font-medium p-2 hover:bg-white/10 rounded-lg">Blogs</Link>
            <Link href="/login" className="text-lg font-medium p-2 hover:bg-white/10 rounded-lg">Log in</Link>
            <Link href="/signup" className="text-lg font-medium p-2 bg-primary text-white rounded-lg text-center mt-4">Sign up</Link>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
