import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { LayoutDashboard, Users, MessageSquare, Briefcase, Bell, Settings, LogOut, Hexagon, FileText } from "lucide-react";
import {
  getGetCreatorProfileQueryKey,
  useGetCreatorProfile,
} from "@workspace/api-client-react";
import { clearSession, getSessionUsername } from "@/lib/session";

export function Sidebar({ role = "client" }: { role?: "client" | "creator" }) {
  const [location, setLocation] = useLocation();
  const username = getSessionUsername() ?? "creator";
  const { data: profile } = useGetCreatorProfile(username, {
    query: {
      enabled: role === "creator",
      queryKey: getGetCreatorProfileQueryKey(username),
    },
  });
  
  const clientLinks = [
    { name: "Dashboard", href: "/client-dashboard", icon: LayoutDashboard },
    { name: "Saved Talent", href: "/search", icon: Users },
    { name: "Projects", href: "/project/new", icon: Briefcase },
    { name: "Messages", href: "/chat", icon: MessageSquare },
    { name: "Notifications", href: "/notifications", icon: Bell },
  ];

  const creatorLinks = [
    { name: "Dashboard", href: "/creator-dashboard", icon: LayoutDashboard },
    { name: "My Profile", href: `/creator/${username}`, icon: Users },
    { name: "Projects", href: "/project/manage", icon: Briefcase },
    { name: "Articles", href: "/creatorlink/upload-blog", icon: FileText },
    { name: "Messages", href: "/chat", icon: MessageSquare },
    { name: "Notifications", href: "/notifications", icon: Bell },
  ];

  const links = role === "client" ? clientLinks : creatorLinks;

  return (
    <aside className="fixed left-0 top-0 bottom-0 w-64 glass-panel border-l-0 border-y-0 rounded-none flex flex-col z-40 hidden lg:flex">
      <div className="p-6 flex items-center gap-3">
        <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary/20 text-primary">
          <Hexagon className="w-5 h-5" />
        </div>
        <span className="font-bold text-xl tracking-tight text-glow">CreatorLink</span>
      </div>

      <div className="flex-1 px-4 py-6 space-y-1 overflow-y-auto">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-4 px-2">Menu</div>
        {links.map((link) => {
          const isActive = location === link.href || location.startsWith(`${link.href}/`);
          return (
            <Link
              key={link.name}
              href={link.href}
              className={cn(
                "flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all group relative overflow-hidden",
                isActive ? "text-white bg-white/10 shadow-[inset_0_1px_0_rgba(255,255,255,0.1)]" : "text-muted-foreground hover:text-foreground hover:bg-white/5"
              )}
              data-testid={`sidebar-${link.name.toLowerCase().replace(' ', '-')}`}
            >
              {isActive && (
                <div className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-8 bg-primary rounded-r-full shadow-[0_0_10px_rgba(108,92,231,0.8)]" />
              )}
              <div className="flex items-center gap-3 relative z-10">
                <link.icon className={cn("w-5 h-5", isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground")} />
                {link.name}
              </div>
            </Link>
          );
        })}
      </div>

      <div className="p-4 mt-auto space-y-1">
        <Link
          href="/settings"
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
            location.startsWith("/settings") ? "text-foreground bg-white/10" : "text-muted-foreground hover:text-foreground hover:bg-white/5"
          )}
        >
          <Settings className="w-5 h-5" />
          Settings
        </Link>
        <Link
          href="/billing"
          className={cn(
            "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
            location.startsWith("/billing") ? "text-foreground bg-white/10" : "text-muted-foreground hover:text-foreground hover:bg-white/5"
          )}
        >
          <Briefcase className="w-5 h-5" />
          Billing
        </Link>
      </div>

      <div className="p-4 border-t border-white/10">
        <div className="flex items-center gap-3 px-2">
          {profile?.profilePhoto ? (
            <img src={profile.profilePhoto} alt={profile.fullName} className="w-10 h-10 rounded-full border border-white/20" />
          ) : (
            <div className="w-10 h-10 rounded-full border border-white/20 bg-white/5" />
          )}
          <div className="flex-1 overflow-hidden">
            <div className="text-sm font-semibold truncate">{profile?.fullName ?? "Creator"}</div>
            <div className="text-xs text-muted-foreground truncate capitalize">{role}</div>
          </div>
          <button
            onClick={() => {
              clearSession();
              setLocation("/login");
            }}
            className="text-muted-foreground hover:text-destructive transition-colors p-1 rounded-md hover:bg-white/5"
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </aside>
  );
}
