import { Link } from "wouter";
import { Hexagon, Twitter, Instagram, Linkedin, ArrowRight } from "lucide-react";

export function Footer() {
  return (
    <footer className="relative border-t border-white/10 bg-black/40 dark:bg-black/60 backdrop-blur-3xl pt-20 pb-10 overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-2xl h-[1px] bg-gradient-to-r from-transparent via-primary to-transparent opacity-50" />
      
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 relative z-10">
        <div className="col-span-1 md:col-span-1 space-y-4">
          <Link href="/" className="flex items-center gap-2 group inline-flex">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-primary/20 text-primary">
              <Hexagon className="w-5 h-5" />
            </div>
            <span className="font-bold text-xl tracking-tight text-white">CreatorLink</span>
          </Link>
          <p className="text-muted-foreground text-sm leading-relaxed max-w-xs">
            The premium marketplace for elite creative talent. Where top-tier designers, editors, and artists meet visionary clients.
          </p>
          <div className="flex gap-4 pt-2">
            <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-white hover:border-primary transition-all">
              <Twitter className="w-4 h-4" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-white hover:border-primary transition-all">
              <Instagram className="w-4 h-4" />
            </a>
            <a href="#" className="w-10 h-10 rounded-full glass flex items-center justify-center text-muted-foreground hover:text-white hover:border-primary transition-all">
              <Linkedin className="w-4 h-4" />
            </a>
          </div>
        </div>

        <div className="space-y-4">
          <h4 className="font-semibold text-white">For Clients</h4>
          <ul className="space-y-3">
            <li><Link href="/search" className="text-sm text-muted-foreground hover:text-primary transition-colors">Find Talent</Link></li>
            <li><Link href="/pricing" className="text-sm text-muted-foreground hover:text-primary transition-colors">Enterprise</Link></li>
            <li><Link href="/how-it-works" className="text-sm text-muted-foreground hover:text-primary transition-colors">How it Works</Link></li>
            <li><Link href="/trust" className="text-sm text-muted-foreground hover:text-primary transition-colors">Trust & Safety</Link></li>
          </ul>
        </div>

        <div className="space-y-4">
          <h4 className="font-semibold text-white">For Creators</h4>
          <ul className="space-y-3">
            <li><Link href="/signup" className="text-sm text-muted-foreground hover:text-primary transition-colors">Join as Pro</Link></li>
            <li><Link href="/resources" className="text-sm text-muted-foreground hover:text-primary transition-colors">Creator Resources</Link></li>
            <li><Link href="/community" className="text-sm text-muted-foreground hover:text-primary transition-colors">Community</Link></li>
            <li><Link href="/guidelines" className="text-sm text-muted-foreground hover:text-primary transition-colors">Guidelines</Link></li>
          </ul>
        </div>

        <div className="space-y-4">
          <h4 className="font-semibold text-white">Stay Updated</h4>
          <p className="text-sm text-muted-foreground">Get the latest news and curated portfolios.</p>
          <div className="flex gap-2">
            <input 
              type="email" 
              placeholder="Enter your email" 
              className="bg-white/5 border border-white/10 rounded-full px-4 py-2 text-sm w-full focus:outline-none focus:border-primary transition-colors text-white placeholder:text-muted-foreground"
            />
            <button className="bg-primary hover:bg-primary/90 text-white rounded-full p-2 w-10 h-10 flex items-center justify-center shrink-0 transition-transform active:scale-95">
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
        <p>© 2024 CreatorLink. All rights reserved.</p>
        <div className="flex gap-6">
          <Link href="/privacy" className="hover:text-white transition-colors">Privacy Policy</Link>
          <Link href="/terms" className="hover:text-white transition-colors">Terms of Service</Link>
        </div>
      </div>
    </footer>
  );
}
