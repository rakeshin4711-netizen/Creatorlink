import React from "react";
import { FloatingNav } from "./FloatingNav";
import { Footer } from "./Footer";
import { motion } from "framer-motion";

interface MarketingLayoutProps {
  children: React.ReactNode;
}

export function MarketingLayout({ children }: MarketingLayoutProps) {
  return (
    <div className="min-h-screen flex flex-col relative overflow-hidden bg-background">
      {/* Global Ambient Orbs */}
      <div className="ambient-glow ambient-glow-primary -top-40 -left-40" />
      <div className="ambient-glow ambient-glow-accent top-1/4 -right-40" />
      
      <FloatingNav />
      <motion.main 
        className="flex-1 w-full"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
      >
        {children}
      </motion.main>
      <Footer />
    </div>
  );
}
