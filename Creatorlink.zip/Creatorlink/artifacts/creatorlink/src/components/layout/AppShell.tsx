import React from "react";
import { Sidebar } from "./Sidebar";
import { motion } from "framer-motion";
import { useLocation } from "wouter";

interface AppShellProps {
  children: React.ReactNode;
  role?: "client" | "creator";
}

export function AppShell({ children, role = "client" }: AppShellProps) {
  const [location] = useLocation();

  return (
    <div className="min-h-screen flex bg-background relative overflow-hidden">
      {/* Dashboard Ambient Background */}
      <div className="absolute top-0 right-0 w-full h-[300px] bg-gradient-to-b from-primary/10 to-transparent pointer-events-none opacity-50" />
      <div className="ambient-glow ambient-glow-primary -top-40 -right-40" />
      
      <Sidebar role={role} />
      
      <main className="flex-1 lg:pl-64 flex flex-col min-h-screen relative z-10">
        <motion.div
          key={location}
          initial={{ opacity: 0, y: 10, filter: "blur(4px)" }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          exit={{ opacity: 0, y: -10, filter: "blur(4px)" }}
          transition={{ duration: 0.4, ease: "easeOut" }}
          className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full"
        >
          {children}
        </motion.div>
      </main>
    </div>
  );
}
