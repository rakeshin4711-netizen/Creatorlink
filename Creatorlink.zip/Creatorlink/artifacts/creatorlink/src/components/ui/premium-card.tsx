import { cn } from "@/lib/utils";
import React from "react";

interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  glow?: "primary" | "accent" | "none";
  tilt?: boolean;
}

export function PremiumCard({
  className,
  children,
  glow = "none",
  tilt = true,
  ...props
}: CardProps) {
  return (
    <div
      className={cn(
        "group relative rounded-2xl glass-panel overflow-hidden spatial-lift",
        className
      )}
      {...props}
    >
      {/* Ambient Inner Glow */}
      {glow !== "none" && (
        <div
          className={cn(
            "absolute -top-24 -right-24 w-48 h-48 rounded-full blur-[80px] opacity-20 transition-opacity group-hover:opacity-40",
            glow === "primary" ? "bg-primary" : "bg-accent"
          )}
        />
      )}
      
      {/* Subdued Border Highlight */}
      <div className="absolute inset-0 rounded-2xl border border-white/10 dark:border-white/5 pointer-events-none" />
      
      <div className="relative z-10">{children}</div>
    </div>
  );
}
