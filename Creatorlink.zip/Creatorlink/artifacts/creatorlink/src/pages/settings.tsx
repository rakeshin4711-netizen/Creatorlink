import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Save, Bell, Shield, Paintbrush, CreditCard, ImagePlus } from "lucide-react";
import { useTheme } from "@/hooks/use-theme";
import { useEffect, useState } from "react";
import { Link } from "wouter";
import {
  getGetCreatorProfileQueryKey,
  useGetCreatorProfile,
  useUpsertCreatorProfile,
  type CreatorProfileInput,
} from "@workspace/api-client-react";
import { CATEGORIES } from "@/lib/categories";
import {
  getSession,
  getSessionUsername,
  updateSessionUsername,
} from "@/lib/session";

const emptyProfile = (username: string): CreatorProfileInput => ({
  username,
  profilePhoto: "",
  fullName: "",
  bio: "",
  skills: [],
  experience: "",
  category: "",
  hourlyRate: 0,
  location: "",
  socialLinks: {
    website: "",
    instagram: "",
    linkedin: "",
    twitter: "",
  },
});

export default function Settings() {
  const { theme, setTheme } = useTheme();
  const session = getSession();
  const isCreator = session?.role === "creator";
  const [activeTab, setActiveTab] = useState(() =>
    new URLSearchParams(window.location.search).get("tab") === "profile"
      ? "profile"
      : "appearance",
  );
  const [identifier, setIdentifier] = useState(getSessionUsername() ?? "creator");
  const [profileForm, setProfileForm] = useState(() => emptyProfile(identifier));
  const [profileMessage, setProfileMessage] = useState("");
  const profileQuery = useGetCreatorProfile(identifier, {
    query: {
      enabled: isCreator,
      queryKey: getGetCreatorProfileQueryKey(identifier),
    },
  });
  const saveProfile = useUpsertCreatorProfile();

  useEffect(() => {
    if (!profileQuery.data) return;
    setProfileForm({
      ...profileQuery.data,
      socialLinks: {
        website: "",
        instagram: "",
        linkedin: "",
        twitter: "",
        ...profileQuery.data.socialLinks,
      },
    });
  }, [profileQuery.data]);

  const updateProfileField = <K extends keyof CreatorProfileInput>(
    field: K,
    value: CreatorProfileInput[K],
  ) => {
    setProfileForm((current) => ({ ...current, [field]: value }));
  };

  const updateSocialLink = (field: string, value: string) => {
    setProfileForm((current) => ({
      ...current,
      socialLinks: { ...current.socialLinks, [field]: value },
    }));
  };

  const handleProfileSave = (event: React.FormEvent) => {
    event.preventDefault();
    setProfileMessage("");
    if (!profileForm.username.trim() || !profileForm.fullName.trim()) {
      setProfileMessage("Username and full name are required.");
      return;
    }

    saveProfile.mutate(
      {
        identifier,
        data: {
          ...profileForm,
          username: profileForm.username.trim(),
          fullName: profileForm.fullName.trim(),
          hourlyRate: Number(profileForm.hourlyRate) || 0,
          skills: profileForm.skills.map((skill) => skill.trim()).filter(Boolean),
        },
      },
      {
        onSuccess: (saved) => {
          updateSessionUsername(saved.username);
          setIdentifier(saved.username);
          setProfileForm(saved);
          setProfileMessage("Profile saved.");
        },
        onError: () => setProfileMessage("Unable to save your profile. Please try again."),
      },
    );
  };

  return (
    <AppShell>
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tight mb-8">Settings</h1>
        
        <div className="flex flex-col md:flex-row gap-8">
          {/* Tabs Sidebar */}
          <div className="w-full md:w-64 space-y-1 shrink-0">
            {[
              { id: 'profile', label: 'Profile', icon: Save },
              { id: 'appearance', label: 'Appearance', icon: Paintbrush },
              { id: 'notifications', label: 'Notifications', icon: Bell },
              { id: 'security', label: 'Security', icon: Shield },
              { id: 'billing', label: 'Billing', icon: CreditCard },
            ].map((tab) => (
              <button 
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-colors ${activeTab === tab.id ? 'bg-primary/20 text-primary border border-primary/20' : 'text-muted-foreground hover:bg-white/5 hover:text-foreground'}`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>

          <div className="flex-1 space-y-6">
            {activeTab === "profile" ? (
              <form onSubmit={handleProfileSave} className="space-y-6">
                <PremiumCard className="p-6">
                  <div className="flex items-center justify-between gap-4 mb-6">
                    <div>
                      <h2 className="text-xl font-bold">Creator Profile</h2>
                      <p className="text-sm text-muted-foreground mt-1">Update the information clients see on your public profile.</p>
                    </div>
                    <ImagePlus className="w-5 h-5 text-primary" />
                  </div>

                  <div className="space-y-5">
                    <div className="flex items-center gap-4">
                      {profileForm.profilePhoto ? (
                        <img src={profileForm.profilePhoto} alt="" className="w-16 h-16 rounded-2xl object-cover border border-white/10" />
                      ) : (
                        <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                          <ImagePlus className="w-5 h-5 text-muted-foreground" />
                        </div>
                      )}
                      <div className="flex-1 space-y-2">
                        <label className="text-sm font-medium">Photo</label>
                        <input
                          type="url"
                          value={profileForm.profilePhoto}
                          onChange={(event) => updateProfileField("profilePhoto", event.target.value)}
                          placeholder="https://example.com/profile-photo.jpg"
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Name</label>
                        <input
                          required
                          value={profileForm.fullName}
                          onChange={(event) => updateProfileField("fullName", event.target.value)}
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Username</label>
                        <input
                          required
                          value={profileForm.username}
                          onChange={(event) => updateProfileField("username", event.target.value.replace(/\s+/g, "-").toLowerCase())}
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Bio</label>
                      <textarea
                        value={profileForm.bio}
                        onChange={(event) => updateProfileField("bio", event.target.value)}
                        rows={4}
                        className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all resize-none"
                      />
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Skills</label>
                      <input
                        value={profileForm.skills.join(", ")}
                        onChange={(event) => updateProfileField("skills", event.target.value.split(","))}
                        placeholder="Motion Design, Video Editing, 3D"
                        className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                      />
                      <p className="text-xs text-muted-foreground">Separate skills with commas.</p>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Experience</label>
                        <textarea
                          value={profileForm.experience}
                          onChange={(event) => updateProfileField("experience", event.target.value)}
                          rows={4}
                          className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all resize-none"
                        />
                      </div>
                      <div className="space-y-4">
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Category</label>
                          <select
                            value={profileForm.category}
                            onChange={(event) => updateProfileField("category", event.target.value)}
                            className="w-full h-11 px-4 rounded-xl bg-background border border-white/10 focus:border-primary outline-none transition-all"
                          >
                            <option value="">Select a category</option>
                            {CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}
                          </select>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Rate</label>
                          <input
                            type="number"
                            min={0}
                            value={profileForm.hourlyRate}
                            onChange={(event) => updateProfileField("hourlyRate", Number(event.target.value))}
                            className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium">Location</label>
                      <input
                        value={profileForm.location}
                        onChange={(event) => updateProfileField("location", event.target.value)}
                        className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                      />
                    </div>

                    <div className="pt-5 border-t border-white/10 space-y-4">
                      <h3 className="text-sm font-medium">Social links</h3>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {["website", "instagram", "linkedin", "twitter"].map((network) => (
                          <input
                            key={network}
                            type="url"
                            value={profileForm.socialLinks[network] ?? ""}
                            onChange={(event) => updateSocialLink(network, event.target.value)}
                            placeholder={`${network[0].toUpperCase()}${network.slice(1)} URL`}
                            className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </PremiumCard>

                <div className="flex items-center justify-end gap-3">
                  {profileMessage && <span className="text-sm text-muted-foreground">{profileMessage}</span>}
                  {profileForm.username && <Link href={`/creator/${profileForm.username}`} className="text-sm text-primary hover:underline">View public profile</Link>}
                  <PremiumButton type="submit" glow disabled={saveProfile.isPending}>
                    {saveProfile.isPending ? "Saving..." : "Save Profile"}
                  </PremiumButton>
                </div>
              </form>
            ) : (
            <PremiumCard className="p-6">
              <h2 className="text-xl font-bold mb-6">Appearance</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="text-sm font-medium mb-3">Theme Preference</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <button 
                      onClick={() => setTheme('light')}
                      className={`p-4 rounded-xl border text-left transition-all ${theme === 'light' ? 'border-primary bg-primary/10' : 'border-white/10 bg-white/5 hover:border-white/30'}`}
                    >
                      <div className="w-full h-24 bg-white rounded-lg border border-gray-200 mb-3 p-2 shadow-sm">
                        <div className="w-full h-2 bg-gray-200 rounded mb-2" />
                        <div className="w-2/3 h-2 bg-gray-200 rounded" />
                      </div>
                      <div className="font-medium text-sm">Light</div>
                    </button>
                    
                    <button 
                      onClick={() => setTheme('dark')}
                      className={`p-4 rounded-xl border text-left transition-all ${theme === 'dark' ? 'border-primary bg-primary/10' : 'border-white/10 bg-white/5 hover:border-white/30'}`}
                    >
                      <div className="w-full h-24 bg-[#0F172A] rounded-lg border border-[#1E293B] mb-3 p-2 shadow-sm">
                        <div className="w-full h-2 bg-[#1E293B] rounded mb-2" />
                        <div className="w-2/3 h-2 bg-primary/50 rounded" />
                      </div>
                      <div className="font-medium text-sm">Dark</div>
                    </button>

                    <button 
                      onClick={() => setTheme('system')}
                      className={`p-4 rounded-xl border text-left transition-all ${theme === 'system' ? 'border-primary bg-primary/10' : 'border-white/10 bg-white/5 hover:border-white/30'}`}
                    >
                      <div className="w-full h-24 bg-gradient-to-r from-white to-[#0F172A] rounded-lg border border-white/10 mb-3 p-2 flex overflow-hidden">
                        <div className="w-1/2 h-full bg-white relative">
                           <div className="absolute top-2 left-2 right-2 h-2 bg-gray-200 rounded" />
                        </div>
                        <div className="w-1/2 h-full bg-[#0F172A] relative">
                           <div className="absolute top-4 left-2 right-2 h-2 bg-[#1E293B] rounded" />
                        </div>
                      </div>
                      <div className="font-medium text-sm">System</div>
                    </button>
                  </div>
                </div>

                <div className="pt-6 border-t border-white/10">
                  <h3 className="text-sm font-medium mb-3">Accent Color</h3>
                  <p className="text-sm text-muted-foreground mb-4">Choose a primary accent color for your dashboard.</p>
                  <div className="flex gap-3">
                    {['#6C5CE7', '#00D2FF', '#10B981', '#F59E0B', '#EF4444'].map((color, i) => (
                      <button 
                        key={color}
                        className={`w-10 h-10 rounded-full flex items-center justify-center transition-transform hover:scale-110 ${i === 0 ? 'ring-2 ring-white ring-offset-2 ring-offset-background' : ''}`}
                        style={{ backgroundColor: color }}
                      >
                        {i === 0 && <div className="w-2 h-2 bg-white rounded-full" />}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </PremiumCard>
            )}
            
            {activeTab !== "profile" && (
              <div className="flex justify-end gap-3">
                <PremiumButton variant="ghost">Cancel</PremiumButton>
                <PremiumButton glow>Save Preferences</PremiumButton>
              </div>
            )}
          </div>
        </div>
      </div>
    </AppShell>
  );
}
