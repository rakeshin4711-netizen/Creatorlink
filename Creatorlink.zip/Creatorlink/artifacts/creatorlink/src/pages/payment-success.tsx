import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { CheckCircle2, Download } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  getGetPaymentByPaymentIdQueryKey,
  useGetPaymentByPaymentId,
} from "@workspace/api-client-react";
import { useSearch } from "wouter";
import { formatCurrency } from "@/lib/currency";

export default function PaymentSuccess() {
  const search = useSearch();
  const paymentId = new URLSearchParams(search).get("paymentId") ?? "";
  const paymentQuery = useGetPaymentByPaymentId(paymentId, {
    query: {
      enabled: Boolean(paymentId),
      queryKey: getGetPaymentByPaymentIdQueryKey(paymentId),
      retry: false,
    },
  });
  const payment = paymentQuery.data;

  return (
    <AppShell>
      <div className="min-h-[70vh] flex flex-col items-center justify-center relative">
        <div className="ambient-glow ambient-glow-primary opacity-40 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: "spring", stiffness: 200, damping: 20 }}
          className="w-24 h-24 rounded-full bg-green-500/20 text-green-500 flex items-center justify-center mb-8 relative z-10 shadow-[0_0_50px_rgba(16,185,129,0.3)]"
        >
          <CheckCircle2 className="w-12 h-12" />
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="text-center relative z-10 w-full max-w-md"
        >
          <h1 className="text-4xl font-bold mb-4 tracking-tight">Payment Successful</h1>
          <p className="text-muted-foreground text-lg mb-8">
            Your project has been funded. The creator will be notified immediately to begin work.
          </p>
          
          <PremiumCard className="p-6 mb-8 text-left bg-black/20 border-white/10">
            {payment ? (
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Amount</span>
                  <span className="font-semibold">{formatCurrency(payment.amount)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Status</span>
                  <span className="font-semibold capitalize">{payment.status}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground">Payment ID</span>
                  <span className="font-mono text-xs break-all text-right">{payment.paymentId}</span>
                </div>
                <div className="flex justify-between gap-4">
                  <span className="text-muted-foreground">Invoice</span>
                  <span className="font-mono text-xs break-all text-right">{payment.invoiceNumber}</span>
                </div>
              </div>
            ) : (
              <div className="text-center text-sm text-muted-foreground">
                {paymentQuery.isLoading ? "Loading payment details..." : "Payment details are unavailable."}
              </div>
            )}
          </PremiumCard>
          
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link href="/project/manage">
              <PremiumButton glow className="w-full sm:w-auto">Go to Project</PremiumButton>
            </Link>
            <PremiumButton variant="outline" className="w-full sm:w-auto bg-white/5">
              <Download className="w-4 h-4 mr-2" /> Download Receipt
            </PremiumButton>
          </div>
        </motion.div>
      </div>
    </AppShell>
  );
}
