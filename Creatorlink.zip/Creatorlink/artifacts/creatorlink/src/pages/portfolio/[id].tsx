import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import {
  getGetPortfolioQueryKey,
  useGetPortfolio,
} from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Heart, Share2, MessageSquare, ArrowLeft } from "lucide-react";
import NotFound from "@/pages/not-found";

export default function PortfolioDetails() {
  const { id } = useParams();
  const portfolioId = Number(id);
  const portfolioQuery = useGetPortfolio(portfolioId, {
    query: {
      enabled: Number.isInteger(portfolioId) && portfolioId > 0,
      queryKey: getGetPortfolioQueryKey(portfolioId),
      retry: false,
    },
  });

  if (portfolioQuery.isLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  if (portfolioQuery.isError || !portfolioQuery.data) {
    return <NotFound />;
  }

  const portfolio = portfolioQuery.data;

  return (
    <AppShell role="client">
      <Link href={`/creator/${portfolio.creatorUsername}`} className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-white transition-colors mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to Profile
      </Link>
      
      <div className="w-full aspect-[21/9] rounded-3xl overflow-hidden mb-8 relative group">
        {portfolio.images[0] ? (
          <img src={portfolio.images[0]} alt={portfolio.title} className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/30 to-accent/20" />
        )}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-8">
          <div className="flex gap-4">
             <PremiumButton variant="secondary" className="bg-white/20 backdrop-blur-md text-white border-white/10 hover:bg-white/30">
               <Heart className="w-4 h-4 mr-2" /> Like
             </PremiumButton>
             <PremiumButton variant="secondary" className="bg-white/20 backdrop-blur-md text-white border-white/10 hover:bg-white/30">
               <Share2 className="w-4 h-4 mr-2" /> Share
             </PremiumButton>
          </div>
        </div>
      </div>

      {portfolio.images.length > 1 && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {portfolio.images.slice(1).map((image, index) => (
            <div key={`${image.slice(0, 24)}-${index}`} className="aspect-video rounded-2xl overflow-hidden border border-white/10">
              <img src={image} alt={`${portfolio.title} ${index + 2}`} className="w-full h-full object-cover" />
            </div>
          ))}
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          <div>
            <h1 className="text-3xl font-bold mb-4">{portfolio.title}</h1>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {portfolio.description}
            </p>
          </div>
          
          <div className="space-y-6 pt-8 border-t border-white/10">
            <h3 className="text-xl font-bold">Comments</h3>
            
            <div className="flex gap-4">
              <div className="w-10 h-10 rounded-full bg-primary/20 border border-white/10 shrink-0" />
              <div className="flex-1 flex gap-2">
                <input type="text" placeholder="Add a comment..." className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 text-sm outline-none focus:border-primary" />
                <PremiumButton glow>Post</PremiumButton>
              </div>
            </div>

            <div className="pt-4 text-sm text-muted-foreground">No comments yet.</div>
          </div>
        </div>

        <div>
          <PremiumCard className="p-6 sticky top-6">
            <h3 className="font-bold mb-4">Project Details</h3>
            
            <div className="space-y-4 mb-6">
              <div>
                <div className="text-xs text-muted-foreground mb-1">Category</div>
                <div className="font-medium text-sm">{portfolio.category || "Uncategorized"}</div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1">Skills</div>
                <div className="flex flex-wrap gap-2 mt-2">
                  {portfolio.skills.map((skill) => (
                    <span key={skill} className="text-xs px-2 py-1 bg-white/5 border border-white/10 rounded">{skill}</span>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="pt-6 border-t border-white/10">
              <Link href={`/creator/${portfolio.creatorUsername}`}>
                <PremiumButton glow className="w-full">View Creator Profile</PremiumButton>
              </Link>
            </div>
          </PremiumCard>
        </div>
      </div>
    </AppShell>
  );
}
