import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Clock, Calendar } from "lucide-react";
import { Link, useParams } from "wouter";
import { getGetClientProjectQueryKey, useCreateMockPayment, useGetClientProject } from "@workspace/api-client-react";
import NotFound from "@/pages/not-found";
import { formatCurrency } from "@/lib/currency";
import { getSessionUsername } from "@/lib/session";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

function formatDeadline(deadline: string) {
  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(new Date(`${deadline}T00:00:00`));
}

export default function ProjectDetails() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const projectId = Number(id);
  const projectQuery = useGetClientProject(projectId, {
    query: {
      enabled: Number.isInteger(projectId) && projectId > 0,
      queryKey: getGetClientProjectQueryKey(projectId),
      retry: false,
    },
  });
  const createPayment = useCreateMockPayment();

  if (projectQuery.isLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  if (projectQuery.isError || !projectQuery.data) {
    return <NotFound />;
  }

  const project = projectQuery.data;

  return (
    <AppShell role="client">
      <div className="max-w-5xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-3">
              <span className="px-3 py-1 bg-primary/20 text-primary text-xs font-bold uppercase tracking-wider rounded-full">Open</span>
              <span className="text-muted-foreground text-sm font-medium flex items-center gap-1">
                <Clock className="w-4 h-4" /> {formatDeadline(project.deadline)}
              </span>
            </div>
            <h1 className="text-3xl md:text-4xl font-bold tracking-tight mb-2">{project.title}</h1>
            <p className="text-muted-foreground">Project details</p>
          </div>

          <div className="flex gap-3">
            <Link href="/chat">
              <PremiumButton variant="outline" className="bg-white/5">Message Creator</PremiumButton>
            </Link>
            <PremiumButton
              glow
              disabled={createPayment.isPending}
              onClick={async () => {
                try {
                  const payment = await createPayment.mutateAsync({
                    data: {
                      projectId: project.id,
                      clientIdentifier: getSessionUsername() ?? project.clientIdentifier,
                      outcome: "success",
                    },
                  });
                  setLocation(`/payment-success?paymentId=${encodeURIComponent(payment.paymentId)}`);
                } catch (error) {
                  toast({
                    title: "Payment failed",
                    description: error instanceof Error ? error.message : "Please try again.",
                    variant: "destructive",
                  });
                }
              }}
            >
              Release Payment
            </PremiumButton>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-6">
            <PremiumCard className="p-6 md:p-8">
              <h2 className="text-xl font-bold mb-4">Requirements &amp; Scope</h2>
              <div className="prose prose-invert max-w-none text-muted-foreground whitespace-pre-line">
                {project.description || "No description has been added yet."}
              </div>

              <div className="mt-8 pt-6 border-t border-white/10">
                <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider">Attachments</h3>
                <div className="text-sm text-muted-foreground">No attachments yet.</div>
              </div>
            </PremiumCard>

            <PremiumCard className="p-6 md:p-8">
              <h2 className="text-xl font-bold mb-6">Milestones</h2>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Calendar className="w-5 h-5" />
                <span>No milestones have been added yet.</span>
              </div>
            </PremiumCard>
          </div>

          <div className="space-y-6">
            <PremiumCard className="p-6 border-primary/20 bg-gradient-to-b from-primary/5 to-transparent">
              <h3 className="font-bold mb-4">Summary</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Category</span>
                  <span className="font-medium">{project.category || "Not specified"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">Budget</span>
                  <span className="font-bold">{formatCurrency(project.budget)}</span>
                </div>
                <div className="flex justify-between pt-3 border-t border-white/10">
                  <span className="text-muted-foreground">Payment data</span>
                  <span className="font-medium text-muted-foreground">Not available</span>
                </div>
              </div>
            </PremiumCard>

            <PremiumCard className="p-6">
              <h3 className="font-bold mb-4">Talent</h3>
              <div className="text-sm text-muted-foreground">No creator assigned yet.</div>
            </PremiumCard>
          </div>
        </div>
      </div>
    </AppShell>
  );
}