import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import {
  getGetCreatorProfileQueryKey,
  getListCreatorPortfoliosQueryKey,
  useCreateClientProject,
  useGetCreatorProfile,
  useListCreatorPortfolios,
} from "@workspace/api-client-react";
import { useParams, Link, useLocation } from "wouter";
import { MapPin, Clock, CheckCircle2, MessageSquare, Play, Globe, Instagram, Linkedin, Twitter } from "lucide-react";
import { motion } from "framer-motion";
import NotFound from "@/pages/not-found";
import { formatCurrency } from "@/lib/currency";
import { getSessionUsername } from "@/lib/session";
import { useToast } from "@/hooks/use-toast";

export default function CreatorProfile() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createProject = useCreateClientProject();
  const profileQuery = useGetCreatorProfile(id ?? "", {
    query: {
      enabled: Boolean(id),
      queryKey: getGetCreatorProfileQueryKey(id ?? ""),
    },
  });
  const creatorUsername = profileQuery.data?.username ?? id ?? "";
  const portfoliosQuery = useListCreatorPortfolios(creatorUsername, {
    query: {
      enabled: Boolean(profileQuery.data),
      queryKey: getListCreatorPortfoliosQueryKey(creatorUsername),
      retry: false,
    },
  });

  if (profileQuery.isLoading) {
    return <div className="min-h-screen bg-background" />;
  }

  if (profileQuery.isError || !profileQuery.data) {
    return <NotFound />;
  }

  const creator = profileQuery.data;
  const socialIcons = { website: Globe, instagram: Instagram, linkedin: Linkedin, twitter: Twitter };
  const handleHire = async () => {
    try {
      const deadline = new Date();
      deadline.setDate(deadline.getDate() + 30);
      const project = await createProject.mutateAsync({
        data: {
          clientIdentifier: getSessionUsername() ?? "client",
          creatorIdentifier: creator.username,
          title: `Hire ${creator.fullName}`,
          description: `Direct hire for ${creator.fullName}.`,
          category: creator.category || "Creative Services",
          budget: Math.max(0, creator.hourlyRate),
          deadline: deadline.toISOString().slice(0, 10),
          skills: creator.skills,
          status: "pending",
        },
      });
      toast({
        title: "Project created",
        description: "Your project is ready for payment.",
      });
      setLocation(`/project/${project.id}`);
    } catch (error) {
      toast({
        title: "Unable to create project",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    }
  };

  return (
    <AppShell role="client">
      {/* Cover Image & Header */}
      <div className="relative h-64 md:h-80 rounded-3xl overflow-hidden mb-24">
        <div className="w-full h-full bg-gradient-to-br from-primary/40 via-background to-accent/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/20 to-transparent" />
        
        {/* Floating Avatar Card */}
        <PremiumCard className="absolute -bottom-16 left-8 md:left-12 p-2 rounded-2xl flex items-center gap-6 bg-background/80 backdrop-blur-2xl border-white/10 shadow-2xl">
          {creator.profilePhoto ? (
            <img src={creator.profilePhoto} alt={creator.fullName} className="w-24 h-24 md:w-32 md:h-32 rounded-xl object-cover" />
          ) : (
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-xl bg-primary/20 flex items-center justify-center text-3xl font-bold text-primary">
              {creator.fullName.slice(0, 1).toUpperCase()}
            </div>
          )}
          <div className="pr-8 pb-2">
            <h1 className="text-2xl md:text-3xl font-bold">{creator.fullName}</h1>
            <p className="text-primary font-medium">{creator.category || "Creator"}</p>
            <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
              {creator.location && <span className="flex items-center gap-1"><MapPin className="w-4 h-4" /> {creator.location}</span>}
              <span className="text-muted-foreground">@{creator.username}</span>
            </div>
          </div>
        </PremiumCard>
      </div>

      <div className="grid lg:grid-cols-3 gap-8 px-4 md:px-8 relative z-10">
        <div className="lg:col-span-2 space-y-12">
          
          {/* About */}
          <section>
            <h2 className="text-xl font-bold mb-4">About</h2>
            <p className="text-muted-foreground leading-relaxed text-lg">
              {creator.bio}
            </p>
            <div className="flex flex-wrap gap-2 mt-6">
              {creator.skills.map(skill => (
                <span key={skill} className="px-3 py-1 rounded-full bg-white/5 border border-white/10 text-sm font-medium">
                  {skill}
                </span>
              ))}
            </div>
            {creator.experience && (
              <div className="mt-8">
                <h3 className="font-semibold mb-2">Experience</h3>
                <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{creator.experience}</p>
              </div>
            )}
            <div className="flex flex-wrap gap-3 mt-6">
              {Object.entries(creator.socialLinks).filter(([, url]) => url).map(([network, url]) => {
                const Icon = socialIcons[network as keyof typeof socialIcons] ?? Globe;
                return <a key={network} href={url} target="_blank" rel="noreferrer" className="text-primary hover:text-accent transition-colors"><Icon className="w-5 h-5" /></a>;
              })}
            </div>
          </section>

          {/* Portfolio Grid */}
          <section>
            <h2 className="text-xl font-bold mb-6">Portfolio</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {portfoliosQuery.data?.length ? portfoliosQuery.data.map((item, i) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link href={`/portfolio/${item.id}`}>
                    <PremiumCard className="relative aspect-video overflow-hidden group cursor-pointer border-white/10">
                      {item.images[0] ? (
                        <img src={item.images[0]} alt={item.title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-primary/20 to-accent/20" />
                      )}
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center p-4">
                        <div className="w-12 h-12 rounded-full bg-primary flex items-center justify-center text-white mb-2 scale-50 group-hover:scale-100 transition-transform duration-300 ease-out">
                          <Play className="w-5 h-5 ml-1" />
                        </div>
                        <h3 className="text-white font-bold text-lg text-center translate-y-4 group-hover:translate-y-0 transition-transform duration-300">{item.title}</h3>
                      </div>
                    </PremiumCard>
                  </Link>
                </motion.div>
              )) : (
                <PremiumCard className="p-6 border-dashed border-white/10 text-muted-foreground">
                  No portfolio items have been added yet.
                </PremiumCard>
              )}
            </div>
          </section>
        </div>

        {/* Right Sidebar - Pricing & CTAs */}
        <div className="space-y-6">
          <PremiumCard className="p-6 sticky top-24 border-primary/20 bg-gradient-to-b from-primary/5 to-transparent">
            <div className="flex items-center gap-2 text-green-500 text-sm font-medium mb-6 bg-green-500/10 w-max px-3 py-1 rounded-full">
              <CheckCircle2 className="w-4 h-4" /> Available for projects
            </div>
            
            <h3 className="font-bold text-2xl mb-1">{formatCurrency(creator.hourlyRate)} <span className="text-muted-foreground text-sm font-normal">/ hour</span></h3>
            
            <div className="space-y-3 mt-6 mb-8">
              <PremiumButton
                glow
                className="w-full shadow-primary/30"
                disabled={createProject.isPending}
                onClick={handleHire}
              >
                Hire {creator.fullName.split(' ')[0]}
              </PremiumButton>
              <Link href={`/chat?with=${encodeURIComponent(creator.username)}`}>
                <PremiumButton variant="outline" className="w-full bg-white/5">
                  <MessageSquare className="w-4 h-4 mr-2" /> Message
                </PremiumButton>
              </Link>
            </div>

            <div className="border-t border-white/10 pt-6">
              <h4 className="font-semibold mb-4 text-sm uppercase tracking-wider text-muted-foreground">Fixed Packages</h4>
              <div className="space-y-3">
                <div className="p-4 rounded-xl border border-dashed border-white/10 text-sm text-muted-foreground">
                  No fixed packages have been added yet.
                </div>
              </div>
            </div>
          </PremiumCard>
        </div>
      </div>
    </AppShell>
  );
}
