import { useState } from "react";
import { AlertTriangle, ArrowLeft, Check, ShieldAlert, Trash2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import {
  getGetCreatorProfileQueryKey,
  getListCreatorPortfoliosQueryKey,
  useDeleteCreatorProfile,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { useToast } from "@/hooks/use-toast";
import { getSessionUsername } from "@/lib/session";

const removedData = [
  "Creator profile",
  "Portfolio projects and images",
  "Skills and experience",
  "Pricing and availability",
  "Social links",
  "Profile photo",
];

export default function DeleteProfile() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const identifier = getSessionUsername() ?? "creator";
  const [deleteText, setDeleteText] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const deleteProfile = useDeleteCreatorProfile();
  const canDelete = deleteText === "DELETE" && confirmed;

  const handleDelete = () => {
    if (!canDelete || deleteProfile.isPending) return;

    deleteProfile.mutate(
      { identifier },
      {
        onSuccess: () => {
          queryClient.removeQueries({ queryKey: getGetCreatorProfileQueryKey(identifier) });
          queryClient.removeQueries({ queryKey: getListCreatorPortfoliosQueryKey(identifier) });
          toast({
            title: "Creator profile deleted",
            description: "Your account is still active. You can create a new creator profile later.",
          });
          setIsModalOpen(false);
          window.setTimeout(() => setLocation("/dashboard"), 700);
        },
        onError: () => {
          setIsModalOpen(false);
          toast({
            title: "Unable to delete creator profile",
            description: "Please try again. Your profile and account were not changed.",
            variant: "destructive",
          });
        },
      },
    );
  };

  return (
    <>
      <AppShell role="creator">
        <div className="max-w-3xl mx-auto">
          <Link
            href="/settings"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-6"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Settings
          </Link>

          <div className="mb-8">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-11 h-11 rounded-xl bg-destructive/15 border border-destructive/25 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5 text-destructive" />
              </div>
              <div>
                <h1 className="text-3xl font-bold tracking-tight">Delete Creator Profile</h1>
                <p className="text-sm text-muted-foreground mt-1">This action affects your creator profile only.</p>
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <PremiumCard className="p-5 sm:p-6 border-destructive/30 bg-destructive/5">
              <div className="flex items-start gap-3">
                <AlertTriangle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
                <div className="space-y-2">
                  <h2 className="font-bold">This cannot be undone</h2>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    Deleting your creator profile permanently removes the creator information below.
                    Your account will remain active, and you can create a new creator profile later.
                  </p>
                </div>
              </div>
            </PremiumCard>

            <PremiumCard className="p-5 sm:p-6">
              <h2 className="text-lg font-bold mb-4">Data that will be removed</h2>
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {removedData.map((item) => (
                  <li key={item} className="flex items-center gap-2 text-sm text-muted-foreground">
                    <span className="w-5 h-5 rounded-full bg-destructive/15 text-destructive flex items-center justify-center shrink-0">
                      <Trash2 className="w-3 h-3" />
                    </span>
                    {item}
                  </li>
                ))}
              </ul>
            </PremiumCard>

            <PremiumCard className="p-5 sm:p-6">
              <div className="space-y-5">
                <div className="space-y-2">
                  <label htmlFor="delete-profile-confirmation" className="text-sm font-medium">
                    Type <span className="font-bold text-destructive">DELETE</span> to continue
                  </label>
                  <input
                    id="delete-profile-confirmation"
                    type="text"
                    value={deleteText}
                    onChange={(event) => setDeleteText(event.target.value)}
                    placeholder="DELETE"
                    autoComplete="off"
                    className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-destructive focus:ring-1 focus:ring-destructive outline-none transition-all"
                  />
                </div>

                <label className="flex items-start gap-3 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmed}
                    onChange={(event) => setConfirmed(event.target.checked)}
                    className="mt-0.5 h-4 w-4 accent-destructive"
                  />
                  <span className="text-sm text-muted-foreground leading-relaxed">
                    I understand that my creator profile and all related creator data will be permanently deleted,
                    while my account will remain.
                  </span>
                </label>

                <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3 pt-2">
                  <Link href="/settings">
                    <PremiumButton type="button" variant="outline" className="w-full sm:w-auto">
                      Cancel
                    </PremiumButton>
                  </Link>
                  <PremiumButton
                    type="button"
                    variant="primary"
                    className="w-full sm:w-auto bg-destructive hover:bg-destructive/90 shadow-destructive/25"
                    disabled={!canDelete}
                    onClick={() => setIsModalOpen(true)}
                  >
                    <Trash2 className="w-4 h-4" />
                    Delete Creator Profile
                  </PremiumButton>
                </div>
              </div>
            </PremiumCard>
          </div>
        </div>
      </AppShell>

      {isModalOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget && !deleteProfile.isPending) {
              setIsModalOpen(false);
            }
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="delete-profile-modal-title"
            className="w-full max-w-md rounded-2xl border border-white/10 bg-background p-6 shadow-2xl"
          >
            <div className="w-12 h-12 rounded-xl bg-destructive/15 flex items-center justify-center mb-5">
              <AlertTriangle className="w-6 h-6 text-destructive" />
            </div>
            <h2 id="delete-profile-modal-title" className="text-xl font-bold mb-2">
              Delete your creator profile?
            </h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-6">
              Your creator profile, portfolio, and related creator data will be permanently removed.
              Your account will remain active.
            </p>
            <div className="flex flex-col-reverse sm:flex-row sm:justify-end gap-3">
              <PremiumButton
                type="button"
                variant="outline"
                className="w-full sm:w-auto"
                disabled={deleteProfile.isPending}
                onClick={() => setIsModalOpen(false)}
              >
                Keep Profile
              </PremiumButton>
              <PremiumButton
                type="button"
                className="w-full sm:w-auto bg-destructive hover:bg-destructive/90 shadow-destructive/25"
                disabled={deleteProfile.isPending}
                onClick={handleDelete}
              >
                <Check className="w-4 h-4" />
                {deleteProfile.isPending ? "Deleting..." : "Yes, Delete Profile"}
              </PremiumButton>
            </div>
          </div>
        </div>
      )}
    </>
  );
}