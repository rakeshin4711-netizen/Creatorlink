import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Plus } from "lucide-react";
import { formatCurrency } from "@/lib/currency";

export default function Billing() {
  return (
    <AppShell>
      <div className="max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Billing & Payments</h1>
        <p className="text-muted-foreground mb-8">Manage your payment methods and view invoice history.</p>

        <div className="grid md:grid-cols-2 gap-8 mb-8">
          
          <PremiumCard className="p-6 relative overflow-hidden group border-primary/30">
            <div className="absolute inset-0 bg-gradient-to-br from-primary/10 to-accent/10 opacity-50" />
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/20 rounded-full blur-[80px] -mr-32 -mt-32" />
            
            <div className="relative z-10 flex flex-col h-full">
              <div className="flex justify-between items-start mb-12">
                <div>
                  <div className="text-sm text-muted-foreground mb-1">Current Balance</div>
                  <div className="text-4xl font-bold">{formatCurrency(0, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</div>
                </div>
                <div className="w-12 h-8 rounded bg-white/10 flex items-center justify-center">
                  <div className="w-6 h-4 bg-white/20 rounded-sm" />
                </div>
              </div>
              
              <div className="mt-auto flex gap-3">
                <PremiumButton glow className="w-full">Withdraw Funds</PremiumButton>
              </div>
            </div>
          </PremiumCard>

          <PremiumCard className="p-6">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-lg">Payment Methods</h3>
              <button className="text-primary hover:text-primary/80 text-sm font-medium flex items-center">
                <Plus className="w-4 h-4 mr-1" /> Add New
              </button>
            </div>
            
            <div className="p-6 border border-dashed border-white/10 rounded-xl text-sm text-muted-foreground">
              No payment methods added yet.
            </div>
          </PremiumCard>
        </div>

        <h2 className="text-xl font-bold mb-4 mt-12">Invoice History</h2>
        <PremiumCard className="p-0 overflow-hidden border-white/10">
          <div className="overflow-x-auto">
            <table className="w-full text-sm text-left">
              <thead className="bg-white/5 text-muted-foreground font-medium border-b border-white/10">
                <tr>
                  <th className="px-6 py-4">Invoice</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Amount</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-muted-foreground">No invoices yet.</td>
                </tr>
              </tbody>
            </table>
          </div>
        </PremiumCard>
      </div>
    </AppShell>
  );
}
