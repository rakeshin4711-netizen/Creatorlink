import { MarketingLayout, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Link, useLocation } from "wouter";
import { motion } from "framer-motion";
import { Eye, EyeOff, Hexagon, ArrowRight } from "lucide-react";
import { useEffect, useState } from "react";
import { createSession, getSession } from "@/lib/session";

export default function Login() {
  const [location, setLocation] = useLocation();
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const returnTo = new URLSearchParams(
    location.split("?")[1] ?? "",
  ).get("returnTo");

  const safeReturnTo =
    returnTo &&
    returnTo.startsWith("/") &&
    !returnTo.startsWith("//")
      ? returnTo
      : null;

  useEffect(() => {
    let cancelled = false;

    async function checkExistingSession() {
      try {
        const response = await fetch("/api/auth/me", {
          credentials: "include",
        });

        if (!response.ok) return;

        const data = await response.json();

        if (cancelled || !data?.user) return;

        const role = data.user.role === "creator" ? "creator" : "client";

        createSession(
          role,
          data.user.username ?? data.user.email,
          rememberMe,
        );

        setLocation(
          safeReturnTo ??
            (role === "creator"
              ? "/creator-dashboard"
              : "/client-dashboard"),
        );
      } catch {
        // No active backend session.
      }
    }

    checkExistingSession();

    return () => {
      cancelled = true;
    };
  }, [safeReturnTo, setLocation, rememberMe]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          email: email.trim(),
          password,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data?.error ?? "Invalid email or password");
        return;
      }

      if (!data?.user) {
        setError("Login failed. Please try again.");
        return;
      }

      const role =
        data.user.role === "creator" ? "creator" : "client";

      createSession(
        role,
        data.user.username ?? data.user.email,
        rememberMe,
      );

      setLocation(
        safeReturnTo ??
          (role === "creator"
            ? "/creator-dashboard"
            : "/client-dashboard"),
      );
    } catch {
      setError(
        "Unable to connect to the server. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingLayout>
      <div className="min-h-[80vh] flex items-center justify-center px-4 relative pt-20">
        <div className="ambient-glow ambient-glow-primary -left-40 top-1/2 -translate-y-1/2" />

        <motion.div
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="w-full max-w-md relative z-10"
        >
          <PremiumCard className="p-8 md:p-10 border-white/20">
            <div className="flex flex-col items-center mb-8">
              <div className="w-12 h-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center mb-4">
                <Hexagon className="w-6 h-6" />
              </div>

              <h1 className="text-2xl font-bold tracking-tight">
                Welcome back
              </h1>

              <p className="text-muted-foreground mt-2 text-sm">
                Enter your credentials to access your account
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  Email
                </label>

                <input
                  type="email"
                  value={email}
                  onChange={(event) =>
                    setEmail(event.target.value)
                  }
                  className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground/50"
                  placeholder="name@example.com"
                  autoComplete="email"
                  required
                />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-foreground">
                    Password
                  </label>

                  <a
                    href="#"
                    className="text-xs text-primary hover:underline"
                  >
                    Forgot password?
                  </a>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(event) =>
                      setPassword(event.target.value)
                    }
                    className="w-full h-11 px-4 pr-11 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground/50"
                    placeholder="••••••••"
                    autoComplete="current-password"
                    required
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setShowPassword((visible) => !visible)
                    }
                    aria-label={
                      showPassword
                        ? "Hide password"
                        : "Show password"
                    }
                    title={
                      showPassword
                        ? "Hide password"
                        : "Show password"
                    }
                    className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>

                <label className="flex items-center gap-2 pt-1 text-xs text-muted-foreground cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(event) =>
                      setRememberMe(event.target.checked)
                    }
                    className="h-4 w-4 rounded border-white/20 bg-white/5 text-primary accent-primary"
                  />
                  Remember me
                </label>
              </div>

              {error && (
                <div
                  role="alert"
                  className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400"
                >
                  {error}
                </div>
              )}

              <PremiumButton
                type="submit"
                className="w-full mt-6"
                glow
                disabled={loading}
              >
                {loading ? "Signing in..." : "Sign In"}

                {!loading && (
                  <ArrowRight className="w-4 h-4 ml-2" />
                )}
              </PremiumButton>
            </form>

            <div className="mt-8 text-center text-sm text-muted-foreground">
              Don't have an account?{" "}
              <Link
                href={
                  safeReturnTo
                    ? `/signup?returnTo=${encodeURIComponent(
                        safeReturnTo,
                      )}`
                    : "/signup"
                }
                className="text-primary font-medium hover:underline"
              >
                Sign up
              </Link>
            </div>
          </PremiumCard>
        </motion.div>
      </div>
    </MarketingLayout>
  );
}