import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { motion } from "framer-motion";
import { Eye, DollarSign, Briefcase, Star, TrendingUp } from "lucide-react";
import { Link } from "wouter";
import {
  getGetCreatorProfileQueryKey,
  getListCreatorPortfoliosQueryKey,
  useCreateCreatorPortfolio,
  useDeleteCreatorPortfolio,
  useGetCreatorProfile,
  useListCreatorPortfolios,
  useUpdateCreatorPortfolio,
  type Portfolio,
  type PortfolioInput,
} from "@workspace/api-client-react";
import { getSession, getSessionUsername } from "@/lib/session";
import { CATEGORIES } from "@/lib/categories";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { ImagePlus, Pencil, Trash2, X } from "lucide-react";

const emptyPortfolio = (): PortfolioInput => ({
  title: "",
  description: "",
  category: "",
  skills: [],
  images: [],
});

function readImage(file: File) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}

export default function CreatorDashboard() {
  const username = getSessionUsername() ?? "creator";
  const isCreator = getSession()?.role === "creator";
  const queryClient = useQueryClient();
  const { data: profile } = useGetCreatorProfile(username, {
    query: {
      enabled: isCreator,
      queryKey: getGetCreatorProfileQueryKey(username),
    },
  });
  const portfoliosQuery = useListCreatorPortfolios(username, {
    query: {
      enabled: isCreator,
      queryKey: getListCreatorPortfoliosQueryKey(username),
      retry: false,
    },
  });
  const createPortfolio = useCreateCreatorPortfolio();
  const updatePortfolio = useUpdateCreatorPortfolio();
  const deletePortfolio = useDeleteCreatorPortfolio();
  const [portfolioFormOpen, setPortfolioFormOpen] = useState(false);
  const [editingPortfolio, setEditingPortfolio] = useState<Portfolio | null>(null);
  const [portfolioForm, setPortfolioForm] = useState<PortfolioInput>(emptyPortfolio);
  const [portfolioMessage, setPortfolioMessage] = useState("");
  const [portfolioSaving, setPortfolioSaving] = useState(false);

  const openNewPortfolio = () => {
    setEditingPortfolio(null);
    setPortfolioForm(emptyPortfolio());
    setPortfolioMessage("");
    setPortfolioFormOpen(true);
  };

  const openEditPortfolio = (portfolio: Portfolio) => {
    setEditingPortfolio(portfolio);
    setPortfolioForm({
      title: portfolio.title,
      description: portfolio.description,
      category: portfolio.category,
      skills: portfolio.skills,
      images: portfolio.images,
    });
    setPortfolioMessage("");
    setPortfolioFormOpen(true);
  };

  const closePortfolioForm = () => {
    setPortfolioFormOpen(false);
    setEditingPortfolio(null);
    setPortfolioMessage("");
  };

  const handlePortfolioImages = async (files: FileList | null) => {
    if (!files?.length) return;
    try {
      const images = await Promise.all(Array.from(files).map(readImage));
      setPortfolioForm((current) => ({
        ...current,
        images: [...current.images, ...images],
      }));
    } catch {
      setPortfolioMessage("Unable to read the selected image.");
    }
  };

  const handlePortfolioSave = (event: React.FormEvent) => {
    event.preventDefault();
    if (!portfolioForm.title.trim()) {
      setPortfolioMessage("Project title is required.");
      return;
    }

    setPortfolioSaving(true);
    setPortfolioMessage("");
    const data = {
      ...portfolioForm,
      title: portfolioForm.title.trim(),
      skills: portfolioForm.skills.map((skill) => skill.trim()).filter(Boolean),
    };
    const onSuccess = () => {
      queryClient.invalidateQueries({ queryKey: getListCreatorPortfoliosQueryKey(username) });
      setPortfolioSaving(false);
      closePortfolioForm();
    };
    const onError = () => {
      setPortfolioSaving(false);
      setPortfolioMessage("Unable to save this project. Please try again.");
    };

    if (editingPortfolio) {
      updatePortfolio.mutate(
        { identifier: username, portfolioId: editingPortfolio.id, data },
        { onSuccess, onError },
      );
    } else {
      createPortfolio.mutate(
        { identifier: username, data },
        { onSuccess, onError },
      );
    }
  };

  const handlePortfolioDelete = (portfolio: Portfolio) => {
    if (!window.confirm(`Delete "${portfolio.title}"?`)) return;
    deletePortfolio.mutate(
      { identifier: username, portfolioId: portfolio.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getListCreatorPortfoliosQueryKey(username) });
        },
      },
    );
  };
  
  const stats = [
    { label: "Monthly Earnings", value: "—", change: "No data yet", icon: DollarSign, color: "text-green-500" },
    { label: "Active Projects", value: "—", change: "No data yet", icon: Briefcase, color: "text-primary" },
    { label: "Profile Views", value: "—", change: "No data yet", icon: Eye, color: "text-accent" },
    { label: "Average Rating", value: "—", change: "No reviews yet", icon: Star, color: "text-yellow-500" }
  ];

  return (
    <AppShell role="creator">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back, {profile?.fullName?.split(' ')[0] ?? "Creator"}</h1>
          <p className="text-muted-foreground mt-1">Here is what's happening with your projects today.</p>
        </div>
        <div className="flex gap-3">
          <Link href="/settings?tab=profile">
            <PremiumButton variant="outline">Edit Profile</PremiumButton>
          </Link>
          <PremiumButton glow onClick={openNewPortfolio}>Add Portfolio</PremiumButton>
        </div>
      </div>

      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Portfolio</h2>
          <PremiumButton variant="outline" size="sm" onClick={openNewPortfolio}>
            <ImagePlus className="w-4 h-4 mr-2" /> Add Project
          </PremiumButton>
        </div>

        {portfolioFormOpen && (
          <PremiumCard className="p-6 mb-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold">{editingPortfolio ? "Edit Project" : "Add Project"}</h3>
              <button type="button" onClick={closePortfolioForm} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <form onSubmit={handlePortfolioSave} className="space-y-5">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Title</label>
                  <input
                    required
                    value={portfolioForm.title}
                    onChange={(event) => setPortfolioForm((current) => ({ ...current, title: event.target.value }))}
                    className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Category</label>
                  <select
                    value={portfolioForm.category}
                    onChange={(event) => setPortfolioForm((current) => ({ ...current, category: event.target.value }))}
                    className="w-full h-11 px-4 rounded-xl bg-background border border-white/10 focus:border-primary outline-none transition-all"
                  >
                    <option value="">Select a category</option>
                    {CATEGORIES.map((category) => <option key={category} value={category}>{category}</option>)}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Description</label>
                <textarea
                  value={portfolioForm.description}
                  onChange={(event) => setPortfolioForm((current) => ({ ...current, description: event.target.value }))}
                  rows={4}
                  className="w-full px-4 py-3 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all resize-none"
                />
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Skills</label>
                <input
                  value={portfolioForm.skills.join(", ")}
                  onChange={(event) => setPortfolioForm((current) => ({ ...current, skills: event.target.value.split(",") }))}
                  placeholder="Motion Design, 3D, After Effects"
                  className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                />
              </div>

              <div className="space-y-3">
                <label className="text-sm font-medium">Images</label>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={(event) => {
                    void handlePortfolioImages(event.target.files);
                    event.currentTarget.value = "";
                  }}
                  className="block w-full text-sm text-muted-foreground file:mr-4 file:rounded-xl file:border-0 file:bg-primary/20 file:px-4 file:py-2 file:text-sm file:font-medium file:text-primary hover:file:bg-primary/30"
                />
                {portfolioForm.images.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                    {portfolioForm.images.map((image, index) => (
                      <div key={`${image.slice(0, 24)}-${index}`} className="relative aspect-square rounded-xl overflow-hidden border border-white/10">
                        <img src={image} alt="" className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => setPortfolioForm((current) => ({ ...current, images: current.images.filter((_, imageIndex) => imageIndex !== index) }))}
                          className="absolute top-1 right-1 w-6 h-6 rounded-full bg-black/70 text-white flex items-center justify-center"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex justify-end items-center gap-3">
                {portfolioMessage && <span className="text-sm text-muted-foreground">{portfolioMessage}</span>}
                <PremiumButton type="button" variant="ghost" onClick={closePortfolioForm}>Cancel</PremiumButton>
                <PremiumButton type="submit" glow disabled={portfolioSaving}>
                  {portfolioSaving ? "Saving..." : editingPortfolio ? "Save Changes" : "Add Project"}
                </PremiumButton>
              </div>
            </form>
          </PremiumCard>
        )}

        {portfoliosQuery.data?.length ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {portfoliosQuery.data.map((portfolio) => (
              <PremiumCard key={portfolio.id} className="p-0 overflow-hidden">
                <div className="aspect-video bg-white/5">
                  {portfolio.images[0] ? (
                    <img src={portfolio.images[0]} alt={portfolio.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-muted-foreground">
                      <ImagePlus className="w-6 h-6" />
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <div className="flex justify-between items-start gap-3">
                    <div>
                      <h3 className="font-bold">{portfolio.title}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{portfolio.category || "Uncategorized"}</p>
                    </div>
                    <div className="flex gap-1">
                      <button type="button" onClick={() => openEditPortfolio(portfolio)} className="p-2 text-muted-foreground hover:text-primary">
                        <Pencil className="w-4 h-4" />
                      </button>
                      <button type="button" onClick={() => handlePortfolioDelete(portfolio)} className="p-2 text-muted-foreground hover:text-destructive">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                  {portfolio.description && <p className="text-sm text-muted-foreground mt-3 line-clamp-2">{portfolio.description}</p>}
                </div>
              </PremiumCard>
            ))}
          </div>
        ) : (
          !portfolioFormOpen && (
            <PremiumCard className="p-6 border-dashed border-white/10 text-muted-foreground">
              No portfolio projects have been added yet.
            </PremiumCard>
          )
        )}
      </section>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8 perspective-[1000px]">
        {stats.map((stat, i) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <PremiumCard className="p-5 hover:rotate-y-[2deg] hover:rotate-x-[2deg] transition-transform">
              <div className="flex justify-between items-start">
                <div className={`p-2.5 rounded-lg bg-white/5 ${stat.color}`}>
                  <stat.icon className="w-5 h-5" />
                </div>
                <TrendingUp className="w-4 h-4 text-green-500 opacity-80" />
              </div>
              <div className="mt-4">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className="text-sm font-medium text-muted-foreground mt-1">{stat.label}</div>
              </div>
              <div className="mt-4 pt-4 border-t border-white/5 text-xs font-medium text-muted-foreground">
                {stat.change}
              </div>
            </PremiumCard>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Active Projects */}
        <div className="lg:col-span-2 space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Active Projects</h2>
            <Link href="/project/manage" className="text-sm text-primary hover:underline">View all</Link>
          </div>
          
          <PremiumCard className="p-5 border-l-4 border-l-primary">
            <div className="flex items-center gap-4 text-muted-foreground">
              <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center shrink-0 border border-white/10">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-base text-foreground">No active projects yet</h3>
                <p className="text-sm mt-1">Project assignments will appear here when available.</p>
              </div>
            </div>
          </PremiumCard>

          {/* Earnings Overview */}
          <div className="pt-4">
             <h2 className="text-xl font-bold mb-6">Earnings Overview</h2>
             <PremiumCard className="p-6 h-64 flex items-center justify-center relative">
               <div className="text-sm text-muted-foreground">No earnings data yet.</div>
             </PremiumCard>
          </div>
        </div>

        {/* Sidebar panels */}
        <div className="space-y-8">
          {/* Notifications */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-bold">Recent Activity</h2>
              <Link href="/notifications" className="text-sm text-primary hover:underline">All</Link>
            </div>
            <PremiumCard className="p-0 overflow-hidden">
              <div className="p-6 text-sm text-muted-foreground">No recent activity yet.</div>
            </PremiumCard>
          </div>

          {/* Profile Completion */}
          <PremiumCard className="p-6 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-accent/20 rounded-full blur-3xl -z-10" />
            <h3 className="font-bold mb-2">Profile Completion</h3>
            <div className="flex items-center gap-4 mb-4">
              <div className="relative w-16 h-16 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90">
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-white/10" />
                  <circle cx="32" cy="32" r="28" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-accent" strokeDasharray="175" strokeDashoffset={profile ? "0" : "175"} />
                </svg>
                <span className="absolute text-sm font-bold">{profile ? "100%" : "0%"}</span>
              </div>
              <p className="text-sm text-muted-foreground flex-1">{profile ? "Your profile is ready to be discovered." : "Complete your profile to be discovered."}</p>
            </div>
            <Link href="/settings?tab=profile">
              <PremiumButton variant="outline" size="sm" className="w-full">Edit Profile</PremiumButton>
            </Link>
          </PremiumCard>
        </div>
      </div>
    </AppShell>
  );
}
