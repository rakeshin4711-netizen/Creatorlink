import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  getListClientPaymentsQueryKey,
  getListClientProjectsQueryKey,
  useCreateMockPayment,
  useCreateClientProject,
  useDeleteClientProject,
  useListClientPayments,
  useListClientProjects,
  useUpdateClientProject,
  type Project,
} from "@workspace/api-client-react";
import { getSessionUsername } from "@/lib/session";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Users, Briefcase, Star, Clock, CheckCircle2, ChevronRight, LayoutList, Pencil, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";
import { formatCurrency } from "@/lib/currency";
import { useToast } from "@/hooks/use-toast";

type ProjectFormState = {
  title: string;
  description: string;
  category: string;
  budget: string;
  deadline: string;
  skills: string;
};

const emptyProjectForm: ProjectFormState = {
  title: "",
  description: "",
  category: "",
  budget: "",
  deadline: "",
  skills: "",
};

function formFromProject(project: Project): ProjectFormState {
  return {
    title: project.title,
    description: project.description,
    category: project.category,
    budget: String(project.budget),
    deadline: project.deadline,
    skills: project.skills.join(", "),
  };
}

function formatDeadline(deadline: string | null | undefined) {
  if (!deadline) return "No deadline";

  const date = new Date(deadline.includes("T") ? deadline : `${deadline}T00:00:00`);
  if (Number.isNaN(date.getTime())) return "No deadline";

  return new Intl.DateTimeFormat(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric",
  }).format(date);
}

export default function ClientDashboard() {
  const clientIdentifier = getSessionUsername() ?? "client";
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const projectsQuery = useListClientProjects(
    { clientIdentifier },
    {
      query: {
        queryKey: getListClientProjectsQueryKey({ clientIdentifier }),
        refetchOnMount: "always",
      },
    },
  );
  const paymentsQuery = useListClientPayments(
    { clientIdentifier },
    {
      query: {
        queryKey: getListClientPaymentsQueryKey({ clientIdentifier }),
        refetchOnMount: "always",
      },
    },
  );
  const createProject = useCreateClientProject();
  const createPayment = useCreateMockPayment();
  const updateProject = useUpdateClientProject();
  const deleteProject = useDeleteClientProject();
  const [projectDialogOpen, setProjectDialogOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);
  const [form, setForm] = useState<ProjectFormState>(emptyProjectForm);

  const openCreateProject = () => {
    setEditingProject(null);
    setForm(emptyProjectForm);
    setProjectDialogOpen(true);
  };

  const openEditProject = (project: Project) => {
    setEditingProject(project);
    setForm(formFromProject(project));
    setProjectDialogOpen(true);
  };

  const updateField = (field: keyof ProjectFormState, value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const handlePayNow = async (project: Project) => {
    try {
      const payment = await createPayment.mutateAsync({
        data: {
          projectId: project.id,
          clientIdentifier,
          outcome: "success",
        },
      });
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey: getListClientProjectsQueryKey({ clientIdentifier }),
        }),
        queryClient.invalidateQueries({
          queryKey: getListClientPaymentsQueryKey({ clientIdentifier }),
        }),
      ]);
      toast({
        title: "Payment successful",
        description: `Invoice ${payment.invoiceNumber} has been generated.`,
      });
    } catch (error) {
      toast({
        title: "Payment failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleProjectSubmit = (event: React.FormEvent) => {
    event.preventDefault();
    const data = {
      clientIdentifier,
      title: form.title.trim(),
      description: form.description.trim(),
      category: form.category.trim(),
      budget: Number(form.budget),
      deadline: form.deadline,
      skills: form.skills
        .split(",")
        .map((skill) => skill.trim())
        .filter(Boolean),
    };

    const onSuccess = () => {
      setProjectDialogOpen(false);
      setEditingProject(null);
      setForm(emptyProjectForm);
      void queryClient.invalidateQueries({
        queryKey: getListClientProjectsQueryKey({ clientIdentifier }),
      });
    };

    if (editingProject) {
      updateProject.mutate({ projectId: editingProject.id, data }, { onSuccess });
    } else {
      createProject.mutate({ data }, { onSuccess });
    }
  };

  const handleDeleteProject = (project: Project) => {
    if (!window.confirm(`Delete "${project.title}"?`)) return;
    deleteProject.mutate(
      { projectId: project.id },
      {
        onSuccess: () => {
          void queryClient.invalidateQueries({
            queryKey: getListClientProjectsQueryKey({ clientIdentifier }),
          });
        },
      },
    );
  };

  const projects = projectsQuery.data ?? [];
  const payments = paymentsQuery.data ?? [];
  const successfulPayments = payments.filter((payment) => payment.status === "succeeded");
  const paidProjectIds = new Set(successfulPayments.map((payment) => payment.projectId));
  const totalSpent = successfulPayments.reduce((total, payment) => total + payment.amount, 0);
  const isSaving = createProject.isPending || updateProject.isPending;

  return (
    <AppShell role="client">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Client Dashboard</h1>
          <p className="text-muted-foreground mt-1">Manage your projects and creative teams.</p>
        </div>
        <div className="flex gap-3">
          <Link href="/search">
            <PremiumButton variant="outline">Find Talent</PremiumButton>
          </Link>
          <PremiumButton glow onClick={openCreateProject}>
            <Plus className="w-4 h-4 mr-2" /> Post a Project
          </PremiumButton>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-8">
          {/* Active Projects */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Active Projects</h2>
              <span className="text-sm text-muted-foreground">
                {projects.length} {projects.length === 1 ? "project" : "projects"}
              </span>
            </div>
            <div className="space-y-4">
              {projects.map((project) => (
                <PremiumCard key={project.id} className="p-6">
                  <div className="flex flex-col md:flex-row justify-between gap-6">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="bg-primary/20 text-primary text-xs font-bold px-2 py-1 rounded-full uppercase tracking-wider">
                          {project.status === "paid" || paidProjectIds.has(project.id) ? "Paid" : project.status === "pending" ? "Pending" : "Open"}
                        </span>
                        <span className="text-sm text-muted-foreground flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" /> Due {formatDeadline(project.deadline)}
                        </span>
                      </div>
                      <h3 className="text-xl font-bold mb-2 truncate">{project.title}</h3>
                      <p className="text-sm text-muted-foreground mb-4 line-clamp-2">{project.description}</p>
                      <div className="flex flex-wrap items-center gap-2">
                        {project.category && (
                          <span className="text-xs px-2 py-1 rounded-full bg-white/5 text-muted-foreground">{project.category}</span>
                        )}
                        {project.skills.map((skill) => (
                          <span key={skill} className="text-xs px-2 py-1 rounded-full bg-white/5 text-muted-foreground">{skill}</span>
                        ))}
                      </div>
                    </div>

                      <div className="md:w-48 flex flex-col justify-between gap-4 p-4 bg-white/5 rounded-xl border border-white/5">
                      {(() => {
                        const projectStatus = String(project.status ?? "").toLowerCase();
                        const isPaid = projectStatus === "paid" || paidProjectIds.has(project.id);
                        const canPay = projectStatus === "open" || projectStatus === "pending";

                        return (
                          <>
                      <div>
                        <div className="text-xs text-muted-foreground mb-1">Budget</div>
                        <div className="font-bold text-lg">{formatCurrency(project.budget)}</div>
                      </div>
                        {canPay && !isPaid && (
                          <PremiumButton
                            glow
                            size="sm"
                            className="w-full"
                            disabled={createPayment.isPending}
                            onClick={() => void handlePayNow(project)}
                          >
                            Pay Now
                          </PremiumButton>
                        )}
                      <div className="flex gap-2">
                        <PremiumButton
                          variant="outline"
                          size="sm"
                          onClick={() => openEditProject(project)}
                          className="flex-1"
                        >
                          <Pencil className="w-3.5 h-3.5 mr-1.5" /> Edit
                        </PremiumButton>
                        <button
                          type="button"
                          onClick={() => handleDeleteProject(project)}
                          aria-label={`Delete ${project.title}`}
                          className="p-2 rounded-lg border border-white/10 text-muted-foreground hover:text-red-400 hover:border-red-400/40 transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                          </>
                        );
                      })()}
                    </div>
                  </div>
                </PremiumCard>
              ))}

              {!projects.length && !projectsQuery.isLoading && (
                <PremiumCard className="p-6 border-dashed border-white/10">
                  <div className="flex items-center gap-4 text-muted-foreground">
                    <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                      <LayoutList className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-medium text-foreground">No projects posted yet</h3>
                      <p className="text-sm">Start a new project and invite talent.</p>
                    </div>
                    <PremiumButton variant="outline" size="sm" className="ml-auto" onClick={openCreateProject}>Create Project</PremiumButton>
                  </div>
                </PremiumCard>
              )}
              {projectsQuery.isLoading && (
                <PremiumCard className="p-6">
                  <div className="text-sm text-muted-foreground">Loading your projects...</div>
                </PremiumCard>
              )}
            </div>
          </section>

          {/* Saved Talent */}
          <section>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-bold">Saved Talent</h2>
              <Link href="/search" className="text-sm text-primary hover:underline">Manage</Link>
            </div>
            <PremiumCard className="p-6 border-dashed border-white/10 text-muted-foreground">
              No saved talent yet.
            </PremiumCard>
          </section>
        </div>

        {/* Sidebar content */}
        <div className="space-y-6">
          <PremiumCard className="p-6 bg-gradient-to-br from-primary/20 to-transparent border-primary/20">
            <h3 className="font-bold text-lg mb-1">Total Spent</h3>
            <div className="text-4xl font-black text-white">{formatCurrency(totalSpent)}</div>
            <p className="text-sm text-primary mt-2 flex items-center gap-1 font-medium">
              <CheckCircle2 className="w-4 h-4" /> {successfulPayments.length ? `${successfulPayments.length} paid ${successfulPayments.length === 1 ? "project" : "projects"}` : "No completed projects yet"}
            </p>
          </PremiumCard>

          <PremiumCard className="p-0 overflow-hidden">
            <div className="p-4 border-b border-white/5">
              <h3 className="font-bold">Recent Invoices</h3>
            </div>
            {successfulPayments.length ? (
              <div className="divide-y divide-white/5">
                {successfulPayments.slice(0, 3).map((payment) => (
                  <div key={payment.paymentId} className="flex items-center justify-between gap-4 p-4 text-sm">
                    <span className="font-mono text-xs text-muted-foreground">{payment.invoiceNumber}</span>
                    <span className="font-semibold">{formatCurrency(payment.amount)}</span>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-6 text-sm text-muted-foreground">No invoices yet.</div>
            )}
            <Link href="/billing" className="block w-full p-3 text-center text-sm text-primary hover:bg-white/5 transition-colors">
              View all billing
            </Link>
          </PremiumCard>
        </div>
      </div>

      <Dialog open={projectDialogOpen} onOpenChange={setProjectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingProject ? "Edit Project" : "Post a Project"}</DialogTitle>
            <DialogDescription>
              Share the details talent needs to understand your project.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleProjectSubmit} className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="project-title" className="text-sm font-medium">Title</label>
              <input
                id="project-title"
                value={form.title}
                onChange={(event) => updateField("title", event.target.value)}
                required
                className="w-full h-10 px-3 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label htmlFor="project-description" className="text-sm font-medium">Description</label>
              <textarea
                id="project-description"
                value={form.description}
                onChange={(event) => updateField("description", event.target.value)}
                required
                rows={3}
                className="w-full px-3 py-2 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors resize-none"
              />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="project-category" className="text-sm font-medium">Category</label>
                <input
                  id="project-category"
                  value={form.category}
                  onChange={(event) => updateField("category", event.target.value)}
                  required
                  className="w-full h-10 px-3 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="project-budget" className="text-sm font-medium">Budget</label>
                <input
                  id="project-budget"
                  type="number"
                  min="0"
                  value={form.budget}
                  onChange={(event) => updateField("budget", event.target.value)}
                  required
                  className="w-full h-10 px-3 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label htmlFor="project-deadline" className="text-sm font-medium">Deadline</label>
                <input
                  id="project-deadline"
                  type="date"
                  value={form.deadline}
                  onChange={(event) => updateField("deadline", event.target.value)}
                  required
                  className="w-full h-10 px-3 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors"
                />
              </div>
              <div className="space-y-2">
                <label htmlFor="project-skills" className="text-sm font-medium">Skills</label>
                <input
                  id="project-skills"
                  value={form.skills}
                  onChange={(event) => updateField("skills", event.target.value)}
                  placeholder="Motion, 3D, Editing"
                  required
                  className="w-full h-10 px-3 rounded-lg bg-white/5 border border-white/10 focus:border-primary outline-none transition-colors"
                />
              </div>
            </div>
            <DialogFooter>
              <PremiumButton type="button" variant="outline" onClick={() => setProjectDialogOpen(false)}>Cancel</PremiumButton>
              <PremiumButton type="submit" glow disabled={isSaving}>
                {isSaving ? "Saving..." : editingProject ? "Save Changes" : "Post Project"}
              </PremiumButton>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}