import { AppShell } from "@/components";
import {
  getListConversationMessagesQueryKey,
  getListConversationsQueryKey,
  useCreateConversation,
  useListConversationMessages,
  useListConversations,
  useMarkConversationRead,
  useSendConversationMessage,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import {
  Search,
  Paperclip,
  Send,
  Phone,
  Video,
  MoreVertical,
  Image as ImageIcon,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { getSession, getSessionUsername } from "@/lib/session";

function formatMessageTime(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "";
  }

  return new Intl.DateTimeFormat(undefined, {
    hour: "numeric",
    minute: "2-digit",
  }).format(date);
}

function getOtherParticipant(
  conversation: {
    participantOne: string;
    participantTwo: string;
  },
  participant: string,
) {
  return conversation.participantOne === participant
    ? conversation.participantTwo
    : conversation.participantOne;
}

function getErrorMessage(error: unknown, fallback: string) {
  if (error instanceof Error && error.message) {
    return error.message;
  }

  if (
    typeof error === "object" &&
    error !== null &&
    "message" in error &&
    typeof error.message === "string"
  ) {
    return error.message;
  }

  return fallback;
}

export default function Chat() {
  const [location] = useLocation();

  /*
   * IMPORTANT:
   * Messages must use the logged-in username as participant.
   * Do not use "creator" / "client" as a fake participant.
   */
  const session = getSession();

  const participant = (
    getSessionUsername()?.trim() ||
    ""
  ).trim();

  /*
   * Read ?with=username directly from the browser URL.
   * This makes the Message button from Creator Profile reliable.
   */
  const requestedParticipant = useMemo(() => {
    try {
      const browserQuery =
        typeof window !== "undefined"
          ? new URLSearchParams(window.location.search).get("with")
          : null;

      if (browserQuery?.trim()) {
        return browserQuery.trim();
      }

      const queryString = location.includes("?")
        ? location.split("?")[1]
        : "";

      return (
        new URLSearchParams(queryString).get("with")?.trim() || ""
      );
    } catch {
      return "";
    }
  }, [location]);

  const [activeConversationId, setActiveConversationId] =
    useState<number | null>(null);

  const [input, setInput] = useState("");
  const [search, setSearch] = useState("");
  const [error, setError] = useState("");

  const creatingConversationKey = useRef<string | null>(null);
  const markedReadKey = useRef<string | null>(null);

  const queryClient = useQueryClient();

  /*
   * If there is no username in session, do not make API requests
   * using "client" or "creator".
   */
  const conversationsQuery = useListConversations(
    { participant },
    {
      query: {
        enabled: Boolean(participant),
        queryKey: getListConversationsQueryKey({ participant }),
        refetchInterval: 5000,
        refetchIntervalInBackground: true,
      },
    },
  );

  const createConversation = useCreateConversation();

  const messagesQuery = useListConversationMessages(
    activeConversationId ?? 0,
    {
      query: {
        enabled: activeConversationId !== null,
        queryKey: getListConversationMessagesQueryKey(
          activeConversationId ?? 0,
        ),
        refetchInterval: 2000,
        refetchIntervalInBackground: true,
      },
    },
  );

  const sendMessage = useSendConversationMessage();

  const { mutate: markConversationRead } =
    useMarkConversationRead();

  /*
   * Session validation.
   */
  useEffect(() => {
    if (!participant) {
      setError("Your session could not be identified. Please log in again.");
    } else {
      setError("");
    }
  }, [participant]);

  /*
   * Reset conversation when participant or recipient changes.
   */
  useEffect(() => {
    setActiveConversationId(null);
    creatingConversationKey.current = null;
    markedReadKey.current = null;
  }, [participant, requestedParticipant]);

  /*
   * Find existing conversation.
   * If none exists and ?with=username exists,
   * automatically create the conversation.
   */
  useEffect(() => {
    if (!participant) return;

    if (activeConversationId !== null) {
      return;
    }

    if (!conversationsQuery.data) {
      return;
    }

    if (!requestedParticipant) {
      const firstConversation =
        conversationsQuery.data[0];

      if (firstConversation) {
        setActiveConversationId(firstConversation.id);
      }

      return;
    }

    /*
     * Don't allow messaging yourself.
     */
    if (
      requestedParticipant.toLowerCase() ===
      participant.toLowerCase()
    ) {
      setError("You cannot start a conversation with yourself.");
      return;
    }

    /*
     * Check whether conversation already exists.
     */
    const existing =
      conversationsQuery.data.find(
        (conversation) =>
          getOtherParticipant(
            conversation,
            participant,
          ).toLowerCase() ===
          requestedParticipant.toLowerCase(),
      );

    if (existing) {
      setActiveConversationId(existing.id);
      setError("");
      return;
    }

    /*
     * Create new conversation.
     */
    const creationKey =
      `${participant}:${requestedParticipant}`;

    if (
      creatingConversationKey.current === creationKey ||
      createConversation.isPending
    ) {
      return;
    }

    creatingConversationKey.current = creationKey;
    setError("");

    createConversation
      .mutateAsync({
        data: {
          participant,
          otherParticipant: requestedParticipant,
        },
      })
      .then((conversation) => {
        setActiveConversationId(conversation.id);

        creatingConversationKey.current = null;

        queryClient.setQueryData(
          getListConversationsQueryKey({
            participant,
          }),
          (
            current:
              | typeof conversationsQuery.data
              | undefined = [],
          ) => {
            const list = current ?? [];

            const alreadyExists = list.some(
              (item) =>
                item.id === conversation.id,
            );

            if (alreadyExists) {
              return list.map((item) =>
                item.id === conversation.id
                  ? conversation
                  : item,
              );
            }

            return [conversation, ...list];
          },
        );

        void queryClient.invalidateQueries({
          queryKey:
            getListConversationsQueryKey({
              participant,
            }),
        });
      })
      .catch((error) => {
        creatingConversationKey.current = null;

        const message = getErrorMessage(
          error,
          "Unable to start this conversation.",
        );

        setError(message);

        console.error(
          "Failed to create conversation:",
          error,
        );
      });
  }, [
    activeConversationId,
    conversationsQuery.data,
    createConversation.isPending,
    participant,
    queryClient,
    requestedParticipant,
  ]);

  /*
   * Mark active conversation as read.
   */
  useEffect(() => {
    if (activeConversationId === null) {
      markedReadKey.current = null;
      return;
    }

    if (!participant) return;

    const lastMessageId =
      messagesQuery.data?.at(-1)?.id ?? 0;

    const readKey =
      `${activeConversationId}:${lastMessageId}`;

    if (markedReadKey.current === readKey) {
      return;
    }

    markedReadKey.current = readKey;

    markConversationRead(
      {
        conversationId: activeConversationId,
        data: {
          participant,
        },
      },
      {
        onSuccess: (conversation) => {
          queryClient.setQueryData(
            getListConversationsQueryKey({
              participant,
            }),
            (
              current:
                | typeof conversationsQuery.data
                | undefined = [],
            ) => {
              const list = current ?? [];

              return list.map((item) =>
                item.id === conversation.id
                  ? {
                      ...item,
                      unreadCount:
                        conversation.unreadCount,
                    }
                  : item,
              );
            },
          );
        },

        onError: (error) => {
          markedReadKey.current = null;

          console.error(
            "Failed to mark conversation as read:",
            error,
          );
        },
      },
    );
  }, [
    activeConversationId,
    conversationsQuery.data,
    markConversationRead,
    messagesQuery.data,
    participant,
    queryClient,
  ]);

  /*
   * Filter conversations.
   */
  const conversations = (
    conversationsQuery.data ?? []
  ).filter((conversation) => {
    if (!search.trim()) {
      return true;
    }

    const other =
      getOtherParticipant(
        conversation,
        participant,
      );

    return `${other} ${conversation.lastMessage}`
      .toLowerCase()
      .includes(
        search.toLowerCase(),
      );
  });

  const activeConversation =
    conversationsQuery.data?.find(
      (conversation) =>
        conversation.id ===
        activeConversationId,
    );

  const activeParticipant =
    activeConversation
      ? getOtherParticipant(
          activeConversation,
          participant,
        )
      : requestedParticipant ||
        "Messages";

  /*
   * SEND MESSAGE
   */
  const handleSend = async (
    event: React.FormEvent,
  ) => {
    event.preventDefault();

    const text = input.trim();

    if (!text) {
      return;
    }

    if (!participant) {
      setError(
        "Your account session could not be identified. Please log in again.",
      );
      return;
    }

    if (activeConversationId === null) {
      setError(
        "No conversation is selected. Open a creator profile and click Message first.",
      );
      return;
    }

    setError("");

    try {
      await sendMessage.mutateAsync({
        conversationId:
          activeConversationId,

        data: {
          senderId: participant,
          text,
          attachment: "",
        },
      });

      /*
       * Clear only after successful send.
       */
      setInput("");

      /*
       * Refresh both messages and conversation list.
       */
      await Promise.all([
        queryClient.invalidateQueries({
          queryKey:
            getListConversationMessagesQueryKey(
              activeConversationId,
            ),
        }),

        queryClient.invalidateQueries({
          queryKey:
            getListConversationsQueryKey({
              participant,
            }),
        }),
      ]);

      await Promise.all([
        messagesQuery.refetch(),
        conversationsQuery.refetch(),
      ]);
    } catch (error) {
      const message = getErrorMessage(
        error,
        "Failed to send message.",
      );

      setError(message);

      console.error(
        "Failed to send message:",
        error,
      );
    }
  };

  return (
    <AppShell>
      <div className="h-[calc(100vh-8rem)] flex rounded-3xl overflow-hidden glass-panel border-white/10">

        {/* SIDEBAR */}
        <div className="w-80 border-r border-white/10 flex flex-col bg-black/20">

          <div className="p-4 border-b border-white/10">
            <h2 className="font-bold text-xl mb-4">
              Messages
            </h2>

            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />

              <input
                type="text"
                value={search}
                onChange={(event) =>
                  setSearch(event.target.value)
                }
                placeholder="Search messages..."
                className="w-full bg-white/5 border border-white/10 rounded-full pl-9 pr-4 py-2 text-sm focus:outline-none focus:border-primary transition-colors"
              />
            </div>
          </div>

          <div className="flex-1 overflow-y-auto">
            {conversations.map(
              (conversation) => {
                const otherParticipant =
                  getOtherParticipant(
                    conversation,
                    participant,
                  );

                return (
                  <button
                    type="button"
                    key={conversation.id}
                    onClick={() => {
                      setActiveConversationId(
                        conversation.id,
                      );
                      setError("");
                    }}
                    className={`w-full text-left p-4 border-b border-white/5 flex gap-3 cursor-pointer transition-colors ${
                      conversation.id ===
                      activeConversationId
                        ? "bg-primary/10 border-l-2 border-l-primary"
                        : "hover:bg-white/5"
                    }`}
                  >
                    <div className="w-12 h-12 rounded-full bg-primary/20 border border-white/10 flex items-center justify-center font-semibold">
                      {otherParticipant
                        .slice(0, 1)
                        .toUpperCase()}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex justify-between items-baseline mb-1 gap-2">
                        <h4 className="font-semibold text-sm truncate">
                          {otherParticipant}
                        </h4>

                        <span className="text-[10px] text-muted-foreground shrink-0">
                          {conversation.lastMessageAt
                            ? formatMessageTime(
                                conversation.lastMessageAt,
                              )
                            : ""}
                        </span>

                        {conversation.unreadCount >
                          0 && (
                          <span className="min-w-4 rounded-full bg-primary px-1 text-center text-[10px] leading-4 text-primary-foreground">
                            {conversation.unreadCount >
                            99
                              ? "99+"
                              : conversation.unreadCount}
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-muted-foreground truncate">
                        {conversation.lastMessage ||
                          "No messages yet"}
                      </p>
                    </div>
                  </button>
                );
              },
            )}

            {!conversations.length &&
              !conversationsQuery.isLoading && (
                <div className="p-6 text-sm text-muted-foreground">
                  {requestedParticipant
                    ? "Starting conversation..."
                    : "No conversations yet."}
                </div>
              )}
          </div>
        </div>

        {/* CHAT AREA */}
        <div className="flex-1 flex flex-col bg-background/50 relative">

          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 to-transparent pointer-events-none" />

          {/* HEADER */}
          <div className="p-4 border-b border-white/10 flex justify-between items-center bg-black/20 backdrop-blur-md relative z-10">

            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-primary/20 border border-white/10 flex items-center justify-center font-semibold">
                {activeParticipant
                  .slice(0, 1)
                  .toUpperCase()}
              </div>

              <div>
                <h3 className="font-bold text-sm">
                  {activeParticipant}
                </h3>

                {activeConversationId !==
                  null && (
                  <span className="text-xs text-green-500">
                    Online
                  </span>
                )}
              </div>
            </div>

            <div className="flex gap-2 text-muted-foreground">
              <button
                type="button"
                className="p-2 rounded-full hover:bg-white/10 hover:text-white transition-colors"
              >
                <Phone className="w-4 h-4" />
              </button>

              <button
                type="button"
                className="p-2 rounded-full hover:bg-white/10 hover:text-white transition-colors"
              >
                <Video className="w-4 h-4" />
              </button>

              <button
                type="button"
                className="p-2 rounded-full hover:bg-white/10 hover:text-white transition-colors"
              >
                <MoreVertical className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* ERROR */}
          {error && (
            <div className="relative z-20 mx-4 mt-4 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm text-red-300">
              <div className="flex items-start justify-between gap-4">
                <span>{error}</span>

                <button
                  type="button"
                  onClick={() =>
                    setError("")
                  }
                  className="text-red-300/70 hover:text-red-200"
                >
                  ×
                </button>
              </div>
            </div>
          )}

          {/* MESSAGES */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6 relative z-10 flex flex-col">

            {(messagesQuery.data ?? []).map(
              (message) => {
                const isSender =
                  message.senderId ===
                  participant;

                return (
                  <div
                    key={message.id}
                    className={`flex ${
                      isSender
                        ? "justify-end"
                        : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[70%] ${
                        isSender
                          ? "items-end"
                          : "items-start"
                      } flex flex-col gap-1`}
                    >
                      <div
                        className={`px-4 py-3 rounded-2xl ${
                          isSender
                            ? "bg-primary text-primary-foreground rounded-tr-sm shadow-lg shadow-primary/20"
                            : "glass bg-white/10 rounded-tl-sm"
                        }`}
                      >
                        <p className="text-sm leading-relaxed">
                          {message.text}
                        </p>

                        {message.attachment && (
                          <div className="mt-3 p-2 bg-black/20 rounded-lg flex items-center gap-2 border border-white/10">
                            <div className="w-8 h-8 rounded bg-red-500/20 text-red-400 flex items-center justify-center shrink-0">
                              <Paperclip className="w-4 h-4" />
                            </div>

                            <div className="text-xs min-w-0">
                              <div className="font-semibold truncate">
                                {message.attachment}
                              </div>

                              <div className="text-muted-foreground opacity-80">
                                Attachment
                              </div>
                            </div>
                          </div>
                        )}
                      </div>

                      <span className="text-[10px] text-muted-foreground px-2">
                        {formatMessageTime(
                          message.createdAt,
                        )}
                      </span>
                    </div>
                  </div>
                );
              },
            )}

            {activeConversationId ===
              null && (
              <div className="m-auto text-sm text-muted-foreground text-center max-w-md">
                {requestedParticipant
                  ? "Starting conversation..."
                  : "Select a conversation to start messaging."}
              </div>
            )}

            {activeConversationId !==
              null &&
              !messagesQuery.data?.length && (
                <div className="m-auto text-sm text-muted-foreground">
                  No messages yet. Start the conversation.
                </div>
              )}
          </div>

          {/* INPUT */}
          <div className="p-4 border-t border-white/10 bg-black/20 backdrop-blur-md relative z-10">

            <form
              onSubmit={handleSend}
              className="flex gap-2"
            >
              <button
                type="button"
                className="p-3 text-muted-foreground hover:text-white transition-colors rounded-xl hover:bg-white/5 shrink-0"
              >
                <Paperclip className="w-5 h-5" />
              </button>

              <button
                type="button"
                className="p-3 text-muted-foreground hover:text-white transition-colors rounded-xl hover:bg-white/5 shrink-0 hidden sm:block"
              >
                <ImageIcon className="w-5 h-5" />
              </button>

              <input
                type="text"
                value={input}
                onChange={(event) => {
                  setInput(event.target.value);

                  if (error) {
                    setError("");
                  }
                }}
                placeholder={
                  activeConversationId ===
                  null
                    ? requestedParticipant
                      ? "Starting conversation..."
                      : "Select a conversation..."
                    : "Type a message..."
                }
                disabled={
                  activeConversationId ===
                    null ||
                  sendMessage.isPending
                }
                className="flex-1 bg-white/5 border border-white/10 rounded-xl px-4 focus:outline-none focus:border-primary transition-colors text-sm disabled:opacity-50"
              />

              <button
                type="submit"
                disabled={
                  !input.trim() ||
                  activeConversationId ===
                    null ||
                  sendMessage.isPending
                }
                className="p-3 bg-primary text-primary-foreground rounded-xl shadow-lg shadow-primary/20 disabled:opacity-50 disabled:shadow-none transition-all active:scale-95 shrink-0"
                title={
                  sendMessage.isPending
                    ? "Sending..."
                    : "Send message"
                }
              >
                {sendMessage.isPending ? (
                  <span className="block w-5 h-5 border-2 border-current border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </AppShell>
  );
}