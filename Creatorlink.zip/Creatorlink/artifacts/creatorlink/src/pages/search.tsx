import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { CATEGORIES } from "@/lib/categories";
import { Link } from "wouter";
import { Search, SlidersHorizontal, Star, MapPin } from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useListCreators } from "@workspace/api-client-react";
import { formatHourlyRate } from "@/lib/currency";

export default function SearchPage() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const creatorsQuery = useListCreators();
  const creators = (creatorsQuery.data ?? []).filter((creator) => {
    const term = searchTerm.trim().toLowerCase();
    const matchesCategory = activeCategory === "All" || creator.category === activeCategory;
    if (!term) return matchesCategory;
    const searchable = [creator.fullName, creator.username, creator.category, creator.location, ...creator.skills].join(" ").toLowerCase();
    return matchesCategory && searchable.includes(term);
  });

  return (
    <AppShell role="client">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-8">
        <div className="w-full max-w-2xl">
          <h1 className="text-3xl font-bold tracking-tight mb-4">Find Talent</h1>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <input 
              type="text" 
              placeholder="Search by skills, names, or roles..." 
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              className="w-full h-14 pl-12 pr-4 rounded-2xl glass-panel border border-white/10 focus:border-primary outline-none transition-all text-lg placeholder:text-muted-foreground/60"
            />
          </div>
        </div>
        <PremiumButton variant="outline" className="shrink-0 h-14 rounded-2xl border-white/10">
          <SlidersHorizontal className="w-5 h-5 mr-2" />
          Filters
        </PremiumButton>
      </div>

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Sidebar Filters */}
        <div className="w-full lg:w-64 space-y-8 sticky top-6">
          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Categories</h3>
            <div className="space-y-1">
              <button 
                onClick={() => setActiveCategory("All")}
                className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${activeCategory === "All" ? "bg-primary/20 text-primary" : "hover:bg-white/5 text-foreground"}`}
              >
                All Categories
              </button>
              {CATEGORIES.map(cat => (
                <button 
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-sm font-medium transition-colors ${activeCategory === cat ? "bg-primary/20 text-primary" : "hover:bg-white/5 text-muted-foreground hover:text-foreground"}`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground mb-4">Hourly Rate</h3>
            <input type="range" className="w-full accent-primary" min="10" max="200" defaultValue="100" />
            <div className="flex justify-between text-xs text-muted-foreground mt-2">
              <span>{formatHourlyRate(10)}</span>
              <span>{formatHourlyRate(200)}</span>
            </div>
          </div>
        </div>

        {/* Results Grid */}
        <div className="flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 perspective-[1000px]">
            <AnimatePresence>
               {creators.map((creator, i) => (
                <motion.div
                  key={creator.id}
                  initial={{ opacity: 0, scale: 0.9, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.4, delay: i * 0.1 }}
                >
                  <Link href={`/creator/${creator.username}`}>
                    <PremiumCard className="h-full flex flex-col hover:rotate-y-[5deg] hover:rotate-x-[5deg] group transition-all duration-300 transform-gpu cursor-pointer">
                      <div className="h-40 relative overflow-hidden">
                        <div className="w-full h-full bg-gradient-to-br from-primary/40 via-primary/10 to-accent/30 transition-transform duration-700 group-hover:scale-110" />
                        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                      </div>
                      <div className="px-5 pb-5 relative flex-1 flex flex-col">
                        <div className="absolute -top-10 left-5">
                          {creator.profilePhoto ? (
                            <img src={creator.profilePhoto} alt={creator.fullName} className="w-16 h-16 rounded-xl object-cover border-2 border-background shadow-lg" />
                          ) : (
                            <div className="w-16 h-16 rounded-xl bg-primary/30 border-2 border-background shadow-lg flex items-center justify-center text-xl font-bold">
                              {creator.fullName.slice(0, 1).toUpperCase()}
                            </div>
                          )}
                        </div>
                        <div className="flex justify-end pt-2 mb-4">
                          <div className="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2 py-1 rounded-md text-xs font-semibold text-white border border-white/10">
                            <Star className="w-3 h-3 fill-accent text-accent" />
                            No reviews
                          </div>
                        </div>
                        <h3 className="font-bold text-lg leading-tight group-hover:text-primary transition-colors">{creator.fullName}</h3>
                        <p className="text-sm text-muted-foreground font-medium mb-3">{creator.category || "Creator"}</p>
                        
                        <div className="flex items-center gap-1 text-xs text-muted-foreground mb-4">
                          <MapPin className="w-3 h-3" /> {creator.location}
                        </div>

                        <div className="flex flex-wrap gap-1 mt-auto">
                          {creator.skills.slice(0, 3).map(skill => (
                            <span key={skill} className="text-[10px] uppercase tracking-wider px-2 py-1 rounded-sm bg-white/5 text-muted-foreground border border-white/10">
                              {skill}
                            </span>
                          ))}
                        </div>
                        <div className="mt-4 pt-4 border-t border-white/5 flex items-center justify-between text-sm">
                          <span className="font-semibold">{formatHourlyRate(creator.hourlyRate)}</span>
                          <span className="text-xs text-muted-foreground font-medium bg-white/5 px-2 py-1 rounded">Profile available</span>
                        </div>
                      </div>
                    </PremiumCard>
                  </Link>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
          {!creatorsQuery.isLoading && creators.length === 0 && (
            <PremiumCard className="mt-6 p-8 border-dashed border-white/10 text-center text-muted-foreground">
              No creators found.
            </PremiumCard>
          )}
        </div>
      </div>
    </AppShell>
  );
}
