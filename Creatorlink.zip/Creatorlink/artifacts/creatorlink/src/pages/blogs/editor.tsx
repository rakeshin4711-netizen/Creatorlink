import { AppShell, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { useListMyBlogsForAuthor, useCreateBlog, useUpdateBlog, useDeleteBlog, type BlogInput } from "@/hooks/use-blogs";
import { useState, useEffect, useRef } from "react";
import { Save, ImagePlus, Trash2, Edit3, Settings, PenTool, LayoutTemplate, Link as LinkIcon, Send, Bold, Italic, Underline, List, Heading2, Link2 } from "lucide-react";
import { CATEGORIES } from "@/lib/categories";
import { getSession, getSessionUsername } from "@/lib/session";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";

type EditorForm = Omit<BlogInput, "authorIdentifier">;

export default function BlogEditor() {
  const session = getSession();
  const [, setLocation] = useLocation();
  const authorIdentifier = getSessionUsername() ?? session?.role ?? "creator";
  const { data: myBlogs, refetch } = useListMyBlogsForAuthor(authorIdentifier);
  const createBlog = useCreateBlog();
  const updateBlog = useUpdateBlog();
  const deleteBlog = useDeleteBlog();
  const { toast } = useToast();
  const editorRef = useRef<HTMLDivElement>(null);

  const [activeTab, setActiveTab] = useState<"write" | "settings">("write");
  const [editingId, setEditingId] = useState<number | null>(null);
  
  const [form, setForm] = useState<EditorForm>({
    title: "",
    slug: "",
    shortDescription: "",
    contentHtml: "",
    coverImage: "",
    category: "",
    tags: [],
    readingTime: 0,
    status: "draft",
    seoTitle: "",
    seoDescription: "",
  });

  // Auto-generate slug when title changes, but only if not manually edited or editing existing
  const [slugEdited, setSlugEdited] = useState(false);

  const calculateReadingTime = (text: string) => {
    const words = text.trim().split(/\s+/).length;
    return Math.max(1, Math.ceil(words / 200));
  };

  const handleTitleChange = (val: string) => {
    setForm(prev => {
      const next = { ...prev, title: val };
      if (!slugEdited && !editingId) {
        next.slug = val.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '');
      }
      return next;
    });
  };

  const handleContentChange = (val: string) => {
    setForm(prev => ({
      ...prev,
      contentHtml: val,
      readingTime: calculateReadingTime(val)
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        toast({ title: "Image is too large", description: "Please choose an image under 5MB.", variant: "destructive" });
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setForm(prev => ({ ...prev, coverImage: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async (status: "draft" | "published") => {
    const title = form.title.trim();
    const shortDescription = form.shortDescription.trim();
    const contentHtml = form.contentHtml.trim();
    const contentText = contentHtml.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim();
    const slug = form.slug.trim() || title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)+/g, "");
    const missingFields = [
      !title && "title",
      !shortDescription && status === "published" && "short description",
      !contentText && "content",
      !slug && "slug",
      !form.category.trim() && status === "published" && "category",
    ].filter(Boolean) as string[];

    if (missingFields.length > 0) {
      toast({
        title: "Complete your article",
        description: `Add a ${missingFields.join(", ")} before ${status === "published" ? "publishing" : "saving"}.`,
        variant: "destructive",
      });
      return;
    }

    const dataToSave: BlogInput = {
      ...form,
      authorIdentifier,
      title,
      shortDescription,
      contentHtml,
      slug,
      readingTime: calculateReadingTime(contentText),
      status,
    };

    try {
      let savedSlug = slug;
      if (editingId) {
        const saved = await updateBlog.mutateAsync({ id: editingId, authorIdentifier, data: dataToSave });
        savedSlug = saved.slug;
      } else {
        const saved = await createBlog.mutateAsync(dataToSave);
        setEditingId(saved.id);
        savedSlug = saved.slug;
      }
      await refetch();

      if (status === "published") {
        setLocation(`/blog/${savedSlug}`);
        return;
      }

      toast({ title: "Draft saved", description: "Your changes were saved successfully." });
    } catch (error) {
      toast({ title: "Could not save article", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" });
    }
  };

  const runFormat = (command: string, value?: string) => {
    editorRef.current?.focus();
    document.execCommand(command, false, value);
    if (editorRef.current) handleContentChange(editorRef.current.innerHTML);
  };

  const loadBlog = (id: number) => {
    const blog = myBlogs?.find(b => b.id === id);
    if (blog) {
      setEditingId(blog.id);
      setForm({
        title: blog.title,
        slug: blog.slug,
        shortDescription: blog.shortDescription,
        contentHtml: blog.contentHtml,
        coverImage: blog.coverImage,
        category: blog.category,
        tags: blog.tags,
        readingTime: blog.readingTime,
        status: blog.status,
        seoTitle: blog.seoTitle,
        seoDescription: blog.seoDescription,
      });
      setSlugEdited(true);
    }
  };

  const handleNew = () => {
    setEditingId(null);
    setSlugEdited(false);
    setForm({
      title: "",
      slug: "",
      shortDescription: "",
      contentHtml: "",
      coverImage: "",
      category: "",
      tags: [],
      readingTime: 0,
      status: "draft",
      seoTitle: "",
      seoDescription: "",
    });
  };

  const handleDelete = async (id: number) => {
    if (authorIdentifier && confirm("Are you sure you want to delete this article?")) {
      try {
        await deleteBlog.mutateAsync({ id, authorIdentifier });
        toast({ title: "Article deleted", description: "The article was removed from your posts." });
      } catch (error) {
        toast({ title: "Could not delete article", description: error instanceof Error ? error.message : "Please try again.", variant: "destructive" });
        return;
      }
      if (editingId === id) {
        handleNew();
      }
      refetch();
    }
  };

  return (
      <AppShell role={session?.role}>
      <div className="max-w-7xl mx-auto h-[calc(100vh-100px)] flex flex-col md:flex-row gap-6">
        
        {/* Sidebar - My Posts */}
        <div className="w-full md:w-80 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">My Articles</h2>
            <button 
              onClick={handleNew}
              className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center hover:bg-primary hover:text-white transition-colors"
            >
              <PenTool className="w-4 h-4" />
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
            {!myBlogs?.length ? (
              <div className="text-sm text-muted-foreground text-center p-6 border border-dashed border-white/10 rounded-xl">
                No articles yet. Start writing!
              </div>
            ) : (
              myBlogs.map(blog => (
                <div 
                  key={blog.id} 
                  className={`p-4 rounded-xl border transition-all cursor-pointer group flex flex-col gap-2 ${
                    editingId === blog.id ? 'bg-primary/10 border-primary/30' : 'bg-white/5 border-white/10 hover:border-white/20'
                  }`}
                  onClick={() => loadBlog(blog.id)}
                >
                  <div className="flex justify-between items-start">
                    <h4 className="font-semibold text-sm line-clamp-1 flex-1 pr-2">{blog.title || "Untitled"}</h4>
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                      blog.status === 'published' ? 'bg-green-500/20 text-green-500' : 'bg-yellow-500/20 text-yellow-500'
                    }`}>
                      {blog.status}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span>{new Date(blog.updatedAt || Date.now()).toLocaleDateString()}</span>
                    <button 
                      onClick={(e) => { e.stopPropagation(); handleDelete(blog.id); }}
                      className="p-1 hover:text-red-500 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Editor Main */}
        <PremiumCard className="flex-1 flex flex-col h-full overflow-hidden border border-white/10">
          {/* Editor Header */}
          <div className="h-16 border-b border-white/10 flex items-center justify-between px-6 shrink-0 bg-background/50 backdrop-blur-md">
            <div className="flex items-center gap-1 bg-white/5 p-1 rounded-lg">
              <button
                onClick={() => setActiveTab("write")}
                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${activeTab === "write" ? "bg-white/10 text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Edit3 className="w-4 h-4" /> Write
              </button>
              <button
                onClick={() => setActiveTab("settings")}
                className={`px-4 py-1.5 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${activeTab === "settings" ? "bg-white/10 text-foreground" : "text-muted-foreground hover:text-foreground"}`}
              >
                <Settings className="w-4 h-4" /> Settings
              </button>
            </div>
            
            <div className="flex items-center gap-3">
              <span className="text-xs text-muted-foreground mr-2">
                {form.readingTime} min read
              </span>
              <PremiumButton 
                variant="outline" 
                size="sm"
                onClick={() => handleSave("draft")}
                disabled={createBlog.isPending || updateBlog.isPending}
              >
                <Save className="w-4 h-4 mr-2" /> Save Draft
              </PremiumButton>
              <PremiumButton 
                size="sm" glow
                onClick={() => handleSave("published")}
                disabled={createBlog.isPending || updateBlog.isPending}
              >
                <Send className="w-4 h-4 mr-2" /> Publish
              </PremiumButton>
            </div>
          </div>

          {/* Editor Body */}
          <div className="flex-1 overflow-y-auto p-6 lg:p-10 custom-scrollbar">
            {activeTab === "write" ? (
              <div className="max-w-3xl mx-auto space-y-8">
                {/* Title */}
                <input
                  type="text"
                  placeholder="Article Title..."
                  value={form.title}
                  onChange={(e) => handleTitleChange(e.target.value)}
                  className="w-full bg-transparent border-none text-4xl lg:text-5xl font-bold focus:outline-none placeholder:text-muted-foreground/30"
                />

                {/* Cover Image */}
                <div className="relative group">
                  {form.coverImage ? (
                    <div className="relative rounded-2xl overflow-hidden aspect-video border border-white/10">
                      <img src={form.coverImage} alt="Cover" className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                        <label className="cursor-pointer bg-white/10 hover:bg-white/20 px-4 py-2 rounded-lg backdrop-blur-md font-medium text-sm transition-colors">
                          Change Image
                          <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                        </label>
                        <button 
                          onClick={() => setForm(prev => ({...prev, coverImage: ""}))}
                          className="bg-red-500/20 text-red-500 hover:bg-red-500/30 px-4 py-2 rounded-lg backdrop-blur-md font-medium text-sm transition-colors"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  ) : (
                    <label className="cursor-pointer flex flex-col items-center justify-center w-full aspect-[21/9] rounded-2xl border-2 border-dashed border-white/10 hover:border-primary/50 hover:bg-primary/5 transition-colors text-muted-foreground group-hover:text-primary">
                      <ImagePlus className="w-8 h-8 mb-3 opacity-50 group-hover:opacity-100 transition-opacity" />
                      <span className="font-medium">Add a cover image</span>
                      <span className="text-xs mt-1 opacity-70">JPEG, PNG, WebP up to 5MB</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                    </label>
                  )}
                </div>

                {/* Rich text editor */}
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] overflow-hidden">
                  <div className="flex flex-wrap items-center gap-1 border-b border-white/10 p-2">
                    <button type="button" aria-label="Bold" onClick={() => runFormat("bold")} className="p-2 rounded-lg hover:bg-white/10"><Bold className="w-4 h-4" /></button>
                    <button type="button" aria-label="Italic" onClick={() => runFormat("italic")} className="p-2 rounded-lg hover:bg-white/10"><Italic className="w-4 h-4" /></button>
                    <button type="button" aria-label="Underline" onClick={() => runFormat("underline")} className="p-2 rounded-lg hover:bg-white/10"><Underline className="w-4 h-4" /></button>
                    <button type="button" aria-label="Heading" onClick={() => runFormat("formatBlock", "h2")} className="p-2 rounded-lg hover:bg-white/10"><Heading2 className="w-4 h-4" /></button>
                    <button type="button" aria-label="Bulleted list" onClick={() => runFormat("insertUnorderedList")} className="p-2 rounded-lg hover:bg-white/10"><List className="w-4 h-4" /></button>
                    <button type="button" aria-label="Add link" onClick={() => runFormat("createLink", window.prompt("Link URL") || "")} className="p-2 rounded-lg hover:bg-white/10"><Link2 className="w-4 h-4" /></button>
                  </div>
                  <div
                    ref={editorRef}
                    contentEditable
                    suppressContentEditableWarning
                    dangerouslySetInnerHTML={{ __html: form.contentHtml }}
                    onInput={(e) => handleContentChange(e.currentTarget.innerHTML)}
                    data-placeholder="Write your amazing article here..."
                    className="min-h-[500px] p-6 text-lg leading-relaxed text-foreground/90 [&_h2]:font-bold [&_h2]:text-[#111827] [&_h3]:font-bold [&_h3]:text-[#111827] [&_h4]:font-bold [&_h4]:text-[#111827] focus:outline-none empty:before:content-[attr(data-placeholder)] empty:before:text-muted-foreground/30"
                  />
                </div>
              </div>
            ) : (
              <div className="max-w-2xl mx-auto space-y-10">
                <div className="space-y-6">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <LayoutTemplate className="w-5 h-5 text-primary" /> Basic Info
                  </h3>
                  
                  <div className="space-y-3">
                    <label className="text-sm font-medium">Short Description</label>
                    <textarea 
                      value={form.shortDescription}
                      onChange={e => setForm(prev => ({...prev, shortDescription: e.target.value}))}
                      placeholder="A brief summary of the article..."
                      rows={3}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all resize-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <label className="text-sm font-medium">Category</label>
                      <select
                        value={form.category}
                        onChange={e => setForm(prev => ({...prev, category: e.target.value}))}
                        className="w-full h-11 bg-background border border-white/10 rounded-xl px-4 focus:outline-none focus:border-primary transition-all"
                      >
                        <option value="">Select Category</option>
                        {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>

                    <div className="space-y-3">
                      <label className="text-sm font-medium">Tags (comma separated)</label>
                      <input 
                        type="text"
                        value={form.tags.join(", ")}
                        onChange={e => setForm(prev => ({...prev, tags: e.target.value.split(",").map(t => t.trim()).filter(Boolean)}))}
                        placeholder="design, tutorial, web"
                        className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-6 pt-8 border-t border-white/10">
                  <h3 className="text-xl font-bold flex items-center gap-2">
                    <LinkIcon className="w-5 h-5 text-primary" /> SEO & URL
                  </h3>
                  
                  <div className="space-y-3">
                    <label className="text-sm font-medium">URL Slug</label>
                    <div className="flex items-center">
                      <span className="bg-white/5 border border-r-0 border-white/10 rounded-l-xl px-4 h-11 flex items-center text-muted-foreground text-sm">
                        creatorlink.com/blogs/
                      </span>
                      <input 
                        type="text"
                        value={form.slug}
                        onChange={e => {
                          setSlugEdited(true);
                          setForm(prev => ({...prev, slug: e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, '')}));
                        }}
                        className="flex-1 h-11 bg-white/5 border border-white/10 rounded-r-xl px-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                      />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium">SEO Title</label>
                    <input 
                      type="text"
                      value={form.seoTitle}
                      onChange={e => setForm(prev => ({...prev, seoTitle: e.target.value}))}
                      placeholder={form.title || "Meta Title"}
                      className="w-full h-11 bg-white/5 border border-white/10 rounded-xl px-4 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all"
                    />
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium">SEO Description</label>
                    <textarea 
                      value={form.seoDescription}
                      onChange={e => setForm(prev => ({...prev, seoDescription: e.target.value}))}
                      placeholder={form.shortDescription || "Meta Description"}
                      rows={2}
                      className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary transition-all resize-none"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </PremiumCard>
      </div>
    </AppShell>
  );
}
