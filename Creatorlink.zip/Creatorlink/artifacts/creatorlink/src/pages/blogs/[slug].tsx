import { MarketingLayout, PremiumCard } from "@/components";
import { useGetBlogBySlug, useListRelatedBlogs } from "@workspace/api-client-react";
import { Link, useParams, useLocation } from "wouter";
import { ArrowLeft, Calendar, Clock, Share2, Tag, Linkedin, Mail, Copy } from "lucide-react";
import { PremiumButton } from "@/components/ui/premium-button";
import { useEffect } from "react";

export default function BlogDetail() {
  const { slug } = useParams();
  const { data: blog, isLoading, isError } = useGetBlogBySlug(slug || "");
  const { data: relatedBlogs } = useListRelatedBlogs(slug || "");

  // Scroll to top on navigation
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [slug]);

  // Update SEO Meta tags
  useEffect(() => {
    if (blog) {
      document.title = blog.seoTitle || `${blog.title} | CreatorLink Insights`;
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute("content", blog.seoDescription || blog.shortDescription);
      } else {
        const meta = document.createElement('meta');
        meta.name = "description";
        meta.content = blog.seoDescription || blog.shortDescription;
        document.head.appendChild(meta);
      }
    }
  }, [blog]);

  if (isLoading) {
    return (
      <MarketingLayout>
        <div className="max-w-4xl mx-auto pt-32 pb-20 px-6 min-h-[80vh] flex flex-col space-y-8 animate-pulse">
          <div className="h-8 w-32 bg-white/10 rounded-full" />
          <div className="h-16 w-3/4 bg-white/10 rounded-xl" />
          <div className="flex gap-4">
            <div className="h-12 w-12 rounded-full bg-white/10" />
            <div className="space-y-2">
              <div className="h-4 w-24 bg-white/10 rounded" />
              <div className="h-4 w-32 bg-white/10 rounded" />
            </div>
          </div>
          <div className="h-96 w-full bg-white/5 rounded-2xl" />
          <div className="space-y-4">
            <div className="h-4 w-full bg-white/5 rounded" />
            <div className="h-4 w-full bg-white/5 rounded" />
            <div className="h-4 w-3/4 bg-white/5 rounded" />
          </div>
        </div>
      </MarketingLayout>
    );
  }

  if (isError || !blog) {
    return (
      <MarketingLayout>
        <div className="min-h-[80vh] flex flex-col items-center justify-center pt-32 pb-20 px-6 text-center">
          <PremiumCard className="p-12 max-w-lg mx-auto">
            <h1 className="text-3xl font-bold mb-4">Article Not Found</h1>
            <p className="text-muted-foreground mb-8">
              The article you're looking for doesn't exist or has been removed.
            </p>
            <Link href="/blog">
              <PremiumButton>Back to Insights</PremiumButton>
            </Link>
          </PremiumCard>
        </div>
      </MarketingLayout>
    );
  }

  return (
    <MarketingLayout>
      <article className="max-w-3xl mx-auto pt-32 pb-20 px-6">
        <Link href="/blog" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground transition-colors mb-10 group">
          <ArrowLeft className="w-4 h-4 mr-2 group-hover:-translate-x-1 transition-transform" />
          Back to all articles
        </Link>
        
        <header className="mb-12">
          <div className="flex items-center gap-3 mb-6">
            <span className="px-3 py-1 rounded-full bg-primary/20 text-primary text-xs font-semibold uppercase tracking-wider">
              {blog.category}
            </span>
            <span className="text-sm text-muted-foreground flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> {blog.readingTime} min read
            </span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight mb-6">
            {blog.title}
          </h1>
          
          <p className="text-xl text-muted-foreground leading-relaxed mb-8">
            {blog.shortDescription}
          </p>

          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 py-6 border-y border-white/10">
            <div className="flex items-center gap-4">
              <Link href={`/creator/${blog.authorIdentifier}`} className="flex items-center gap-3 group">
                {blog.authorProfileUrl ? (
                  <img src={blog.authorProfileUrl} alt={blog.authorName} className="w-12 h-12 rounded-full object-cover border border-white/10" />
                ) : (
                  <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center text-lg font-bold text-primary border border-white/10">
                    {blog.authorName.charAt(0)}
                  </div>
                )}
                <div>
                  <div className="font-semibold group-hover:text-primary transition-colors">{blog.authorName}</div>
                  <div className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                    <Calendar className="w-3.5 h-3.5" />
                    {new Date(blog.publishedAt || blog.createdAt).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
              </Link>
            </div>
            
            <div className="flex items-center gap-1">
              <button aria-label="Copy article link" onClick={() => navigator.clipboard.writeText(window.location.href)} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"><Copy className="w-4 h-4" /></button>
              <a aria-label="Share on LinkedIn" href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`} target="_blank" rel="noreferrer" className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"><Linkedin className="w-4 h-4" /></a>
              <a aria-label="Share by email" href={`mailto:?subject=${encodeURIComponent(blog.title)}&body=${encodeURIComponent(window.location.href)}`} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"><Mail className="w-4 h-4" /></a>
              <button aria-label="Share article" onClick={() => navigator.share?.({ title: blog.title, text: blog.shortDescription, url: window.location.href })} className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/5 transition-colors"><Share2 className="w-4 h-4" /></button>
            </div>
          </div>
        </header>

        {blog.coverImage && (
          <figure className="mb-16 -mx-6 sm:mx-0">
            <img 
              src={blog.coverImage} 
              alt={blog.title} 
              className="w-full aspect-[21/9] object-cover sm:rounded-2xl border border-white/10 shadow-2xl"
            />
          </figure>
        )}

        <div 
          className="prose prose-invert prose-lg max-w-none prose-headings:font-bold prose-h2:font-bold prose-h2:text-[#111827] prose-h3:font-bold prose-h3:text-[#111827] prose-h4:font-bold prose-h4:text-[#111827] prose-p:text-gray-600 prose-a:text-primary hover:prose-a:text-primary/80 prose-img:rounded-xl prose-img:border prose-img:border-white/10"
          dangerouslySetInnerHTML={{ __html: blog.contentHtml }}
        />

        {blog.tags && blog.tags.length > 0 && (
          <div className="mt-16 pt-8 border-t border-white/10 flex flex-wrap gap-2 items-center">
            <Tag className="w-5 h-5 text-muted-foreground mr-2" />
            {blog.tags.map(tag => (
              <span key={tag} className="px-3 py-1 rounded-full glass-pill text-xs font-medium text-muted-foreground">
                {tag}
              </span>
            ))}
          </div>
        )}
      </article>

      {/* Related Articles */}
      {relatedBlogs && relatedBlogs.length > 0 && (
        <section className="bg-white/5 border-t border-white/10 py-24 px-6 mt-12">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-3xl font-bold mb-10">Keep Reading</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {relatedBlogs.slice(0, 2).map(related => (
                <Link key={related.id} href={`/blog/${related.slug}`} className="group h-full block">
                  <PremiumCard className="h-full flex flex-col hover:-translate-y-1 transition-transform duration-300">
                    {related.coverImage && (
                      <div className="h-48 relative overflow-hidden bg-white/5">
                        <img 
                          src={related.coverImage} 
                          alt={related.title}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      </div>
                    )}
                    <div className="p-6 flex flex-col flex-1">
                      <h3 className="text-xl font-bold mb-3 group-hover:text-primary transition-colors line-clamp-2">
                        {related.title}
                      </h3>
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-4 flex-1">
                        {related.shortDescription}
                      </p>
                      <div className="text-xs text-muted-foreground flex items-center gap-1.5 mt-auto">
                        <Clock className="w-3.5 h-3.5" /> {related.readingTime} min read
                      </div>
                    </div>
                  </PremiumCard>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </MarketingLayout>
  );
}
