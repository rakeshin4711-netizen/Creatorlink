import { useEffect, useState } from "react";
import { MarketingLayout, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Eye, EyeOff, LockKeyhole, ArrowRight } from "lucide-react";
import BlogEditor from "@/pages/blogs/editor";

const BLOG_UPLOAD_AUTH_KEY = "creatorlink-upload-blog-auth";
const BLOG_UPLOAD_PASSWORD = "creatorblog";

export default function BlogUploadGate() {
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isChecking, setIsChecking] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    try {
      const authenticated =
        localStorage.getItem(BLOG_UPLOAD_AUTH_KEY) === "true";

      setIsAuthenticated(authenticated);
    } catch {
      setIsAuthenticated(false);
    } finally {
      setIsChecking(false);
    }
  }, []);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (password.trim() !== BLOG_UPLOAD_PASSWORD) {
      setError("Incorrect password");
      return;
    }

    try {
      localStorage.setItem(BLOG_UPLOAD_AUTH_KEY, "true");
    } catch {
      // Continue even if localStorage is unavailable
    }

    setError("");
    setIsAuthenticated(true);
  };

  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <BlogEditor />;
  }

  return (
    <MarketingLayout>
      <div className="min-h-[80vh] flex items-center justify-center px-4 relative pt-20">
        <div className="ambient-glow ambient-glow-primary -left-40 top-1/2 -translate-y-1/2" />

        <div className="w-full max-w-md relative z-10">
          <PremiumCard className="p-8 md:p-10 border-white/20">
            <div className="flex flex-col items-center mb-8">
              <div className="w-12 h-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center mb-4">
                <LockKeyhole className="w-6 h-6" />
              </div>

              <h1 className="text-2xl font-bold tracking-tight">
                Upload Blog
              </h1>

              <p className="text-muted-foreground mt-2 text-sm text-center">
                Enter the password to access the blog editor
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <label
                  htmlFor="upload-blog-password"
                  className="text-sm font-medium text-foreground"
                >
                  Password
                </label>

                <div className="relative">
                  <input
                    id="upload-blog-password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(event) => {
                      setPassword(event.target.value);
                      if (error) setError("");
                    }}
                    className="w-full h-11 px-4 pr-11 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all placeholder:text-muted-foreground/50"
                    placeholder="Enter password"
                    autoFocus
                    required
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword((visible) => !visible)}
                    aria-label={
                      showPassword ? "Hide password" : "Show password"
                    }
                    className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground hover:text-foreground"
                  >
                    {showPassword ? (
                      <EyeOff className="w-4 h-4" />
                    ) : (
                      <Eye className="w-4 h-4" />
                    )}
                  </button>
                </div>

                {error && (
                  <p className="text-sm text-destructive">{error}</p>
                )}
              </div>

              <PremiumButton
                type="submit"
                className="w-full mt-6"
                glow
              >
                Continue
                <ArrowRight className="w-4 h-4 ml-2" />
              </PremiumButton>
            </form>
          </PremiumCard>
        </div>
      </div>
    </MarketingLayout>
  );
}