import { MarketingLayout, PremiumCard } from "@/components";
import { useListPublishedBlogs } from "@workspace/api-client-react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Search, Calendar, Clock, ArrowRight } from "lucide-react";
import { useState } from "react";
import { CATEGORIES } from "@/lib/categories";

export default function BlogList() {
  const { data: blogs, isLoading } = useListPublishedBlogs();
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");

  const filteredBlogs = (blogs || []).filter(blog => {
    const matchesSearch = blog.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          blog.shortDescription.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === "All" || blog.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <MarketingLayout>
      <section className="relative pt-32 pb-20 px-6 text-center overflow-hidden">
        <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
        <div className="z-10 relative max-w-4xl mx-auto space-y-6">
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
            CreatorLink <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Insights</span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
            Trends, tutorials, and stories from the frontlines of the digital creator economy.
          </p>
          
          <div className="max-w-xl mx-auto pt-8">
            <div className="relative flex items-center glass-panel rounded-full p-2">
              <Search className="w-5 h-5 text-muted-foreground ml-4 absolute pointer-events-none" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 bg-transparent border-none focus:outline-none pl-12 pr-4 py-2 text-foreground"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
            {["All", ...CATEGORIES.slice(0, 6)].map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${
                  selectedCategory === cat 
                    ? "bg-primary text-primary-foreground" 
                    : "glass hover:bg-white/10"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 px-6 max-w-7xl mx-auto min-h-[50vh]">
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map(i => (
              <PremiumCard key={i} className="h-96 animate-pulse opacity-50 flex flex-col">
                <div className="h-48 bg-white/5" />
                <div className="p-6 space-y-4 flex-1">
                  <div className="h-6 w-1/3 bg-white/5 rounded" />
                  <div className="h-8 w-3/4 bg-white/10 rounded" />
                  <div className="h-4 w-full bg-white/5 rounded" />
                  <div className="h-4 w-2/3 bg-white/5 rounded" />
                </div>
              </PremiumCard>
            ))}
          </div>
        ) : filteredBlogs.length > 0 ? (
          <div className="space-y-12">
            <Link href={`/blog/${filteredBlogs[0].slug}`} className="block group">
              <PremiumCard className="overflow-hidden md:flex hover:-translate-y-1 transition-transform duration-300">
                <div className="h-64 md:h-auto md:w-1/2 relative overflow-hidden bg-white/5">
                  {filteredBlogs[0].coverImage ? (
                    <img src={filteredBlogs[0].coverImage} alt={filteredBlogs[0].title} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105" />
                  ) : (
                    <div className="w-full h-full min-h-64 flex items-center justify-center text-muted-foreground bg-primary/10">No Cover Image</div>
                  )}
                  <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-primary">Featured</div>
                </div>
                <div className="p-8 md:w-1/2 flex flex-col justify-center">
                  <span className="text-xs uppercase tracking-wider font-semibold text-primary mb-4">{filteredBlogs[0].category}</span>
                  <h2 className="text-3xl md:text-4xl font-bold mb-4 group-hover:text-primary transition-colors">{filteredBlogs[0].title}</h2>
                  <p className="text-muted-foreground leading-relaxed mb-8">{filteredBlogs[0].shortDescription}</p>
                  <div className="flex flex-wrap items-center gap-4 text-xs text-muted-foreground">
                    <span className="font-medium text-foreground">{filteredBlogs[0].authorName}</span>
                    <span className="flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5" />{new Date(filteredBlogs[0].publishedAt || filteredBlogs[0].createdAt).toLocaleDateString()}</span>
                    <span className="flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" />{filteredBlogs[0].readingTime} min read</span>
                  </div>
                </div>
              </PremiumCard>
            </Link>

            {filteredBlogs.length > 1 && (
              <div>
                <h2 className="text-2xl font-bold mb-6">Latest posts</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredBlogs.slice(1).map((blog, index) => (
              <motion.div
                key={blog.id}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="h-full"
              >
                <Link href={`/blog/${blog.slug}`} className="h-full block group">
                  <PremiumCard className="h-full flex flex-col hover:-translate-y-1 transition-transform duration-300">
                    <div className="h-48 relative overflow-hidden bg-white/5">
                      {blog.coverImage ? (
                        <img 
                          src={blog.coverImage} 
                          alt={blog.title}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-muted-foreground bg-primary/10">
                          No Cover Image
                        </div>
                      )}
                      <div className="absolute top-4 left-4 bg-background/80 backdrop-blur-md px-3 py-1 rounded-full text-xs font-semibold text-primary">
                        {blog.category}
                      </div>
                    </div>
                    
                    <div className="p-6 flex-1 flex flex-col">
                      <h3 className="text-xl font-bold mb-3 line-clamp-2 group-hover:text-primary transition-colors">
                        {blog.title}
                      </h3>
                      <p className="text-muted-foreground text-sm line-clamp-3 mb-6 flex-1">
                        {blog.shortDescription}
                      </p>
                      
                      <div className="mt-auto border-t border-white/5 pt-4 flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-4">
                          <span className="flex items-center gap-1.5">
                            <Calendar className="w-3.5 h-3.5" />
                            {new Date(blog.publishedAt || blog.createdAt).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5" />
                            {blog.readingTime} min read
                          </span>
                        </div>
                        <ArrowRight className="w-4 h-4 group-hover:translate-x-1 group-hover:text-primary transition-all" />
                      </div>
                    </div>
                  </PremiumCard>
                </Link>
              </motion.div>
            ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="text-center py-20">
            <PremiumCard className="inline-block p-12 text-center max-w-md mx-auto">
              <h3 className="text-xl font-bold mb-2">No articles found</h3>
              <p className="text-muted-foreground">
                {searchQuery ? "Try adjusting your search or category filters." : "We haven't published any articles yet. Check back soon!"}
              </p>
            </PremiumCard>
          </div>
        )}
      </section>
    </MarketingLayout>
  );
}
