import { MarketingLayout, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { CATEGORIES } from "@/lib/categories";
import { motion, useScroll, useTransform } from "framer-motion";
import { Search, Star, ArrowRight, ShieldCheck, Zap, Sparkles } from "lucide-react";
import { Link } from "wouter";
import { useListCreators } from "@workspace/api-client-react";
import { formatHourlyRate } from "@/lib/currency";

export default function LandingPage() {
  const creatorsQuery = useListCreators();
  const creators = creatorsQuery.data ?? [];
  const { scrollYProgress } = useScroll();
  const y1 = useTransform(scrollYProgress, [0, 1], [0, 200]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -100]);

  return (
    <MarketingLayout>
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex flex-col items-center justify-center pt-32 pb-20 px-4 text-center overflow-hidden">
        <motion.div style={{ y: y2 }} className="absolute inset-0 pointer-events-none flex items-center justify-center opacity-40">
          <div className="w-[800px] h-[800px] border border-white/5 rounded-full absolute" />
          <div className="w-[600px] h-[600px] border border-white/5 rounded-full absolute" />
          <div className="w-[400px] h-[400px] border border-white/5 rounded-full absolute" />
        </motion.div>

        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="z-10 max-w-4xl mx-auto flex flex-col items-center"
        >
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass-pill text-sm font-medium text-primary mb-8">
            <Sparkles className="w-4 h-4" />
            <span>The New Standard for Creative Work</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6 leading-tight">
            Hire Elite Creative <br className="hidden md:block"/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">
              Talent on Demand.
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl">
            A premium marketplace connecting visionary brands with world-class designers, editors, and artists. No bidding wars. Just exceptional work.
          </p>

          <div className="w-full max-w-2xl relative">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary/30 to-accent/30 rounded-[2rem] blur-xl opacity-50" />
            <div className="relative glass-panel rounded-full p-2 flex items-center shadow-2xl">
              <div className="pl-4 text-muted-foreground">
                <Search className="w-6 h-6" />
              </div>
              <input 
                type="text" 
                placeholder="What are you looking for? e.g. 'Motion Designer'" 
                className="flex-1 bg-transparent border-none focus:outline-none px-4 text-lg text-foreground placeholder:text-muted-foreground"
              />
              <PremiumButton size="lg" className="px-8 rounded-full">
                Search
              </PremiumButton>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-2 mt-8">
            {CATEGORIES.slice(0, 5).map((cat, i) => (
              <motion.button 
                key={cat}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 + (i * 0.1) }}
                className="px-4 py-2 rounded-full glass hover:bg-white/10 text-sm font-medium transition-colors"
              >
                {cat}
              </motion.button>
            ))}
          </div>
        </motion.div>
      </section>

      {/* Featured Talent Section */}
      <section className="py-32 px-6 relative z-10">
        <div className="max-w-7xl mx-auto">
          <div className="flex justify-between items-end mb-16">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-4">Featured Talent</h2>
              <p className="text-muted-foreground text-lg">Curated professionals ready for your next project.</p>
            </div>
            <Link href="/search" className="hidden md:flex items-center gap-2 text-primary hover:text-primary/80 font-medium group transition-colors">
              View All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {creators.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 perspective-[1000px]">
            {creators.map((creator, index) => (
              <motion.div
                key={creator.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                className="h-full"
              >
                <Link href={`/creator/${creator.username}`} className="h-full">
                <PremiumCard className="h-full flex flex-col hover:rotate-y-[5deg] hover:rotate-x-[5deg] group transition-all duration-300 transform-gpu cursor-pointer">
                  <div className="h-32 relative overflow-hidden">
                    <div className="w-full h-full bg-gradient-to-br from-primary/40 via-primary/10 to-accent/30 transition-transform duration-700 group-hover:scale-110" />
                    <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                  </div>
                  <div className="px-5 pb-5 relative flex-1 flex flex-col">
                    <div className="absolute -top-10 left-5">
                      {creator.profilePhoto ? (
                        <img src={creator.profilePhoto} alt={creator.fullName} className="w-16 h-16 rounded-xl object-cover border-2 border-background shadow-lg" />
                      ) : (
                        <div className="w-16 h-16 rounded-xl bg-primary/30 border-2 border-background shadow-lg flex items-center justify-center text-xl font-bold">
                          {creator.fullName.slice(0, 1).toUpperCase()}
                        </div>
                      )}
                    </div>
                    <div className="flex justify-end pt-2 mb-4">
                      <div className="flex items-center gap-1 bg-black/40 backdrop-blur-md px-2 py-1 rounded-md text-xs font-semibold text-white">
                        <Star className="w-3 h-3 fill-accent text-accent" />
                        No reviews
                      </div>
                    </div>
                    <h3 className="font-bold text-lg leading-tight">{creator.fullName}</h3>
                    <p className="text-sm text-primary font-medium mb-3">{creator.category || "Creator"}</p>
                    <div className="flex flex-wrap gap-1 mt-auto">
                      {creator.skills.slice(0, 2).map(skill => (
                        <span key={skill} className="text-[10px] uppercase tracking-wider px-2 py-1 rounded-sm bg-white/5 text-muted-foreground border border-white/10">
                          {skill}
                        </span>
                      ))}
                    </div>
                    <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-sm">
                      <span className="font-semibold">{formatHourlyRate(creator.hourlyRate)}</span>
                       <span className="text-muted-foreground">Profile available</span>
                    </div>
                  </div>
                </PremiumCard>
                </Link>
              </motion.div>
            ))}
            </div>
          ) : (
            <PremiumCard className="p-8 border-dashed border-white/10 text-center text-muted-foreground">
              No creators have joined yet.
            </PremiumCard>
          )}
        </div>
      </section>

      {/* How it Works / Trust */}
      <section className="py-32 px-6 relative bg-white/5 border-y border-white/10">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-16 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="space-y-8"
            >
              <h2 className="text-4xl font-bold leading-tight">Built for quality.<br/>Designed for speed.</h2>
              
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-primary/20 flex items-center justify-center shrink-0 text-primary">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">Vetted Professionals</h4>
                    <p className="text-muted-foreground">Every creator on our platform passes a rigorous portfolio review. We accept less than 5% of applicants.</p>
                  </div>
                </div>
                
                <div className="flex gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-accent/20 flex items-center justify-center shrink-0 text-accent">
                    <Zap className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="text-xl font-semibold mb-2">Fixed-Price Packages</h4>
                    <p className="text-muted-foreground">Know exactly what you'll pay and when it will be delivered. No scope creep, no surprises.</p>
                  </div>
                </div>
              </div>

              <PremiumButton size="lg" className="mt-4 group">
                Find your expert <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </PremiumButton>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="relative h-[600px] w-full"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 rounded-3xl blur-3xl" />
              <PremiumCard className="absolute top-10 left-10 right-10 bottom-10 p-6 flex flex-col border border-white/20 shadow-2xl">
                <div className="flex items-center gap-4 border-b border-white/10 pb-4 mb-4">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <div className="text-xs text-muted-foreground mx-auto font-mono">creatorlink.com/project</div>
                </div>
                {/* Product preview */}
                <div className="space-y-4 flex-1 opacity-70">
                  <div className="h-8 w-1/3 bg-white/10 rounded-lg animate-pulse" />
                  <div className="h-4 w-1/2 bg-white/5 rounded-full" />
                  <div className="h-4 w-2/3 bg-white/5 rounded-full" />
                  <div className="mt-8 grid grid-cols-2 gap-4">
                    <div className="h-32 bg-white/5 rounded-xl border border-white/10" />
                    <div className="h-32 bg-white/5 rounded-xl border border-white/10" />
                  </div>
                </div>
                <div className="mt-auto pt-4 flex justify-between items-center border-t border-white/10">
                  <div className="h-10 w-24 bg-primary/20 rounded-full" />
                  <div className="h-10 w-32 bg-white/10 rounded-full" />
                </div>
              </PremiumCard>
              
              {/* Floating elements for parallax depth effect */}
              <motion.div 
                style={{ y: y1 }}
                className="absolute -right-8 top-32 glass-panel p-4 rounded-xl flex items-center gap-3 shadow-2xl"
              >
                <div className="w-10 h-10 rounded-full bg-green-500/20 flex items-center justify-center text-green-500">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-sm font-bold">Approved</div>
                  <div className="text-xs text-muted-foreground">Just now</div>
                </div>
              </motion.div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-32 px-6 text-center relative overflow-hidden">
        <div className="absolute inset-0 bg-primary/10" />
        <div className="ambient-glow ambient-glow-accent bottom-0 left-1/2 -translate-x-1/2" />
        
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative z-10 max-w-2xl mx-auto space-y-8"
        >
          <h2 className="text-5xl font-bold tracking-tight">Ready to create?</h2>
          <p className="text-xl text-muted-foreground">Join thousands of brands and creators building the future of digital content.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4 pt-4">
            <Link href="/signup">
              <PremiumButton size="lg" glow className="w-full sm:w-auto">Get Started</PremiumButton>
            </Link>
            <Link href="/search">
              <PremiumButton variant="outline" size="lg" className="w-full sm:w-auto">Browse Portfolios</PremiumButton>
            </Link>
          </div>
        </motion.div>
      </section>

    </MarketingLayout>
  );
}
