import { MarketingLayout } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Link } from "wouter";
import { motion } from "framer-motion";
import { Hexagon, Home } from "lucide-react";

export default function NotFound() {
  return (
    <MarketingLayout>
      <div className="min-h-[80vh] flex flex-col items-center justify-center px-4 relative">
        <div className="ambient-glow ambient-glow-primary opacity-50" />
        
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: "spring" }}
          className="relative z-10 text-center flex flex-col items-center"
        >
          <div className="relative w-48 h-48 mb-8 flex items-center justify-center">
            <Hexagon className="w-full h-full text-white/5 absolute" strokeWidth={0.5} />
            <Hexagon className="w-3/4 h-3/4 text-primary/20 absolute animate-[spin_10s_linear_infinite]" strokeWidth={1} />
            <h1 className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-br from-primary to-accent relative z-10 text-glow">
              404
            </h1>
          </div>
          
          <h2 className="text-3xl font-bold mb-4 tracking-tight">Page not found</h2>
          <p className="text-muted-foreground max-w-md mb-8">
            The link you clicked may be broken or the page may have been removed. We couldn't find the creative space you were looking for.
          </p>
          
          <Link href="/">
            <PremiumButton size="lg" className="px-8 rounded-full" glow>
              <Home className="w-4 h-4 mr-2" />
              Return Home
            </PremiumButton>
          </Link>
        </motion.div>
      </div>
    </MarketingLayout>
  );
}
