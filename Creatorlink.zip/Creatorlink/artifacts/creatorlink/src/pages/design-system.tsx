import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { Sun, Moon, Eye, EyeOff, Hexagon, LockKeyhole, LogOut } from "lucide-react";

/* ─── types ──────────────────────────────────────────────────── */
type Swatch = [string, string, string]; // [name, hex, token]

/* ─── data ───────────────────────────────────────────────────── */
const surfaces: Swatch[] = [
  ["background", "#050816", "--background"],
  ["surface-1",  "#0B1020", "--card"],
  ["surface-2",  "#101827", "--surface-2"],
  ["surface-3",  "#182135", "--surface-3"],
];
const brandColors: Swatch[] = [
  ["primary",   "#8B5CF6", "--primary"],
  ["secondary", "#3B82F6", "--secondary"],
  ["accent",    "#06B6D4", "--accent"],
];
const semanticColors: Swatch[] = [
  ["success",     "#22C55E", "--success"],
  ["warning",     "#F59E0B", "--warning"],
  ["destructive", "#EF4444", "--destructive"],
];
const textColors: Swatch[] = [
  ["foreground",        "#FFFFFF",  "--foreground"],
  ["foreground-2",      "#C7CBD6",  "--fg2"],
  ["muted-foreground",  "#8A90A2",  "--muted-foreground"],
];

const spaces: [number, number][] = [
  [1,4],[2,8],[3,12],[4,16],[5,20],[6,24],[8,32],[10,40],[12,48],[16,64],[24,96],
];

const sparkBars = [38, 54, 32, 68, 50, 84, 62, 92];

const sections = [
  { id: "color",     label: "Color",           group: "Foundations" },
  { id: "type",      label: "Typography",      group: "Foundations" },
  { id: "space",     label: "Spacing",         group: "Foundations" },
  { id: "radius",    label: "Radius",          group: "Foundations" },
  { id: "elevation", label: "Elevation & Glass", group: "Foundations" },
  { id: "buttons",   label: "Buttons",         group: "Components" },
  { id: "inputs",    label: "Inputs",          group: "Components" },
  { id: "badges",    label: "Badges & Status", group: "Components" },
  { id: "avatars",   label: "Avatars",         group: "Components" },
  { id: "cards",     label: "Cards",           group: "Components" },
  { id: "tabs",      label: "Tabs",            group: "Components" },
  { id: "feedback",  label: "Feedback",        group: "Components" },
  { id: "loading",   label: "Loading & Empty", group: "Components" },
  { id: "a11y",      label: "Accessibility",   group: "Rules" },
  { id: "motion",    label: "Motion",          group: "Rules" },
];

/* ─── sub-components ─────────────────────────────────────────── */

function SwatchCard({ name, hex, token }: { name: string; hex: string; token: string }) {
  const [copied, setCopied] = useState(false);

  const copy = () => {
    const value = `hsl(var(${token}))`;
    navigator.clipboard?.writeText(value).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    });
  };

  return (
    <div
      className="rounded-2xl overflow-hidden border border-white/10 cursor-pointer transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_12px_40px_-12px_rgba(0,0,0,.6)]"
      onClick={copy}
      role="button"
      tabIndex={0}
      aria-label={`Copy token ${token}`}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && copy()}
      data-testid={`swatch-${name}`}
    >
      <div className="h-20" style={{ background: hex }} />
      <div className="px-3 py-2.5 bg-[#0B1020]">
        <div className="text-[12.5px] font-semibold text-foreground">{copied ? "Copied!" : name}</div>
        <div className="text-[10.5px] font-mono text-muted-foreground mt-0.5">{hex}</div>
      </div>
    </div>
  );
}

function SwatchGroup({ swatches, cols = 4 }: { swatches: Swatch[]; cols?: number }) {
  const gridCols: Record<number, string> = {
    3: "grid-cols-1 sm:grid-cols-3",
    4: "grid-cols-2 sm:grid-cols-4",
    6: "grid-cols-2 sm:grid-cols-6",
  };
  return (
    <div className={`grid gap-3 ${gridCols[cols] ?? "grid-cols-2 sm:grid-cols-4"}`}>
      {swatches.map(([n, h, t]) => (
        <SwatchCard key={t} name={n} hex={h} token={t} />
      ))}
    </div>
  );
}

function SectionHeader({ title, note }: { title: string; note?: string }) {
  return (
    <>
      <h2 className="text-[1.42rem] font-bold tracking-[-0.032em]">{title}</h2>
      {note && <p className="text-sm text-muted-foreground leading-relaxed mt-1.5 mb-5 max-w-2xl">{note}</p>}
    </>
  );
}

function Panel({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={`relative rounded-3xl border border-white/10 p-6 overflow-hidden ${className}`}
      style={{ background: "var(--glass)", backdropFilter: "blur(28px) saturate(180%)" }}
    >
      {/* specular highlight */}
      <span className="pointer-events-none absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent opacity-60" />
      {children}
    </div>
  );
}

function TableRow({ label, value, mono = false }: { label: React.ReactNode; value: string; mono?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-5 py-3.5 border-b border-white/[0.06] last:border-0 flex-wrap">
      <span className="text-sm text-foreground">{label}</span>
      <span className={`text-xs text-muted-foreground whitespace-nowrap ${mono ? "font-mono" : ""}`}>{value}</span>
    </div>
  );
}

function Code({ children }: { children: React.ReactNode }) {
  return (
    <code className="font-mono text-xs bg-white/[0.03] border border-white/[0.06] rounded px-1.5 py-0.5 text-muted-foreground">
      {children}
    </code>
  );
}

/* ─── Toast flash ────────────────────────────────────────────── */
function useFlash() {
  const [msg, setMsg] = useState("");
  const [visible, setVisible] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const flash = (m: string) => {
    setMsg(m);
    setVisible(true);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setVisible(false), 2200);
  };

  return { msg, visible, flash };
}

/* ─── Toggle component ───────────────────────────────────────── */
function Toggle({ defaultOn = true }: { defaultOn?: boolean }) {
  const [on, setOn] = useState(defaultOn);
  return (
    <button
      role="switch"
      aria-checked={on}
      aria-label="Toggle"
      onClick={() => setOn(!on)}
      data-testid="toggle-switch"
      className="relative w-11 h-6.5 rounded-full border flex-shrink-0 transition-all duration-300"
      style={{
        background: on ? "linear-gradient(120deg,#8B5CF6,#3B82F6)" : "var(--surface-3, #182135)",
        borderColor: on ? "transparent" : "var(--stroke, rgba(255,255,255,.10))",
      }}
    >
      <span
        className="absolute top-0.5 w-5 h-5 rounded-full transition-all duration-300"
        style={{
          left: on ? "calc(100% - 22px)" : "2px",
          background: on ? "#fff" : "var(--muted-foreground, #8A90A2)",
        }}
      />
    </button>
  );
}

/* ─── Tab component ──────────────────────────────────────────── */
function TabDemo() {
  const [active, setActive] = useState(0);
  const items = ["Overview", "Portfolio", "Reviews"];

  return (
    <div
      role="tablist"
      className="inline-flex p-1 rounded-2xl border gap-1"
      style={{ background: "var(--glass)", borderColor: "var(--stroke)" }}
    >
      {items.map((item, i) => (
        <button
          key={item}
          role="tab"
          aria-selected={active === i}
          onClick={() => setActive(i)}
          onKeyDown={(e) => {
            if (e.key === "ArrowRight") setActive((active + 1) % items.length);
            if (e.key === "ArrowLeft")  setActive((active - 1 + items.length) % items.length);
          }}
          data-testid={`tab-${item.toLowerCase()}`}
          className="px-4 py-2 rounded-xl border-none text-[13px] font-semibold cursor-pointer transition-all duration-300"
          style={{
            background: active === i ? "linear-gradient(120deg,#8B5CF6,#3B82F6)" : "transparent",
            color: active === i ? "#fff" : "var(--muted-foreground)",
            boxShadow: active === i ? "0 6px 18px -8px rgba(139,92,246,.8)" : "none",
          }}
        >
          {item}
        </button>
      ))}
    </div>
  );
}

/* ─── Loading Button ─────────────────────────────────────────── */
function LoadingButton({ flash }: { flash: (m: string) => void }) {
  const [loading, setLoading] = useState(false);
  const handle = () => {
    if (loading) return;
    setLoading(true);
    setTimeout(() => { setLoading(false); flash("Async action complete"); }, 1400);
  };
  return (
    <button
      onClick={handle}
      disabled={loading}
      data-testid="btn-loading-demo"
      className="relative inline-flex items-center gap-2 px-5 py-2.5 rounded-2xl text-sm font-semibold border cursor-pointer overflow-hidden transition-all duration-300 hover:-translate-y-0.5 disabled:opacity-70"
      style={{ background: "var(--glass)", borderColor: "var(--stroke)", color: "var(--foreground)" }}
    >
      {loading ? "Working…" : "Click for loading state"}
    </button>
  );
}

/* ─── Sidebar active-section tracker ────────────────────────── */
function useSectionObserver(enabled = true) {
  const [active, setActive] = useState("color");
  useEffect(() => {
    if (!enabled) return;

    const els = document.querySelectorAll<HTMLElement>("[data-section]");
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => {
          if (e.isIntersecting) setActive(e.target.id);
        });
      },
      { rootMargin: "-10% 0px -75%" }
    );
    els.forEach((el) => obs.observe(el));
    return () => obs.disconnect();
  }, [enabled]);
  return active;
}

const DESIGN_SYSTEM_PASSWORD = "CreatoR@4711@";
const DESIGN_SYSTEM_AUTH_KEY = "creatorlink-design-system-auth";

function DesignSystemPasswordGate({
  onAuthenticated,
}: {
  onAuthenticated: () => void;
}) {
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [focused, setFocused] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (password === DESIGN_SYSTEM_PASSWORD) {
      localStorage.setItem(DESIGN_SYSTEM_AUTH_KEY, "true");
      setError(false);
      onAuthenticated();
      return;
    }

    setError(true);
  };

  return (
    <div
      className="relative min-h-screen overflow-hidden font-sans flex items-center justify-center px-6 py-12"
      style={{ background: "var(--bg, hsl(var(--background)))" }}
    >
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div
          className="orb orb-primary absolute"
          style={{
            width: 680,
            height: 680,
            top: "-28%",
            left: "-14%",
            animation: "gateOrbDrift1 26s ease-in-out infinite",
          }}
        />
        <div
          className="orb orb-accent absolute"
          style={{
            width: 560,
            height: 560,
            bottom: "-22%",
            right: "-12%",
            animation: "gateOrbDrift2 32s ease-in-out infinite",
          }}
        />
      </div>

      <style>{`
        @keyframes gateOrbDrift1 {
          0%,100% { transform: translate(0,0) scale(1); }
          50% { transform: translate(120px,120px) scale(1.12); }
        }
        @keyframes gateOrbDrift2 {
          0%,100% { transform: translate(0,0) scale(1); }
          50% { transform: translate(-120px,-100px) scale(1.1); }
        }
      `}</style>

      <main
        className="relative z-10 w-full max-w-[460px] rounded-[32px] border p-7 sm:p-9"
        style={{
          background: "var(--glass)",
          backdropFilter: "blur(32px) saturate(180%)",
          borderColor: "var(--stroke)",
          boxShadow: "0 30px 80px -20px rgba(0,0,0,.72)",
        }}
      >
        <span className="pointer-events-none absolute top-0 left-8 right-8 h-px bg-gradient-to-r from-transparent via-white/60 to-transparent" />

        <div className="flex items-center gap-2.5 mb-10">
          <div
            className="w-9 h-9 rounded-[11px] flex items-center justify-center shadow-[0_8px_28px_-6px_rgba(139,92,246,.7)]"
            style={{ background: "linear-gradient(135deg,#8B5CF6,#3B82F6 52%,#06B6D4)" }}
          >
            <Hexagon className="w-[18px] h-[18px] text-white" />
          </div>
          <span className="font-bold text-[17px] tracking-tight">CreatorLink</span>
        </div>

        <div
          className="w-14 h-14 rounded-[18px] grid place-items-center mb-6 border"
          style={{
            background: "linear-gradient(135deg,rgba(139,92,246,.22),rgba(6,182,212,.1))",
            borderColor: "rgba(139,92,246,.28)",
            boxShadow: "0 14px 34px -16px rgba(139,92,246,.7)",
          }}
        >
          <LockKeyhole className="w-6 h-6 text-primary" strokeWidth={1.8} />
        </div>

        <p className="text-[11px] font-bold tracking-[0.12em] uppercase text-primary mb-3">
          Private workspace
        </p>
        <h1 className="text-[clamp(1.8rem,6vw,2.4rem)] font-extrabold tracking-[-0.045em] leading-[1.05]">
          Design System
        </h1>
        <p className="text-sm text-muted-foreground leading-relaxed mt-3 max-w-[350px]">
          Enter the workspace password to view CreatorLink&apos;s visual language,
          component rules, and accessibility standards.
        </p>

        <form onSubmit={handleSubmit} className="mt-8">
          <label
            htmlFor="design-system-password"
            className="block text-[12.5px] font-semibold mb-2"
            style={{ color: "hsl(var(--foreground) / 0.82)" }}
          >
            Workspace password
          </label>
          <div
            className="rounded-2xl transition-all duration-300"
            style={{
              boxShadow: focused
                ? "0 0 0 4px rgba(139,92,246,.14)"
                : error
                  ? "0 0 0 4px rgba(239,68,68,.12)"
                  : "none",
            }}
          >
            <div className="relative">
              <input
                id="design-system-password"
                type={showPassword ? "text" : "password"}
                autoFocus
                autoComplete="current-password"
                value={password}
                onChange={(event) => {
                  setPassword(event.target.value);
                  if (error) setError(false);
                }}
                onFocus={() => setFocused(true)}
                onBlur={() => setFocused(false)}
                aria-invalid={error}
                aria-describedby={error ? "design-system-password-error" : undefined}
                placeholder="Enter password"
                data-testid="input-design-system-password"
                className="w-full px-4 pr-12 py-3 rounded-2xl text-sm font-medium outline-none transition-all duration-300"
                style={{
                  background: "var(--glass-2)",
                  border: `1px solid ${
                    error ? "hsl(var(--destructive))" : focused ? "rgba(139,92,246,.65)" : "var(--stroke)"
                  }`,
                  color: "hsl(var(--foreground))",
                }}
              />
              <button
                type="button"
                onClick={() => setShowPassword((visible) => !visible)}
                aria-label={showPassword ? "Hide password" : "Show password"}
                title={showPassword ? "Hide password" : "Show password"}
                className="absolute inset-y-0 right-0 flex w-12 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>
          <div className="min-h-5 mt-2">
            {error && (
              <p
                id="design-system-password-error"
                className="text-[12px]"
                style={{ color: "hsl(var(--destructive))" }}
                role="alert"
              >
                Incorrect password
              </p>
            )}
          </div>

          <button
            type="submit"
            data-testid="btn-design-system-submit"
            className="w-full mt-4 inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5 active:translate-y-0"
            style={{
              background: "linear-gradient(120deg,#8B5CF6,#3B82F6 50%,#06B6D4)",
              backgroundSize: "220% 100%",
              boxShadow: "0 14px 34px -11px rgba(139,92,246,.72)",
              animation: "gradientPan 7s ease infinite",
            }}
          >
            Unlock design system
          </button>
        </form>

        <p className="text-[11px] text-muted-foreground text-center mt-6">
          Press Enter to unlock
        </p>
      </main>
    </div>
  );
}

/* ─── Main page ──────────────────────────────────────────────── */
export default function DesignSystemPage() {
  const [authenticated, setAuthenticated] = useState(
    () => localStorage.getItem(DESIGN_SYSTEM_AUTH_KEY) === "true"
  );
  const activeSection = useSectionObserver(authenticated);
  const { msg, visible, flash } = useFlash();
  const [isDark, setIsDark] = useState(
    () => document.documentElement.classList.contains("dark")
  );

  const logout = () => {
    localStorage.removeItem(DESIGN_SYSTEM_AUTH_KEY);
    setAuthenticated(false);
  };

  if (!authenticated) {
    return <DesignSystemPasswordGate onAuthenticated={() => setAuthenticated(true)} />;
  }

  const toggleTheme = () => {
    const next = !isDark;
    setIsDark(next);
    if (next) {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
    localStorage.setItem("theme", next ? "dark" : "light");
  };

  /* group sidebar items */
  const groups = ["Foundations", "Components", "Rules"];

  return (
    <div className="relative min-h-screen font-sans" style={{ background: "var(--bg, hsl(var(--background)))" }}>
      {/* Ambient orbs */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div
          className="orb orb-primary absolute"
          style={{ width: 600, height: 600, top: "-16%", left: "-8%",
            animation: "orbDrift1 28s ease-in-out infinite" }}
        />
        <div
          className="orb orb-accent absolute"
          style={{ width: 520, height: 520, bottom: "8%", right: "-10%",
            animation: "orbDrift2 34s ease-in-out infinite" }}
        />
      </div>

      <style>{`
        @keyframes orbDrift1 {
          0%,100% { transform: translate(0,0); }
          50%      { transform: translate(120px,140px) scale(1.15); }
        }
        @keyframes orbDrift2 {
          0%,100% { transform: translate(0,0); }
          50%      { transform: translate(-140px,-90px) scale(1.12); }
        }
      `}</style>

      <div className="relative z-10 flex min-h-screen">
        {/* ── Sidebar ── */}
        <aside
          className="hidden md:flex flex-col sticky top-0 h-screen w-[250px] shrink-0 overflow-y-auto py-6 px-4 border-r"
          style={{
            background: "var(--glass)",
            backdropFilter: "blur(28px) saturate(180%)",
            borderColor: "var(--stroke-2, rgba(255,255,255,.06))",
          }}
        >
          {/* Brand */}
          <Link href="/" className="flex items-center gap-2.5 font-bold text-[16.5px] tracking-tight mb-7 hover:opacity-80 transition-opacity" data-testid="ds-home-link">
            <div className="w-8 h-8 rounded-[10px] flex items-center justify-center shadow-[0_6px_22px_-4px_rgba(139,92,246,.6)]"
              style={{ background: "linear-gradient(135deg,#8B5CF6,#3B82F6 52%,#06B6D4)" }}>
              <Hexagon className="w-4 h-4 text-white" />
            </div>
            CreatorLink
          </Link>

          {groups.map((group) => {
            const items = sections.filter((s) => s.group === group);
            return (
              <div key={group} className="mb-2">
                <p className="text-[10.5px] font-bold tracking-[0.1em] uppercase text-muted-foreground px-2.5 mt-4 mb-2">
                  {group}
                </p>
                {items.map(({ id, label }) => (
                  <a
                    key={id}
                    href={`#${id}`}
                    data-testid={`sidebar-${id}`}
                    className="block text-[13.5px] font-medium px-2.5 py-2 rounded-[10px] transition-all duration-200 no-underline"
                    style={{
                      color: activeSection === id ? "hsl(var(--foreground))" : "hsl(var(--muted-foreground))",
                      background: activeSection === id ? "var(--glass-2)" : "transparent",
                      boxShadow: activeSection === id ? "inset 0 0 0 1px var(--stroke)" : "none",
                    }}
                  >
                    {label}
                  </a>
                ))}
              </div>
            );
          })}
        </aside>

        {/* ── Main content ── */}
        <main className="flex-1 min-w-0 px-6 sm:px-10 py-8 pb-24 max-w-[1000px]">
          {/* Header */}
          <div className="flex items-start justify-between gap-5 flex-wrap mb-2">
            <div>
              <h1 className="text-[clamp(2rem,4.4vw,2.8rem)] font-extrabold tracking-[-0.042em] leading-[1.03]">
                Design System
              </h1>
              <p className="text-sm text-muted-foreground leading-relaxed mt-3 max-w-xl">
                The single source of truth for every CreatorLink surface. Tokens map 1:1 to{" "}
                <Code>index.css</Code> and <Code>tailwind.config.ts</Code>. If a value isn't
                defined here, it does not exist in the product.
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={toggleTheme}
                aria-label="Toggle theme"
                data-testid="btn-toggle-theme"
                className="w-[38px] h-[38px] rounded-xl border flex items-center justify-center transition-all duration-300 hover:border-primary/50 hover:-translate-y-0.5"
                style={{ background: "var(--glass-2)", borderColor: "var(--stroke)" }}
              >
                {isDark ? <Sun className="w-4 h-4 text-muted-foreground" /> : <Moon className="w-4 h-4 text-muted-foreground" />}
              </button>
              <button
                onClick={logout}
                aria-label="Log out of design system"
                data-testid="btn-design-system-logout"
                className="inline-flex items-center gap-2 h-[38px] px-3.5 rounded-xl border text-xs font-semibold transition-all duration-300 hover:border-destructive/50 hover:text-destructive hover:-translate-y-0.5"
                style={{ background: "var(--glass-2)", borderColor: "var(--stroke)", color: "hsl(var(--muted-foreground))" }}
              >
                <LogOut className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Log out</span>
              </button>
            </div>
          </div>

          {/* ── COLOR ── */}
          <section id="color" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Color"
              note="Backgrounds carry no hue shift between surfaces beyond luminance — depth comes from blur and stroke, not tinted panels. Click any swatch to copy its token."
            />
            <h3 className="text-sm font-semibold text-muted-foreground mb-3">Surfaces</h3>
            <SwatchGroup swatches={surfaces} cols={4} />

            <h3 className="text-sm font-semibold text-muted-foreground mt-7 mb-3">Brand</h3>
            <SwatchGroup swatches={brandColors} cols={3} />

            <h3 className="text-sm font-semibold text-muted-foreground mt-7 mb-3">Semantic</h3>
            <SwatchGroup swatches={semanticColors} cols={3} />

            <h3 className="text-sm font-semibold text-muted-foreground mt-7 mb-3">Text</h3>
            <SwatchGroup swatches={textColors} cols={3} />

            <p className="text-xs text-muted-foreground mt-4">
              Gradients are always{" "}
              <Code>primary → secondary → accent</Code> at 115°. Never invent a new gradient direction.
            </p>
          </section>

          {/* ── TYPOGRAPHY ── */}
          <section id="type" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Typography"
              note="Inter with SF Pro Display fallback. Display sizes are fluid via clamp(); body sizes are fixed so line lengths stay readable. Negative tracking scales with size."
            />
            <Panel>
              {[
                { sample: "Display 1", style: { fontSize: "clamp(2.4rem,5vw,3.4rem)", fontWeight: 800, letterSpacing: "-0.045em", lineHeight: 1 }, spec: "clamp(2.7–5.4rem) / 800 / -0.045em" },
                { sample: "Display 2", style: { fontSize: "clamp(1.8rem,3.4vw,2.4rem)", fontWeight: 700, letterSpacing: "-0.038em" }, spec: "clamp(2–3.35rem) / 700 / -0.038em" },
                { sample: "Title 1",   style: { fontSize: "1.5rem", fontWeight: 600, letterSpacing: "-0.03em" }, spec: "24px / 600 / -0.03em" },
                { sample: "Title 2",   style: { fontSize: "1.16rem", fontWeight: 600, letterSpacing: "-0.022em" }, spec: "18.5px / 600 / -0.022em" },
                { sample: "Body — the quick brown fox jumps over the lazy dog", style: { fontSize: "0.9375rem" }, spec: "15px / 400 / 1.62" },
                { sample: "Caption — metadata, timestamps, helper text", style: { fontSize: "0.8125rem", color: "var(--muted-foreground)" }, spec: "13px / 400" },
                { sample: "MICRO / OVERLINE", style: { fontSize: "0.7188rem", fontWeight: 700, letterSpacing: "0.1em", textTransform: "uppercase" as const, color: "var(--muted-foreground)" }, spec: "11.5px / 700 / +0.1em" },
              ].map(({ sample, style, spec }) => (
                <div key={spec} className="flex items-baseline justify-between gap-5 py-4 border-b border-white/[0.06] last:border-0 flex-wrap">
                  <span style={style}>{sample}</span>
                  <span className="font-mono text-[11px] text-muted-foreground whitespace-nowrap">{spec}</span>
                </div>
              ))}
            </Panel>
          </section>

          {/* ── SPACING ── */}
          <section id="space" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Spacing"
              note="4px base grid. Component padding uses 4–7; section rhythm uses 12–24. Nothing in between — arbitrary values are a review rejection."
            />
            <Panel>
              {spaces.map(([s, px]) => (
                <div key={s} className="flex items-center gap-3.5 py-1.5">
                  <span className="font-mono text-[11px] text-muted-foreground w-24 shrink-0">
                    space-{s} · {px}px
                  </span>
                  <div
                    className="h-3 rounded-sm"
                    style={{
                      width: Math.min(px * 2.6, 300),
                      background: "linear-gradient(90deg,#8B5CF6,#06B6D4)",
                    }}
                  />
                </div>
              ))}
            </Panel>
          </section>

          {/* ── RADIUS ── */}
          <section id="radius" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Radius"
              note="Large radii are the signature of the spatial look. Small elements never go below 8px, and cards never below 24px."
            />
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { r: 8,  label: "sm · 8px",   sub: "badges, pills" },
                { r: 16, label: "base · 16px", sub: "inputs, buttons" },
                { r: 24, label: "md · 24px",   sub: "cards" },
                { r: 32, label: "lg · 32px",   sub: "panels, modals" },
              ].map(({ r, label, sub }) => (
                <div
                  key={r}
                  className="aspect-[1.5] flex items-center justify-center text-center border-2 border-dashed border-white/[0.12] font-mono text-[11px] text-muted-foreground leading-relaxed"
                  style={{ borderRadius: r, background: "var(--glass-2)" }}
                >
                  {label}<br />{sub}
                </div>
              ))}
            </div>
          </section>

          {/* ── ELEVATION ── */}
          <section id="elevation" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Elevation & Glass"
              note="Two surface families. Glass for anything floating above content (nav, modals, dropdowns). Solid for dense data surfaces — tables, chat, forms. Never nest glass inside glass."
            />
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
              {[
                { shadow: "0 4px 16px -6px rgba(0,0,0,.5)",     label: "elev-1 · hover states" },
                { shadow: "0 12px 40px -12px rgba(0,0,0,.6)",    label: "elev-2 · resting cards" },
                { shadow: "0 30px 80px -20px rgba(0,0,0,.75)",   label: "elev-3 · modals, lifted" },
              ].map(({ shadow, label }) => (
                <div
                  key={label}
                  className="h-24 rounded-2xl flex items-center justify-center text-[11.5px] font-semibold text-muted-foreground border border-white/[0.06]"
                  style={{ background: "hsl(var(--card))", boxShadow: shadow }}
                >
                  {label}
                </div>
              ))}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <Panel className="rounded-3xl transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_30px_80px_-20px_rgba(0,0,0,.75)] hover:border-primary/35">
                <h3 className="text-[0.95rem] font-semibold tracking-[-0.02em]">Glass surface</h3>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  blur(28px) saturate(180%), 1px stroke at 10% white, top specular highlight. Floats above the ambient orb field.
                </p>
              </Panel>
              <div
                className="rounded-3xl p-6 border border-white/[0.06] transition-all duration-500 hover:-translate-y-1.5"
                style={{ background: "hsl(var(--card))", boxShadow: "0 12px 40px -12px rgba(0,0,0,.6)" }}
              >
                <h3 className="text-[0.95rem] font-semibold tracking-[-0.02em]">Solid surface</h3>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed">
                  Opaque <Code>surface-1</Code> with elev-2. Use wherever a user reads dense text for more than a few seconds.
                </p>
              </div>
            </div>
          </section>

          {/* ── BUTTONS ── */}
          <section id="buttons" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Buttons"
              note="One primary action per view. Ghost is the workhorse. Destructive never appears without a confirmation step."
            />
            <Panel>
              <div className="flex gap-3 flex-wrap items-center">
                {/* Primary */}
                <button
                  data-testid="btn-primary-demo"
                  className="relative inline-flex items-center px-5 py-2.5 rounded-2xl text-sm font-semibold text-white overflow-hidden transition-all duration-300 hover:-translate-y-0.5"
                  style={{
                    background: "linear-gradient(120deg,#8B5CF6,#3B82F6 50%,#06B6D4)",
                    backgroundSize: "220% 100%",
                    boxShadow: "0 12px 34px -10px rgba(139,92,246,.7)",
                    animation: "gradientPan 7s ease infinite",
                  }}
                >
                  Hire creator
                </button>
                {/* Ghost */}
                <button
                  data-testid="btn-ghost-demo"
                  className="inline-flex items-center px-5 py-2.5 rounded-2xl text-sm font-semibold border transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/50"
                  style={{ background: "var(--glass)", borderColor: "var(--stroke)", backdropFilter: "blur(18px)", color: "hsl(var(--foreground))" }}
                >
                  View portfolio
                </button>
                {/* Subtle */}
                <button
                  data-testid="btn-subtle-demo"
                  className="inline-flex items-center px-5 py-2.5 rounded-2xl text-sm font-semibold transition-all duration-200 hover:text-foreground"
                  style={{ background: "transparent", color: "hsl(var(--muted-foreground))" }}
                >
                  Cancel
                </button>
                {/* Danger */}
                <button
                  data-testid="btn-danger-demo"
                  className="inline-flex items-center px-5 py-2.5 rounded-2xl text-sm font-semibold text-white transition-all duration-300 hover:-translate-y-0.5"
                  style={{ background: "hsl(var(--destructive))", boxShadow: "0 12px 30px -12px rgba(239,68,68,.75)" }}
                >
                  Delete project
                </button>
                {/* Disabled */}
                <button
                  data-testid="btn-disabled-demo"
                  disabled
                  className="inline-flex items-center px-5 py-2.5 rounded-2xl text-sm font-semibold text-white opacity-40 pointer-events-none"
                  style={{ background: "linear-gradient(120deg,#8B5CF6,#3B82F6)" }}
                >
                  Disabled
                </button>
              </div>

              <div className="flex gap-3 flex-wrap items-center mt-5 pt-5 border-t border-white/[0.06]">
                <button data-testid="btn-sm-demo" className="px-4 py-2 rounded-[11px] text-[13px] font-semibold text-white" style={{ background: "linear-gradient(120deg,#8B5CF6,#3B82F6)", backgroundSize: "220%", animation: "gradientPan 7s ease infinite" }}>Small</button>
                <button data-testid="btn-md-demo" className="px-5 py-2.5 rounded-2xl text-sm font-semibold text-white" style={{ background: "linear-gradient(120deg,#8B5CF6,#3B82F6)", backgroundSize: "220%", animation: "gradientPan 7s ease infinite" }}>Default</button>
                <button data-testid="btn-lg-demo" className="px-7 py-3.5 rounded-[15px] text-[15px] font-semibold text-white" style={{ background: "linear-gradient(120deg,#8B5CF6,#3B82F6)", backgroundSize: "220%", animation: "gradientPan 7s ease infinite" }}>Large</button>
                <LoadingButton flash={flash} />
              </div>
            </Panel>
          </section>

          {/* ── INPUTS ── */}
          <section id="inputs" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Inputs"
              note="Focus ring is 4px primary at 14% plus a border shift — visible against both themes and satisfies AA non-text contrast. Errors are announced, not just coloured."
            />
            <Panel>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="ds-i1" className="text-[12.5px] font-semibold" style={{ color: "hsl(var(--foreground) / 0.8)" }}>Project title</label>
                  <input
                    id="ds-i1"
                    data-testid="input-project-title"
                    placeholder="e.g. Thumbnail pack for a gaming channel"
                    className="w-full px-3.5 py-2.5 rounded-2xl text-sm font-medium outline-none transition-all duration-300"
                    style={{
                      background: "var(--glass-2)",
                      border: "1px solid var(--stroke)",
                      color: "hsl(var(--foreground))",
                    }}
                    onFocus={(e) => { e.target.style.border = "1px solid rgba(139,92,246,.6)"; e.target.style.boxShadow = "0 0 0 4px rgba(139,92,246,.14)"; }}
                    onBlur={(e)  => { e.target.style.border = "1px solid var(--stroke)"; e.target.style.boxShadow = "none"; }}
                  />
                  <span className="text-[11.5px]" style={{ color: "hsl(var(--muted-foreground))" }}>Shown to creators in search results.</span>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="ds-i2" className="text-[12.5px] font-semibold" style={{ color: "hsl(var(--foreground) / 0.8)" }}>Budget (INR)</label>
                  <input
                    id="ds-i2"
                    data-testid="input-budget"
                    defaultValue="120"
                    aria-invalid="true"
                    className="w-full px-3.5 py-2.5 rounded-2xl text-sm font-medium outline-none"
                    style={{
                      background: "var(--glass-2)",
                      border: "1px solid hsl(var(--destructive))",
                      boxShadow: "0 0 0 4px rgba(239,68,68,.13)",
                      color: "hsl(var(--foreground))",
                    }}
                  />
                  <span className="text-[11.5px]" style={{ color: "hsl(var(--destructive))" }} role="alert">Minimum budget is ₹500.</span>
                </div>
                <div className="flex flex-col gap-1.5 sm:col-span-2">
                  <label htmlFor="ds-i3" className="text-[12.5px] font-semibold" style={{ color: "hsl(var(--foreground) / 0.8)" }}>Brief</label>
                  <textarea
                    id="ds-i3"
                    data-testid="input-brief"
                    rows={3}
                    placeholder="Describe deliverables, style references, and deadline…"
                    className="w-full px-3.5 py-2.5 rounded-2xl text-sm font-medium outline-none resize-none transition-all duration-300"
                    style={{
                      background: "var(--glass-2)",
                      border: "1px solid var(--stroke)",
                      color: "hsl(var(--foreground))",
                    }}
                    onFocus={(e) => { e.target.style.border = "1px solid rgba(139,92,246,.6)"; e.target.style.boxShadow = "0 0 0 4px rgba(139,92,246,.14)"; }}
                    onBlur={(e)  => { e.target.style.border = "1px solid var(--stroke)"; e.target.style.boxShadow = "none"; }}
                  />
                </div>
                <div className="flex items-center justify-between gap-4 sm:col-span-2 pt-1">
                  <div>
                    <p className="text-[13.5px] font-semibold">Accept direct invitations</p>
                    <p className="text-[11.5px]" style={{ color: "hsl(var(--muted-foreground))" }}>Clients can hire you without a public posting.</p>
                  </div>
                  <Toggle defaultOn={true} />
                </div>
              </div>
            </Panel>
          </section>

          {/* ── BADGES ── */}
          <section id="badges" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Badges & Status"
              note="Status colour is never the only signal — every badge carries a label or icon for colour-blind users."
            />
            <Panel className="flex gap-2.5 flex-wrap">
              {[
                { label: "Available now",    color: "#22C55E", bg: "rgba(34,197,94,.12)",   border: "rgba(34,197,94,.28)",   dot: true },
                { label: "Verified creator", color: "#3B82F6", bg: "rgba(59,130,246,.12)",  border: "rgba(59,130,246,.28)",  icon: "✓" },
                { label: "Pending review",   color: "#F59E0B", bg: "rgba(245,158,11,.12)",  border: "rgba(245,158,11,.28)" },
                { label: "Payment failed",   color: "#EF4444", bg: "rgba(239,68,68,.12)",   border: "rgba(239,68,68,.28)" },
                { label: "Figma" },
                { label: "Motion Design" },
                { label: "Top rated" },
              ].map(({ label, color, bg, border, dot, icon }) => (
                <span
                  key={label}
                  data-testid={`badge-${label.toLowerCase().replace(/\s+/g, "-")}`}
                  className="inline-flex items-center gap-1.5 px-2.5 py-[5px] rounded-[9px] text-[11.5px] font-semibold"
                  style={{
                    color: color ?? "hsl(var(--muted-foreground))",
                    background: bg ?? "var(--glass-2)",
                    border: `1px solid ${border ?? "var(--stroke-2)"}`,
                  }}
                >
                  {dot && <span className="status-dot" style={{ color }} />}
                  {icon && <span>{icon}</span>}
                  {label}
                </span>
              ))}
            </Panel>
          </section>

          {/* ── AVATARS ── */}
          <section id="avatars" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Avatars"
              note="Squircle, not circle — the radius scales with size. Initials fall back to a deterministic gradient derived from the user ID."
            />
            <Panel className="flex gap-6 items-center flex-wrap">
              {[
                { size: 26, r: 8,  label: "AR", grad: "linear-gradient(135deg,#8B5CF6,#3B82F6)", fs: 10 },
                { size: 34, r: 11, label: "NK", grad: "linear-gradient(135deg,#06B6D4,#22C55E)", fs: 12 },
                { size: 44, r: 14, label: "SI", grad: "linear-gradient(135deg,#F59E0B,#EF4444)", fs: 14 },
                { size: 60, r: 18, label: "MF", grad: "linear-gradient(135deg,#3B82F6,#8B5CF6)", fs: 18 },
              ].map(({ size, r, label, grad, fs }) => (
                <div
                  key={label}
                  data-testid={`avatar-${label}`}
                  className="grid place-items-center text-white font-bold shrink-0"
                  style={{ width: size, height: size, borderRadius: r, background: grad, fontSize: fs }}
                >
                  {label}
                </div>
              ))}

              {/* Stack */}
              <div className="flex" data-testid="avatar-stack">
                {[
                  { label: "AR", grad: "linear-gradient(135deg,#8B5CF6,#3B82F6)" },
                  { label: "NK", grad: "linear-gradient(135deg,#06B6D4,#22C55E)" },
                  { label: "SI", grad: "linear-gradient(135deg,#F59E0B,#EF4444)" },
                  { label: "+9", grad: "var(--surface-3, #182135)" },
                ].map(({ label, grad }, i) => (
                  <div
                    key={label}
                    className="grid place-items-center text-[12px] font-bold shrink-0"
                    style={{
                      width: 34, height: 34, borderRadius: 11,
                      background: grad,
                      marginLeft: i === 0 ? 0 : -10,
                      boxShadow: "0 0 0 3px hsl(var(--background))",
                      color: label === "+9" ? "hsl(var(--muted-foreground))" : "#fff",
                    }}
                  >
                    {label}
                  </div>
                ))}
              </div>
            </Panel>
          </section>

          {/* ── CARDS ── */}
          <section id="cards" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Cards"
              note="Three canonical card types cover ~90% of the product. Build new ones only when none of these fit."
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Creator card (glass) */}
              <Panel className="rounded-3xl transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_30px_80px_-20px_rgba(0,0,0,.75)] hover:border-primary/35">
                <div className="flex gap-3 items-start">
                  <div className="w-11 h-11 rounded-[14px] grid place-items-center text-sm font-bold text-white shrink-0" style={{ background: "linear-gradient(135deg,#8B5CF6,#3B82F6)" }}>AR</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[0.95rem] font-semibold">Aria Reyes</p>
                    <p className="text-[12.5px] mt-0.5" style={{ color: "hsl(var(--muted-foreground))" }}>Thumbnail Designer · Lisbon</p>
                    <p className="text-xs mt-1.5" style={{ color: "hsl(var(--foreground) / 0.8)" }}>
                      <span style={{ color: "#F59E0B" }}>★</span> 4.9 <span style={{ color: "hsl(var(--muted-foreground))" }}>(184)</span>
                    </p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-[1.1rem] font-bold tracking-tight">₹4,200</p>
                    <p className="text-[10.5px]" style={{ color: "hsl(var(--muted-foreground))" }}>/hour</p>
                  </div>
                </div>
                <div className="flex gap-1.5 mt-3.5 flex-wrap">
                  {["Photoshop", "YouTube"].map((t) => (
                    <span key={t} className="text-[11.5px] font-semibold px-2.5 py-[5px] rounded-[9px]" style={{ background: "var(--glass-2)", border: "1px solid var(--stroke-2)", color: "hsl(var(--muted-foreground))" }}>{t}</span>
                  ))}
                </div>
                <p className="text-[11px] mt-3" style={{ color: "hsl(var(--muted-foreground))" }}>Creator card — marketplace grid</p>
              </Panel>

              {/* Stat card (glass) */}
              <Panel className="rounded-3xl transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_30px_80px_-20px_rgba(0,0,0,.75)] hover:border-primary/35">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-semibold" style={{ color: "hsl(var(--muted-foreground))" }}>Portfolio views</span>
                  <span className="text-[11.5px] font-semibold px-2 py-[3px] rounded-[9px]" style={{ color: "#22C55E", background: "rgba(34,197,94,.12)", border: "1px solid rgba(34,197,94,.28)" }}>+24.8%</span>
                </div>
                <p className="text-[1.9rem] font-bold tracking-[-0.04em] mt-1.5">12,480</p>
                <div className="flex items-end gap-1 h-[52px] mt-3">
                  {sparkBars.map((h, i) => (
                    <div key={i} className="flex-1 rounded-t-sm" style={{ height: `${h}%`, background: "linear-gradient(180deg,#8B5CF6,rgba(59,130,246,.2))" }} />
                  ))}
                </div>
                <p className="text-[11px] mt-3" style={{ color: "hsl(var(--muted-foreground))" }}>Stat card — dashboards</p>
              </Panel>

              {/* Project row (solid) */}
              <div
                data-testid="card-project-row"
                className="sm:col-span-2 rounded-3xl p-5 border transition-all duration-500 hover:-translate-y-1.5 flex justify-between gap-5 items-center flex-wrap"
                style={{ background: "hsl(var(--card))", borderColor: "hsl(var(--card-border))", boxShadow: "0 12px 40px -12px rgba(0,0,0,.6)" }}
              >
                <div className="flex-1 min-w-[220px]">
                  <p className="text-[0.95rem] font-semibold">Thumbnail pack — 30 designs for a gaming channel</p>
                  <p className="text-[12.5px] mt-1.5" style={{ color: "hsl(var(--muted-foreground))" }}>Northwind Media · 31 applications · posted 2h ago</p>
                  <div className="flex gap-1.5 flex-wrap mt-2.5">
                    {["Photoshop", "3 weeks", "Entry level welcome"].map((t) => (
                      <span key={t} className="text-[11.5px] font-semibold px-2.5 py-[5px] rounded-[9px]" style={{ background: "var(--glass-2)", border: "1px solid var(--stroke-2)", color: "hsl(var(--muted-foreground))" }}>{t}</span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-[1.1rem] font-bold tracking-tight">₹45,000</p>
                    <p className="text-[11px]" style={{ color: "hsl(var(--muted-foreground))" }}>Fixed</p>
                  </div>
                  <button className="px-4 py-2 rounded-[11px] text-[13px] font-semibold border transition-all duration-300 hover:-translate-y-0.5 hover:border-primary/50"
                    style={{ background: "var(--glass)", borderColor: "var(--stroke)", color: "hsl(var(--foreground))" }}>
                    Apply
                  </button>
                </div>
              </div>
            </div>
            <p className="text-[11px] mt-3" style={{ color: "hsl(var(--muted-foreground))" }}>
              Project row uses a <em>solid</em> surface — it appears in long scrollable lists where blur cost compounds.
            </p>
          </section>

          {/* ── TABS ── */}
          <section id="tabs" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Tabs & Segmented Control"
              note="Keyboard: arrow keys move between tabs, Enter/Space activates. Selection announced via aria-selected."
            />
            <Panel>
              <TabDemo />
            </Panel>
          </section>

          {/* ── FEEDBACK ── */}
          <section id="feedback" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Feedback"
              note="Toasts live in an aria-live='polite' region and auto-dismiss at 5s — except errors, which persist until dismissed."
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {[
                { icon: "✓", iconBg: "rgba(34,197,94,.16)",  iconColor: "#22C55E",  msg: "Milestone approved · ₹15,000 released" },
                { icon: "!",  iconBg: "rgba(239,68,68,.16)",  iconColor: "#EF4444",  msg: "Upload failed — file exceeds 50 MB" },
                { icon: "↑",  iconBg: "rgba(59,130,246,.16)", iconColor: "#3B82F6",  msg: "Portfolio item published" },
                { icon: "⏱", iconBg: "rgba(245,158,11,.16)", iconColor: "#F59E0B",  msg: "Verification pending review" },
              ].map(({ icon, iconBg, iconColor, msg: m }) => (
                <div
                  key={m}
                  data-testid={`toast-${m.slice(0, 15).replace(/\s+/g, "-").toLowerCase()}`}
                  className="flex items-center gap-3 p-3.5 rounded-[15px] border text-[13.5px] font-medium"
                  style={{ background: "var(--glass)", backdropFilter: "blur(28px)", borderColor: "var(--stroke)", boxShadow: "0 12px 40px -12px rgba(0,0,0,.6)" }}
                >
                  <span className="w-[26px] h-[26px] rounded-[9px] grid place-items-center shrink-0" style={{ background: iconBg, color: iconColor }}>{icon}</span>
                  {m}
                </div>
              ))}
            </div>
          </section>

          {/* ── LOADING & EMPTY ── */}
          <section id="loading" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Loading & Empty States"
              note="Skeletons mirror the exact layout of the content they replace — no generic spinners in list views."
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Skeleton card */}
              <Panel className="rounded-3xl pointer-events-none">
                <div className="flex gap-3 items-center">
                  <div className="skeleton w-11 h-11 rounded-[14px] shrink-0" />
                  <div className="flex-1">
                    <div className="skeleton h-3 w-[55%] rounded" />
                    <div className="skeleton h-2.5 w-[38%] rounded mt-2" />
                  </div>
                </div>
                <div className="skeleton h-2.5 w-full rounded mt-4" />
                <div className="skeleton h-2.5 w-[72%] rounded mt-2" />
              </Panel>

              {/* Empty state */}
              <Panel className="rounded-3xl text-center pointer-events-none py-10">
                <div
                  className="w-16 h-16 rounded-[20px] mx-auto mb-4 grid place-items-center border"
                  style={{
                    background: "linear-gradient(135deg,rgba(139,92,246,.2),rgba(6,182,212,.1))",
                    borderColor: "var(--stroke)",
                  }}
                >
                  <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="hsl(var(--primary))" strokeWidth="1.7" strokeLinecap="round">
                    <path d="M4 7h16v13H4zM4 7l3-4h10l3 4M9 12h6" />
                  </svg>
                </div>
                <h3 className="text-[0.95rem] font-semibold">No applications yet</h3>
                <p className="text-sm text-muted-foreground mt-2 leading-relaxed max-w-[280px] mx-auto">
                  Share your project link to reach creators directly, or let smart matching surface it.
                </p>
                <div className="mt-4">
                  <span className="px-4 py-2 rounded-2xl text-[13px] font-semibold text-white inline-block opacity-60"
                    style={{ background: "linear-gradient(120deg,#8B5CF6,#3B82F6)" }}>
                    Copy project link
                  </span>
                </div>
              </Panel>
            </div>
          </section>

          {/* ── ACCESSIBILITY ── */}
          <section id="a11y" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Accessibility Rules"
              note="Non-negotiable. These are checked in code review, not at the end of the sprint."
            />
            <Panel>
              {[
                ["Body text on any surface",                          "≥ 4.5:1"],
                ["Large text (≥ 18.66px bold / 24px)",               "≥ 3:1"],
                ["Borders, focus rings, icon-only controls",          "≥ 3:1"],
                ["Every interactive element reachable by Tab",        "required"],
                ["Icon-only buttons carry aria-label",                "required"],
                ["Status never conveyed by colour alone",             "required"],
                ["Minimum touch target",                              "44 × 44 px"],
                ["Glass panels honour prefers-reduced-transparency",  "required"],
              ].map(([label, val]) => (
                <TableRow key={label as string} label={label} value={val as string} mono />
              ))}
            </Panel>
            <p className="text-[11px] mt-3" style={{ color: "hsl(var(--muted-foreground))" }}>
              Caution: <Code>--fg3</Code> (#8A90A2) on <Code>--bg</Code> measures ~5.6:1 — safe for body. Do not use it below 13px on glass surfaces.
            </p>
          </section>

          {/* ── MOTION ── */}
          <section id="motion" data-section className="mt-14 scroll-mt-6">
            <SectionHeader
              title="Motion"
              note="One easing curve across the entire product. Duration encodes distance: the further something travels, the longer it takes."
            />
            <Panel>
              {[
                ["Ease",                                           "cubic-bezier(0.16, 1, 0.3, 1)"],
                ["Fast — hovers, toggles, focus",                 "180ms"],
                ["Base — cards, dropdowns, tabs",                 "320ms"],
                ["Slow — page transitions, modals, lifts",        "560ms"],
                ["Ambient — orbs, floating cards, gradients",     "7–34s loops"],
                ["Animate only transform & opacity",              "60fps rule"],
                ["All motion gated behind prefers-reduced-motion","required"],
              ].map(([label, val]) => (
                <TableRow key={label as string} label={label} value={val as string} mono />
              ))}
            </Panel>
          </section>

        </main>
      </div>

      {/* Flash toast */}
      <div
        className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-4 py-3 rounded-[15px] border text-[13.5px] font-medium transition-all duration-500"
        style={{
          background: "var(--glass)",
          backdropFilter: "blur(28px)",
          borderColor: "var(--stroke)",
          boxShadow: "0 12px 40px -12px rgba(0,0,0,.6)",
          transform: `translate(-50%, ${visible ? "0%" : "150%"})`,
        }}
        aria-live="polite"
        data-testid="flash-toast"
      >
        <span className="w-[26px] h-[26px] rounded-[9px] grid place-items-center shrink-0" style={{ background: "rgba(34,197,94,.16)", color: "#22C55E" }}>✓</span>
        {msg}
      </div>
    </div>
  );
}
