import { MarketingLayout, PremiumCard } from "@/components";
import { PremiumButton } from "@/components/ui/premium-button";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Eye,
  EyeOff,
  Hexagon,
  ArrowRight,
  User,
  Briefcase,
} from "lucide-react";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { createSession } from "@/lib/session";

type Role = "client" | "creator" | null;

function isValidEmail(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

export default function Signup() {
  const [location, setLocation] = useLocation();

  const [role, setRole] = useState<Role>(null);
  const [step, setStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);

  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");

  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState("");

  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const returnTo = new URLSearchParams(
    location.split("?")[1] ?? "",
  ).get("returnTo");

  const safeReturnTo =
    returnTo &&
    returnTo.startsWith("/") &&
    !returnTo.startsWith("//")
      ? returnTo
      : null;

  const validateEmail = () => {
    const value = email.trim();

    if (!value) {
      setEmailError("Email is required.");
      return false;
    }

    if (!isValidEmail(value)) {
      setEmailError(
        "Please enter a valid email address, for example name@example.com.",
      );
      return false;
    }

    setEmailError("");
    return true;
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();

    setError("");

    if (!role) {
      setError("Please select whether you are a Client or Creator.");
      setStep(1);
      return;
    }

    if (!firstName.trim() || !lastName.trim()) {
      setError("First name and last name are required.");
      return;
    }

    if (!validateEmail()) {
      return;
    }

    if (password.length < 8) {
      setError("Password must be at least 8 characters.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        credentials: "include",
        body: JSON.stringify({
          email: email.trim(),
          password,
          firstName: firstName.trim(),
          lastName: lastName.trim(),
          role,
        }),
      });

      const data = await response.json().catch(() => null);

      if (!response.ok) {
        setError(
          data?.error ??
            "Unable to create your account. Please try again.",
        );
        return;
      }

      if (!data?.user) {
        setError("Account creation failed. Please try again.");
        return;
      }

      const sessionRole =
        data.user.role === "creator" ? "creator" : "client";

      createSession(
        sessionRole,
        data.user.email,
        true,
      );

      setLocation(
        safeReturnTo ??
          (sessionRole === "creator"
            ? "/creator-dashboard"
            : "/client-dashboard"),
      );
    } catch {
      setError(
        "Unable to connect to the server. Please try again.",
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <MarketingLayout>
      <div className="min-h-[80vh] flex items-center justify-center px-4 relative pt-20">
        <div className="ambient-glow ambient-glow-accent -right-40 top-1/2 -translate-y-1/2" />

        <motion.div
          layout
          className="w-full max-w-lg relative z-10"
        >
          <PremiumCard className="p-8 md:p-10 border-white/20 min-h-[500px] flex flex-col">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="flex flex-col h-full"
                >
                  <div className="flex flex-col items-center mb-8">
                    <div className="w-12 h-12 rounded-xl bg-primary/20 text-primary flex items-center justify-center mb-4">
                      <Hexagon className="w-6 h-6" />
                    </div>

                    <h1 className="text-2xl font-bold tracking-tight">
                      Join CreatorLink
                    </h1>

                    <p className="text-muted-foreground mt-2 text-sm text-center">
                      To begin, tell us how you want to use the
                      platform.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 gap-4 mb-8">
                    <button
                      type="button"
                      onClick={() => {
                        setRole("client");
                        setError("");
                      }}
                      className={cn(
                        "p-6 rounded-2xl border text-left transition-all",
                        role === "client"
                          ? "border-primary bg-primary/10 shadow-[0_0_20px_rgba(108,92,231,0.2)]"
                          : "border-white/10 bg-white/5 hover:border-white/30",
                      )}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="p-3 rounded-lg bg-white/10 text-foreground">
                          <Briefcase className="w-6 h-6" />
                        </div>

                        <div
                          className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            role === "client"
                              ? "border-primary"
                              : "border-white/20",
                          )}
                        >
                          {role === "client" && (
                            <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                          )}
                        </div>
                      </div>

                      <h3 className="font-bold text-lg">
                        I'm a Client
                      </h3>

                      <p className="text-sm text-muted-foreground mt-1">
                        I want to hire top-tier creative talent
                        for my projects.
                      </p>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setRole("creator");
                        setError("");
                      }}
                      className={cn(
                        "p-6 rounded-2xl border text-left transition-all",
                        role === "creator"
                          ? "border-accent bg-accent/10 shadow-[0_0_20px_rgba(0,210,255,0.2)]"
                          : "border-white/10 bg-white/5 hover:border-white/30",
                      )}
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div className="p-3 rounded-lg bg-white/10 text-foreground">
                          <User className="w-6 h-6" />
                        </div>

                        <div
                          className={cn(
                            "w-5 h-5 rounded-full border-2 flex items-center justify-center",
                            role === "creator"
                              ? "border-accent"
                              : "border-white/20",
                          )}
                        >
                          {role === "creator" && (
                            <div className="w-2.5 h-2.5 rounded-full bg-accent" />
                          )}
                        </div>
                      </div>

                      <h3 className="font-bold text-lg">
                        I'm a Creator
                      </h3>

                      <p className="text-sm text-muted-foreground mt-1">
                        I want to showcase my portfolio and find
                        clients.
                      </p>
                    </button>
                  </div>

                  {error && (
                    <div className="mb-4 rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400">
                      {error}
                    </div>
                  )}

                  <div className="mt-auto">
                    <PremiumButton
                      className="w-full"
                      onClick={() => {
                        if (!role) {
                          setError(
                            "Please select Client or Creator.",
                          );
                          return;
                        }

                        setError("");
                        setStep(2);
                      }}
                      variant={
                        role ? "primary" : "secondary"
                      }
                    >
                      Continue
                      <ArrowRight className="w-4 h-4 ml-2" />
                    </PremiumButton>

                    <div className="mt-6 text-center text-sm text-muted-foreground">
                      Already have an account?{" "}
                      <Link
                        href={
                          safeReturnTo
                            ? `/login?returnTo=${encodeURIComponent(
                                safeReturnTo,
                              )}`
                            : "/login"
                        }
                        className="text-primary font-medium hover:underline"
                      >
                        Log in
                      </Link>
                    </div>
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="flex flex-col h-full"
                >
                  <button
                    type="button"
                    onClick={() => {
                      setError("");
                      setStep(1);
                    }}
                    className="text-sm text-muted-foreground hover:text-foreground mb-6 flex items-center gap-1 w-max"
                  >
                    ← Back
                  </button>

                  <div className="mb-8">
                    <h1 className="text-2xl font-bold tracking-tight">
                      Create your{" "}
                      {role === "client"
                        ? "Client"
                        : "Creator"}{" "}
                      account
                    </h1>

                    <p className="text-muted-foreground mt-2 text-sm">
                      Just a few details to get you set up.
                    </p>
                  </div>

                  <form
                    onSubmit={handleSignup}
                    className="space-y-4 flex-1"
                    noValidate
                  >
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">
                          First name
                        </label>

                        <input
                          type="text"
                          value={firstName}
                          onChange={(event) =>
                            setFirstName(event.target.value)
                          }
                          required
                          autoComplete="given-name"
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium text-foreground">
                          Last name
                        </label>

                        <input
                          type="text"
                          value={lastName}
                          onChange={(event) =>
                            setLastName(event.target.value)
                          }
                          required
                          autoComplete="family-name"
                          className="w-full h-11 px-4 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">
                        Email
                      </label>

                      <input
                        type="email"
                        value={email}
                        onChange={(event) => {
                          setEmail(event.target.value);

                          if (emailError) {
                            setEmailError("");
                          }

                          if (error) {
                            setError("");
                          }
                        }}
                        onBlur={validateEmail}
                        placeholder="name@example.com"
                        autoComplete="email"
                        required
                        className={cn(
                          "w-full h-11 px-4 rounded-xl bg-white/5 border outline-none transition-all",
                          emailError
                            ? "border-red-500 focus:border-red-500 focus:ring-1 focus:ring-red-500"
                            : "border-white/10 focus:border-primary focus:ring-1 focus:ring-primary",
                        )}
                      />

                      {emailError && (
                        <p className="text-sm text-red-400">
                          {emailError}
                        </p>
                      )}
                    </div>

                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">
                        Password
                      </label>

                      <div className="relative">
                        <input
                          type={
                            showPassword
                              ? "text"
                              : "password"
                          }
                          value={password}
                          onChange={(event) => {
                            setPassword(event.target.value);

                            if (error) {
                              setError("");
                            }
                          }}
                          required
                          minLength={8}
                          autoComplete="new-password"
                          className="w-full h-11 px-4 pr-11 rounded-xl bg-white/5 border border-white/10 focus:border-primary focus:ring-1 focus:ring-primary outline-none transition-all"
                        />

                        <button
                          type="button"
                          onClick={() =>
                            setShowPassword(
                              (visible) => !visible,
                            )
                          }
                          aria-label={
                            showPassword
                              ? "Hide password"
                              : "Show password"
                          }
                          title={
                            showPassword
                              ? "Hide password"
                              : "Show password"
                          }
                          className="absolute inset-y-0 right-0 flex w-11 items-center justify-center text-muted-foreground transition-colors hover:text-foreground"
                        >
                          {showPassword ? (
                            <EyeOff className="w-4 h-4" />
                          ) : (
                            <Eye className="w-4 h-4" />
                          )}
                        </button>
                      </div>

                      <p className="text-xs text-muted-foreground">
                        Password must be at least 8 characters.
                      </p>
                    </div>

                    {error && (
                      <div
                        role="alert"
                        className="rounded-xl border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400"
                      >
                        {error}
                      </div>
                    )}

                    <PremiumButton
                      type="submit"
                      className="w-full mt-8"
                      glow
                      disabled={loading}
                    >
                      {loading
                        ? "Creating account..."
                        : "Create Account"}

                      {!loading && (
                        <ArrowRight className="w-4 h-4 ml-2" />
                      )}
                    </PremiumButton>
                  </form>
                </motion.div>
              )}
            </AnimatePresence>
          </PremiumCard>
        </motion.div>
      </div>
    </MarketingLayout>
  );
}