import { AppShell, PremiumCard } from "@/components";
import { Check } from "lucide-react";
import { PremiumButton } from "@/components/ui/premium-button";

export default function Notifications() {
  return (
    <AppShell>
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h1 className="text-3xl font-bold tracking-tight mb-2">Notifications</h1>
            <p className="text-muted-foreground">Stay updated on your projects and messages.</p>
          </div>
          <PremiumButton variant="ghost" className="text-sm">
            <Check className="w-4 h-4 mr-2" /> Mark all as read
          </PremiumButton>
        </div>

        <PremiumCard className="p-8 border-dashed border-white/10 text-center text-muted-foreground">
          No notifications yet.
        </PremiumCard>
      </div>
    </AppShell>
  );
}
