import {
  useCreateBlog as useGeneratedCreateBlog,
  useDeleteBlogById,
  useGetBlogBySlug,
  useListMyBlogs,
  useListPublishedBlogs,
  useListRelatedBlogs,
  useUpdateBlogById,
  type Blog,
  type BlogInput,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";

export type { Blog, BlogInput };

export function useBlogs() {
  return useListPublishedBlogs();
}

export function useMyBlogs(authorIdentifier: string | null) {
  return useListMyBlogs({ authorIdentifier: authorIdentifier ?? "anonymous" });
}

export { useGetBlogBySlug, useListPublishedBlogs, useListRelatedBlogs };

export function useCreateBlog() {
  const queryClient = useQueryClient();
  const mutation = useGeneratedCreateBlog();

  return {
    ...mutation,
    mutateAsync: (data: BlogInput) =>
      mutation.mutateAsync({ data }).then((result) => {
        queryClient.invalidateQueries({ queryKey: ["/api/blogs"] });
        return result;
      }),
  };
}

export function useUpdateBlog() {
  const queryClient = useQueryClient();
  const mutation = useUpdateBlogById();

  return {
    ...mutation,
    mutateAsync: (variables: {
      id: number;
      authorIdentifier: string;
      data: BlogInput;
    }) =>
      mutation
        .mutateAsync({
          blogId: variables.id,
          authorIdentifier: variables.authorIdentifier,
          data: variables.data,
        })
        .then((result) => {
          queryClient.invalidateQueries();
          return result;
        }),
  };
}

export function useDeleteBlog() {
  const queryClient = useQueryClient();
  const mutation = useDeleteBlogById();

  return {
    ...mutation,
    mutateAsync: (variables: { id: number; authorIdentifier: string }) =>
      mutation
        .mutateAsync({
          blogId: variables.id,
          authorIdentifier: variables.authorIdentifier,
        })
        .then((result) => {
          queryClient.invalidateQueries();
          return result;
        }),
  };
}

export function useListMyBlogsForAuthor(authorIdentifier: string | null) {
  return useMyBlogs(authorIdentifier);
}