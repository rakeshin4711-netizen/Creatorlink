import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Route, Switch, Router as WouterRouter, useLocation } from 'wouter';
import { useTheme } from '@/hooks/use-theme';
import { useEffect, useState, type ComponentType } from "react";
import { getSession, type SessionRole } from "@/lib/session";

// Pages
import LandingPage from '@/pages/index';
import Login from '@/pages/login';
import Signup from '@/pages/signup';
import CreatorDashboard from '@/pages/creator-dashboard';
import ClientDashboard from '@/pages/client-dashboard';
import SearchPage from '@/pages/search';
import CreatorProfile from '@/pages/creator/[id]';
import PortfolioDetails from '@/pages/portfolio/[id]';
import ProjectDetails from '@/pages/project/[id]';
import Chat from '@/pages/chat';
import Notifications from '@/pages/notifications';
import Settings from '@/pages/settings';
import DeleteProfile from '@/pages/settings/delete-profile';
import Billing from '@/pages/billing';
import PaymentSuccess from '@/pages/payment-success';
import DesignSystem from '@/pages/design-system';
import NotFound from '@/pages/not-found';
import BlogList from '@/pages/blogs/index';
import BlogDetail from '@/pages/blogs/[slug]';
import BlogEditor from '@/pages/blogs/editor';
import BlogUploadGate from '@/pages/blogs/upload-gate';
import { Toaster } from "@/components/ui/toaster";

const queryClient = new QueryClient();

function ProtectedRoute({
  component: Component,
  requiredRole,
}: {
  component: ComponentType;
  requiredRole?: SessionRole;
}) {
  const [location, setLocation] = useLocation();
  const [isAuthorized, setIsAuthorized] = useState(() => {
    const session = getSession();
    return Boolean(session && (!requiredRole || session.role === requiredRole));
  });

  useEffect(() => {
    const session = getSession();
    const authorized = Boolean(session && (!requiredRole || session.role === requiredRole));
    setIsAuthorized(authorized);

    if (!session) {
      setLocation(`/login?returnTo=${encodeURIComponent(location)}`);
    } else if (requiredRole && session.role !== requiredRole) {
      setLocation(session.role === "creator" ? "/creator-dashboard" : "/client-dashboard");
    }
  }, [location, requiredRole, setLocation]);

  if (!isAuthorized) {
    return <div className="min-h-screen bg-background" />;
  }

  return <Component />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/login" component={Login} />
      <Route path="/signup" component={Signup} />
      <Route path="/blog" component={BlogList} />
      <Route path="/blog/:slug" component={BlogDetail} />
      <Route path="/blogs" component={BlogList} />
      <Route path="/blogs/:slug" component={BlogDetail} />
      <Route path="/creatorlink/upload-blog">
        <BlogUploadGate />
      </Route>
      <Route path="/creator-dashboard">
        <ProtectedRoute component={CreatorDashboard} requiredRole="creator" />
      </Route>
      <Route path="/dashboard">
        <ProtectedRoute
          component={DashboardRedirect}
        />
      </Route>
      <Route path="/client-dashboard">
        <ProtectedRoute component={ClientDashboard} requiredRole="client" />
      </Route>
      <Route path="/search" component={SearchPage} />
      <Route path="/creator/:id" component={CreatorProfile} />
      <Route path="/portfolio/:id" component={PortfolioDetails} />
      <Route path="/project/:id">
        <ProtectedRoute component={ProjectDetails} />
      </Route>
      <Route path="/chat">
        <ProtectedRoute component={Chat} />
      </Route>
      <Route path="/notifications">
        <ProtectedRoute component={Notifications} />
      </Route>
      <Route path="/settings/delete-profile">
        <ProtectedRoute component={DeleteProfile} requiredRole="creator" />
      </Route>
      <Route path="/settings">
        <ProtectedRoute component={Settings} />
      </Route>
      <Route path="/billing">
        <ProtectedRoute component={Billing} />
      </Route>
      <Route path="/payment-success">
        <ProtectedRoute component={PaymentSuccess} />
      </Route>
      <Route path="/design-system" component={DesignSystem} />
      <Route component={NotFound} />
    </Switch>
  );
}

function DashboardRedirect() {
  const [, setLocation] = useLocation();

  useEffect(() => {
    const session = getSession();
    setLocation(session?.role === "creator" ? "/creator-dashboard" : "/client-dashboard");
  }, [setLocation]);

  return <div className="min-h-screen bg-background" />;
}

function App() {
  // Ensure dark theme is applied based on localStorage or default to system
  useTheme();

  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
        <Router />
        <Toaster />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
