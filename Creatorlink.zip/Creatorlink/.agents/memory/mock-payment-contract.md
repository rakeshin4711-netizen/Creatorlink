---
name: Mock payment contract
description: India-only mock checkout persists provider-neutral payment records for future Razorpay replacement.
---

Payment records use INR amounts, a server-calculated 10% CreatorLink commission, 90% creator earnings, status, provider, payment ID, and invoice number; the current provider is `mock`.

**Why:** The checkout must be testable before Razorpay credentials are available without coupling the database or UI to a temporary provider.

**How to apply:** Keep amount and commission calculations server-owned, preserve the payment/invoice identifiers across success navigation, and replace only the provider execution layer when Razorpay is connected.