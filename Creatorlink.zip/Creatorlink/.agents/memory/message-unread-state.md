---
name: Message unread state
description: Conversation unread counts are persisted per participant and cleared through the read endpoint when a thread is opened.
---

Unread state belongs to the conversation and must be tracked separately for each participant, not inferred only from the current browser.

**Why:** Creator-to-client delivery needs the recipient’s unread count to survive reloads and appear consistently in every session.

**How to apply:** Increment only the recipient counter when saving a message, return the requesting participant’s count in list responses, and clear it through an explicit participant-scoped read action.