---
name: DB-only UI data
description: Rule for removing demo records from CreatorLink screens when a persisted model is unavailable.
---

All user-facing records must come from persisted database data. When a feature has no database model or API yet, preserve the existing section layout but render an explicit empty state instead of static sample values.

**Why:** Demo records made empty databases look populated and caused the UI to contradict the product's DB-only requirement.

**How to apply:** Add or use a typed DB endpoint for real records; otherwise show a clear empty state for notifications, invoices, payments, assignments, reviews, comments, and similar unsupported data.