---
name: Client payment dashboard
description: Client dashboard payment state is derived from persisted successful payments and paid project status.
---
Successful mock payment creation updates the project to `paid`, creates the invoice record, hides Pay Now, and contributes to the client’s Total Spent.
**Why:** The dashboard must remain correct after refresh and across sessions instead of relying on local button state.
**How to apply:** Read projects and client payments from the API, treat successful payment records as the source for totals and invoice rows, and invalidate both queries after payment.