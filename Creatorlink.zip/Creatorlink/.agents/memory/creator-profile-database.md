---
name: Creator profile database
description: Creator profiles use a dedicated database table and API contract; the legacy users table must remain represented for safe schema sync.
---

Creator profile data is stored independently from legacy account records in the database. Schema synchronization must preserve the pre-existing `users` table rather than treating it as an unmanaged table.

**Why:** The development database can retain tables from removed features, and Drizzle schema pushes may stop on a named-schema conflict if those tables are omitted.

**How to apply:** Keep legacy table shape represented in the database schema while adding creator-specific tables and OpenAPI-backed routes separately.