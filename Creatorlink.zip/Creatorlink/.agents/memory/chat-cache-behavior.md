---
name: Chat cache behavior
description: Chat polling endpoints must return fresh JSON because the generated fetch client treats HTTP 304 as an empty result.
---

Chat conversation and message list responses should disable HTTP cache validation with `Cache-Control: no-store`.

**Why:** The generated client considers 304 a no-body response, so Express freshness responses can replace a valid React Query list with an empty result during polling.

**How to apply:** Keep chat GET endpoints uncached and update the conversation-list cache immediately after creating a thread.