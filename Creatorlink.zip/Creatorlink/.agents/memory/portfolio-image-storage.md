---
name: Portfolio image storage
description: Why CreatorLink portfolio images are persisted directly with portfolio records.
---

CreatorLink portfolio image uploads are converted to data URLs in the browser and stored in the portfolio `images` array.

**Why:** The app currently has no server authentication or object-storage integration, while the portfolio requirement needed working uploads without changing the existing auth/UI architecture.

**How to apply:** If portfolio images need production-scale handling later, migrate the existing image strings to object storage behind authenticated upload endpoints; keep the portfolio API response shape as an array of image URLs.