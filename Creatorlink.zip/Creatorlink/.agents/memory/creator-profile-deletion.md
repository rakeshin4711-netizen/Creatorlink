---
name: Creator profile deletion
description: Data boundary for removing a CreatorLink creator profile without removing the account.
---

Creator profile deletion must target the `creators` record and its creator-owned portfolio records only. The separate account record remains available so the user can create a new creator profile later.

**Why:** A creator profile is user-owned content, not the authentication account.

**How to apply:** Keep profile deletion creator-scoped, remove related portfolio data in the same database transaction, preserve the session/account, and invalidate creator profile/portfolio caches afterward.