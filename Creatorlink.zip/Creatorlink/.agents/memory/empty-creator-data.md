---
name: Empty creator data
description: Runtime behavior when CreatorLink has no creator records.
---

CreatorLink currently permits an empty creator collection, so any existing demo-oriented screen that reads the first creator must render a safe empty or not-found state rather than assuming a record exists.

**Why:** Removing the demo creator data exposed direct index-zero and property dereferences in dashboard, sidebar, and detail routes.

**How to apply:** When creator records are absent, use optional access for incidental dashboard identity and return a safe not-found state for creator or portfolio detail routes. Do not reintroduce fixture records to satisfy the UI.