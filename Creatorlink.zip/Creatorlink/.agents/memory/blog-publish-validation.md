---
name: Blog publish validation
description: Published articles require complete public-facing metadata before database persistence and redirect.
---

Publishing must validate title, content, generated or editable slug, short description, and category before saving; the server must repeat these checks.

**Why:** Client-only validation can be bypassed or drift from the API contract, creating published articles that cannot render correctly.

**How to apply:** Normalize and validate at both boundaries, persist the uploaded cover image with the article, force published status for Publish, and redirect using the saved slug only after a successful response.