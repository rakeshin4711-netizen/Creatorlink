---
name: Design System access
description: Access behavior and security boundary for the private design-system page.
---

The Design System page is intentionally protected at the route component level with a client-side password gate. Successful access is persisted in localStorage, and the page provides a logout action that clears the local state.

**Why:** The requested behavior was route-only protection without changing the rest of the public app, using localStorage for a lightweight shared preview/workspace gate.

**How to apply:** Keep this gate isolated to `/design-system`; do not move it into global authentication or add redirects that affect other routes. This client-side gate is a UX/access barrier, not a server-side security boundary.