---
name: Protected return routes
description: Protected direct URLs preserve their requested path through login and signup before returning to the original page.
---

ProtectedRoute redirects unauthenticated direct visits with a validated `returnTo` path rather than dropping the original destination.

**Why:** Refreshing or opening a protected deep link should authenticate the user and then restore the intended page instead of sending them to a generic dashboard.

**How to apply:** Keep return paths relative, reject protocol-relative URLs, and use the same return target in login and signup links.