---
name: Orval parameter naming
description: Generated API/Zod naming constraints when adding multiple OpenAPI parameters to operations.
---

When an operation's path and query parameters produce the same generated parameter type name in Orval, code generation can fail with duplicate barrel exports. Prefer a stable, entity-shaped request body for ownership context when the generated parameter contract would collide.

**Why:** Orval emits runtime parameter schemas and TypeScript parameter types into separate generated files that are re-exported together; operation-shaped names can collide.

**How to apply:** After changing an OpenAPI operation's parameters, run codegen immediately and inspect the generated barrel/typecheck before implementing callers.