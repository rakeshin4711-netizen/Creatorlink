---
name: Blog upload route gate
description: The blog editor deep link uses its own localStorage password gate before rendering the existing editor.
---

The Upload Blog deep link must remain an SPA history route and use a route-specific gate before mounting the editor; the editor and other application routes stay unchanged.

**Why:** Direct visits and refreshes need to resolve through the Vite fallback while access to this standalone upload surface remains restricted.

**How to apply:** Keep the route at `/creatorlink/upload-blog`, persist only the gate’s localStorage flag, and avoid changing the editor component when adjusting access behavior.