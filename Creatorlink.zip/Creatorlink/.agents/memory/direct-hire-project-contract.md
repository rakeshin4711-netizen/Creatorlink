---
name: Direct hire project contract
description: Direct creator hires use the existing project record with both participant identifiers and a pending status.
---
Direct hires are persisted as projects with the client identifier, creator identifier, and `pending` status before opening the project/payment page.
**Why:** This keeps hiring compatible with the existing project and mock-payment flow without introducing a separate checkout-only record.
**How to apply:** Keep the Hire action server-backed, preserve both participant identifiers, and route successful creation to the existing project detail page.