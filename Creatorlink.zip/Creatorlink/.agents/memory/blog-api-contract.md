---
name: Blog API contract
description: Durable conventions for the CreatorLink blog API and generated client
---

Blog public slug reads and owned mutations use distinct OpenAPI operation IDs and paths. Keep author ownership in the mutation path and keep the “my posts” identifier as a query parameter so Orval does not generate duplicate parameter exports.

**Why:** Orval combines operation IDs and parameter names across generated Zod and React clients; reusing an operation ID or the same parameter name in different locations creates duplicate generated declarations and breaks the workspace typecheck.

**How to apply:** When adding blog endpoints, use the existing generated hook conventions and regenerate the API clients before wiring UI code.