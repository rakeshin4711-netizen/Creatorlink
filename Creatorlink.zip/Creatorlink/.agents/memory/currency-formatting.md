---
name: Currency formatting
description: Shared monetary display policy for CreatorLink.
---

CreatorLink stores numeric rates and budgets independently of display currency. User-facing monetary values should use the shared formatter, which defaults to INR (`en-IN`) and supports future currency/locale overrides.

**Why:** Currency presentation needs to change without rewriting every page or changing persisted numeric data.

**How to apply:** Use the currency helpers for rates, budgets, balances, totals, and range labels; pass an explicit currency only when a future account or project setting provides one.